/*【字符串】编写程序，输入一个字符串s1，接着再输入一个字符串s2，将字符串s1中字符串s2都删掉，输出处理后的字符串。
例如：输入：abcababcababca
           abc
      输出：ababa*/
#include <iostream>
#include <cstring>
using namespace std;

int main()
{
	ios::sync_with_stdio(false);
	cin.tie(0);
	char a[100], b[100];
	int j = 0;
	gets(a);
	gets(b);
	int len = strlen(b);
	for (int i = 0; a[i] != '\0'; i++)
	{
		if (strncmp(a + i, b, len) == 0)
		{
			i += len - 1;
		}
		else
		{
			a[j++] = a[i];
		}
		a[j] = '\0';
	}
	puts(a);
	return 0;
}