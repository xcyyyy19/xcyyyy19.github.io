/*大连东软信息学院要举行教工拔河比赛了，计算机系的老师们为了取得好的成绩，决定使用最胖的老师参赛，你能帮助老师们挑出参赛的队员吗？
按照比赛的要求，计算机系需要派出5男5女的阵容参赛。
Input
在输入的数据中，第一行是个整数N（10<=N<=100），接下来的N行数据中，每行是一位老师的姓名，体重，性别的信息，
所有老师的姓名和体重不会重复，性别以M和F表示男女，男女教师的个数分别>=5。
Output
你的输出应该是10行，是参赛的10位老师的姓名，并且前5个是男老师，后5个是女老师，分别以体重的降序排列。
Sample Input
13
张冬青 160 M
董玮 120 F
李绪成 190 M
刘振宇 140 M
窦乔 86 F
孙斌 151 M
王刚 200 M
杨勇虎 163 M
高志君 125 F
张娜 100 F
邱建华 145 M
孙建梅 110 F
王珍 111 F
Sample Output

王刚
李绪成
杨勇虎
张冬青
孙斌
高志君
董玮
王珍
孙建梅
张娜*/
#include <iostream>
#include <algorithm>
#include <string.h>

using namespace std;

struct S
{
	char arr[100];
	double h;
	char sex;
} a[100];

void swap_arr(char *arr, char *ar)
{
	char a[1000] = {0};
	strcpy(a, arr);
	strcpy(arr, ar);
	strcpy(ar, a);
}
void swap_h(double *h, double *h2)
{
	double temp;
	temp = *h;
	*h = *h2;
	*h2 = temp;
}
void swap_sex(char *sex, char *se)
{
	char *temp;
	temp = sex;
	sex = se;
	se = temp;
}
void swap(struct S *a, struct S *b)
{
	swap_arr(a->arr, b->arr);
	swap_h(&(a->h), &(b->h));
	swap_sex(&a->sex, &b->sex);
}

int main()
{
	int n;
	cin >> n;
	for (int i = 0; i < n; i++)
	{
		cin >> a[i].arr[i] >> a[i].h >> a[i].sex;
	}
	//sort(a[100].arr[0], a[100].arr[n - 1], greater<struct S>());
	for (int i = n; i > 0; i--)
	{
		for (int j = 0; j < n; j++)
		{
			if (a[j].arr[j] > a[j + 1].arr[j + 1])
			{
				swap(a[j], a[j + 1]);
			}
		}
	}
	return 0;
}
