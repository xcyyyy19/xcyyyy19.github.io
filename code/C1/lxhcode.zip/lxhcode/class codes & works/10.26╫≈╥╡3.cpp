/*【单循环】编写程序，从键盘上输入若干个整数（以0作为结束），统计正数个数及负数的个数，分别在两行上输出。

    例如：输入：1 6 -2 -3 7 1 4 -5 0

          输出：5

                3

    【测试数据有多组，每组输出结果后必须换行】
*/
#include <stdio.h>

int main()
{
	int a[30] = {0}, i = 0, j = 0, k = 0;
	while (scanf("%d", &a[i++]) != EOF)
	{
		if (a[i - 1] > 0)
			k++;
		else if (a[i - 1] < 0)
			j++;
		else
			break;
	}
	printf("%d\n%d\n", k, j);
	return 0;
}