/*【单循环】编写程序，输入一个正整数n，计算1/1-2/3+3/5-4/7+5/9-6/11+…的前n项之和。结果保留10位小数。

    例如：输入：3

          输出：0.9333333333

    【测试数据有多组，每组输出结果后必须换行】*/
#include <stdio.h>

int main()
{
	double j, b = 1, c = 1, sum = 0;
	int i;
	int n;
	scanf("%d", &n);
	for (i = 0; i < n; ++i)
	{
		sum += b / c * (i % 2 ? -1 : 1);
		b += 1;
		c += 2;
	}
	printf("%.10lf\n", sum);
	return 0;
}
// if (n % 2 == 0)
// {
// 	for (double a = 0, i = 1.0, j = 1.0; i < n && j < n + 2; i++, j += 2)
// 	{
// 		b = a;
// 		a = i / j;
// 		c = a - b;
// 	}
// 	}
// 	else
// 	{
// 		for (double a = 0, i = 1.0, j = 1.0; i < n && j < n + 2; i++, j += 2)
// 		{
// 			b = a;
// 			a = i / j;
// 			d = a + b;
// 		}
// 	}
