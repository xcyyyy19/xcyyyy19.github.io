#include<stdio.h>
int main()
{
	char n[15];
	scanf("%s",n);//循环读到\0        其中n = &n[0] = ??
//scanf("%s",n+1);把n+1当成首地址，我内存开的大，前面的内存都不要了
	
	return 0;
}