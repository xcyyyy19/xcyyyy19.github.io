#include <iostream>

using namespace std;
int isum(int *, int); //函数声明

int main()
{
	ios::sync_with_stdio(false);
	cin.tie(0);

	int a[10] = {1, 2, 3, 4, 5};
	printf("%d", isum(a, 10));

	return 0;
}
int isum(int *p, int n) //也可写成 int isum(int p[], int n)
{
	int i, sum = 0;
	for (i = 0; i < n; i++)
		sum += p[i]; //p[i]与a[i]只区别在&p[i]系统不知道p多大，且p为指针，指针都是变量，只可做右值；
	return sum;
}