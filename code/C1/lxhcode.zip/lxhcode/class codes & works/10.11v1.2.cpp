#include <stdio.h>
int main()
{
	int a[5] = {0};
	int i = 0;
	for (i = 0; i < 5; i++)
	{
		scanf("%d", a + i);
		scanf("%d", &a[i]);
		scanf("%d", &*(a + i));
	}

	for (i = 0; i < 5; i++)
	{
		printf("%d ", a[i]);
		printf("%x ", a + i); //%x打印地址
		printf("%x \n", &a[i]);
		printf("%d\n", *(a + i));
	}

	int *p = NULL;
	p = a;
	for (i = 0; i < 5; i++)
	{
		printf("%d ", p[i]);
		printf("%d\n", *(p + i));
	}
	return 0;
}