#include <stdio.h>
int main()
{
	int arr[5];
	int i = 0;
	for (i = 0; i < 5; i++)
	{
		scanf("%d", arr + i);
		//scanf("%d", &arr [i]);
		//scanf("%d", &*(arr + i);               没事找事
	}
	for (i = 0; i < 5; i++)
	{
		printf("%d ", arr[i]);  //*(arr=i)   打印数组值
		printf("%X ", arr + i); //&arr[i]    打印数组地址
	}
}