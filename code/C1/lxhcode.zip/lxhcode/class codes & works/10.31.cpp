#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdlib.h>

void fun()
{
	/**********Program**********/
	double a = 0, b = 0, c = 0;
	scanf("%lf%lf%lf", &a, &b, &c);
	printf("%.1lf\n%.1lf\n", a + b + c, (a + b + c) / 3);
	/**********  End  **********/
}
int main() /*严禁修改，否则，后果自负*/
{
	fun();
	return 0;
}