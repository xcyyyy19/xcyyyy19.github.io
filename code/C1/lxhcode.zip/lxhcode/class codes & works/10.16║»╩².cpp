#include <stdio.h>
int fun(int *p);//指针改变实参
int fun2(int n)
{
	printf("%d\n", n);
	fun(&n);
	return 0;
}
int fun(int *p)
{
	printf("%d\n", *p);
	(*p)++;//*p即为m
	printf("%d\n", *p);
	return 0;
}
int main()
{
	int m = 1;
	fun2(m);
	printf("%d\n", m);
	return 0;
}