#include <stdio.h>

int main()
{

	char name[100];
	double ds = 0.0, cs = 0.0;
	printf("input u name\n");
	scanf("%s", name);
	printf("my name is:%s", name);
	printf("input u c_score and data_structure_score\n"); //C语言成绩和数据结构成绩
	scanf("%lf%lf", &cs, &ds);
	printf("%.2lf %lf\n", cs, ds);
	if (cs > 87.7)
	{
		if (ds > 90.1)
		{
			printf("u nb xueshen\n");
		}
		else if (ds > 80.0 && ds <= 90.1)
		{
			printf("u xueba\n")
		}
		else
	}
	return 0;
}