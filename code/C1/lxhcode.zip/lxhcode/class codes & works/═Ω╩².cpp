/*输出1~1000的完数(1不是完数)
6=1+2+3
。。。
Sample Input
Sample Output
6=1+2+3
28=1+2+4+7+14
496=1+2+4+8+16+31+62+124+248*/
#include <stdio.h>

 int main()
 {
	 int arr[1000];
	 for(int i = 0;i < 1000;i++)
	 {
		 for(int j = 0; j < i;j++)
		 {
			  if(arr[i]%arr)
		 }
		
	 }
	return 0;
 }