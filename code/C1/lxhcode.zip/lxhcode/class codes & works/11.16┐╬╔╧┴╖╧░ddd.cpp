//找最大最小值
#include <iostream>

using namespace std;

int main()
{
	ios::sync_with_stdio(false);
	cin.tie(0);

	int a[10];
	int max, min, i;

	for (int i = 0; i < 10; i++)
	{
		scanf("%d", &a[i]);
	}
	min = max = a[0]; //注意这一行如果放到scanf上面，就自动得0了
	for (int i = 0; i < 10; i++)
	{
		if (a[i] > max)
		{
			max = a[i];
		}
		else if (a[i] < min)
		{
			min = a[i];
		}
	}
	printf("%d\n", max - min);

	return 0;
}