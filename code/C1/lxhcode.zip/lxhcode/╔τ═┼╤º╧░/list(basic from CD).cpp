#include <stdio.h>
#include <stdlib.h>

struct List
{
	int data;
	struct List *next;
};

void insert(struct List *l, int loc, int value)
{
	for (int i = 0; i < loc - 1; ++i)
		l = l->next;
	struct List *p = (struct List *)malloc(sizeof(struct List));
	p->data = value;
	p->next = l->next;
	l->next = p;
}

struct List *push_front(struct List *l, int value)
{
	struct List *p = (struct List *)malloc(sizeof(struct List));
	p->data = value;
	p->next = l;
	return p;
}

void push_back(struct List *l, int value)
{
	struct List *p = (struct List *)malloc(sizeof(struct List)); //malloc 类型为void*,需要强制转换才能赋值
	p->data = value;
	while (l->next)
		l = l->next;
	l->next = p;
	p->next = NULL;
}

void erase(struct List *l, int loc)
{
	for (int i = 0; i < loc - 1; ++i)
		l = l->next;
	struct List *p = l->next;
	l->next = l->next->next;
	free(p);
}

struct List *pop_front(struct List *l)
{
	struct List *p = l->next;
	free(l);
	return p;
}

void pop_back(struct List *l)
{
	while (l->next->next)
		l = l->next;
	free(l->next);
	l->next = NULL;
}

void clear(struct List *l)
{
	do
	{
		struct List *t = l->next;
		printf("%d go die\n", l->data);
		free(l);
		l = t;
	} while (l->next);
	free(l);
}

int main()
{
	struct List *p = (struct List *)malloc(sizeof(struct List));
	p->data = 1;
	p->next = 0;
	for (int i = 2; i <= 10; ++i)
	{
		push_back(p, i);
	}
	//p = push_front(p, 100);//p变成新的头节点。
	struct List *t = p;
	printf("%d ", t->data);
	do
	{
		t = t->next;
		printf("%d ", t->data);
	} while (t->next);
	printf("\n");
	clear(p);
	return 0;
}