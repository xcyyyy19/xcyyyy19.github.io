/*总结出了“三人同行七十稀，五树梅花廿一枝，七子团圆正半月，去百零五便得知。”
这样的口诀，意思是说“以三三数之，余数乘以七十；五五数之，余数乘以二十一；七七数之，余数乘十五。
三者相加，如不大于一百零五，即为答数；否则须减去一百零五或其倍数。”也就是说，(2*70+3*21+2*15)%105=(140+63+30)%105=23。
聪明的同学你看懂其中的道理了吗?现在我给你三个整数a、b和c(a、b、c的最大公约数是1)，
然后再给你余数r1、r2和r3。求最小的非负数x，使得x%a=r1,x%b=r2,x%c=r3。
Input
输入N行，每行6个非负整数，前三个a、b、c，后三个r1、r2、r3
Oupt
输出N行，每行一个数，对应输入的答案
Sample Input
3 5 7 2 3 2
7 9 5 1 2 3
7 5 3 1 1 2
Sample Output
23
218
71*/
#include <iostream>

using namespace std;

int main()
{
	ios::sync_with_stdio(false);
	cin.tie(0);

	int a, b, c, r1, r2, r3;
	while (scanf("%d%d%d%d%d%d", &a, &b, &c, &r1, &r2, &r3) != EOF)
	{
		for (int x = 0; x < 10000; x++)
		{
			if ((x % a == r1) && (x % b == r2) && (x % c == r3))
			{
				printf("%d\n", x);
				break;
			}
		}
	}

	return 0;
}