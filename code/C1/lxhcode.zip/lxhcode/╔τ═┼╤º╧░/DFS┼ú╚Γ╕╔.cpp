/*阿牛从家里拿来了一块上等的牛肉干，准备在上面刻下一个长度为n的只由"E" "O" "F"三种字符组成的字符串
（可以只有其中一种或两种字符，但绝对不能有其他字符）,阿牛同时禁止在串中出现O相邻的情况，他认为，"OO"看起来就像发怒的眼睛，效果不好。
Input
输入数据包含多个测试实例,每个测试实例占一行,由一个整数n组成，(0<n<40)。
Output
对于每个测试实例，请输出全部的满足要求的涂法，每个实例的输出占一行。
Sample Input
1
2
Sample Output
3
8*/

#include <iostream>

using namespace std;

int _count = 0, N, i, b[5] = {0};

int dfs(int n)
{
	if (n == N - 1)
	{
		_count++;
		return 0;
	}
	for (i = 1; i < 4; i++)
	{
		if (i == 2)
		{
			if (n != 0)
			{
				if (b[n - 1] == -1)
					continue;
			}
		}
		if (i == 2)
		{
			b[n] = -1;
		}
		dfs(n + 1);
		if (i == 2)
		{
			b[n] = 0;
		}
	}
	return 0;
}

int main()
{
	ios::sync_with_stdio(false);
	cin.tie(0);

	cin >> N;
	dfs(0);
	cout << _count;

	return 0;
}