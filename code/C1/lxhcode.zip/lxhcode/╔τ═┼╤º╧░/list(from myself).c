#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <stdbool.h>
typedef struct S
{
	struct S *priv;
	struct S *next;
	int data;
} S;

typedef struct List
{
	int size;
	S *head;
	S *tail;
} List;

List *Head()
{
	List *h = (List *)malloc(sizeof(List));
	int size = 0;
	h->head = NULL;
	h->tail = NULL;
	return h;
}

void push_back(List *l, int value)
{
	S *b = (S *)malloc(sizeof(S));
	b->priv = NULL;
	b->next = NULL;
	b->data = value;
	if (l->size)
	{
		b->priv = l->tail;
		l->tail->next = b;
		l->tail = b;
	}
	else
	{
		l->tail = b;
		l->head = b;
	}
	l->size++;
}

void push_front(List *l, int value)
{
	S *f = (S *)malloc(sizeof(S));
	f->priv = NULL;
	f->next = NULL;
	f->data = value;
	if (l->size == 0)
	{
		push_back(l, value);
	}
	else
	{
		f->next = l->head;
		l->head = f;
		l->size++;
	}
}

void insert(List *l, int pos, int value)
{
	if (pos == 0)
	{
		push_front(l, value);
	}
	else if (pos == l->size)
	{
		push_back(l, value);
	}
	else
	{
		S *i = (S *)malloc(sizeof(S));
		i->data = value;
		i->next = NULL;
		i->priv = NULL;
		S *m = l->head;
		for (int j = 1; j < pos; j++)
		{
			m = m->next;
		}
		i->priv = m;
		i->next = m->next;
		m->next = i;
		i->next->priv = i;
		l->size++;
	}
}

void pop_back(List *l)
{
	if (l->size == 1)
	{
		free(l->head);
		l->head = NULL;
		l->tail = NULL;
		l->size--;
	}
	else if (l->size > 1)
	{
		l->tail = l->tail->priv;
		free(l->tail->next);
		l->tail->next = NULL;
		l->size--;
	}
}

void pop_front(List *l)
{
	if (l->size > 1)
	{
		l->head = l->head->next;
		free(l->head->priv);
		l->head->priv = NULL;
		l->size--;
	}
	else if (l->size == 1)
	{
		pop_back(l);
	}
}

void earse(List *l, int pos)
{
	if (pos == 0)
	{
		pop_front(l);
	}
	else if (pos == l->size - 1) //!!!!!!!
	{
		pop_back(l);
	}
	else if (pos > 0 && pos < l->size)
	{
		S *m = l->head;
		for (int i = 0; i < pos; i++)
		{
			m = m->next;
		}
		m->priv->next = m->next;
		m->next->priv = m->priv;
		free(m);
		l->size--;
	}
}

int get_value(List *l, int pos)
{
	S *m = l->head;
	for (int i = 0; i < pos; i++)
	{
		m = m->next;
	}
	return m->data;
}
int size(List *l)
{
	return l->size;
}

bool empty(List *l)
{
	// if(l->size==0)
	// {
	// 	return true;
	// }
	// else
	// {
	// 	return false;
	// }
	return l->size == 0;
}

void print(List *l)
{
	S *m = l->head;
	for (int i = 0; i < l->size; i++)
	{
		if (i != 0)
		{
			printf(" ");
		}
		printf("%d", m->data);
		m = m->next;
	}
	printf("\n");
}

void clear(List *l)
{
	S *m = l->head;
	for (int i = 0; i < l->size - 1; i++)
	{
		m = m->next;
		free(m->priv);
	}
	free(m);
	l->size = 0;
	l->head = NULL;
	l->tail = NULL;
}

void destroy(List *l)
{
	clear(l);
	free(l);
}

int main()
{
	char a[100];
	List *l;
	while (scanf("%s", a) != EOF)
	{
		if (strcmp(a, "init_list") == 0)
			l = Head();
		else if (strcmp(a, "push_back") == 0)
		{
			int value;
			scanf("%d", &value);
			push_back(l, value);
		}
		else if (strcmp(a, "push_front") == 0)
		{
			int value;
			scanf("%d", &value);
			push_front(l, value);
		}
		else if (strcmp(a, "insert") == 0)
		{
			int value, pos;
			scanf("%d%d", &pos, &value);
			insert(l, pos, value);
		}
		else if (strcmp(a, "erase") == 0)
		{
			int pos;
			scanf("%d", &pos);
			earse(l, pos);
		}
		else if (strcmp(a, "get_value") == 0)
		{
			int pos;
			scanf("%d", &pos);
			printf("%d\n", get_value(l, pos));
		}
		else if (strcmp(a, "size") == 0)
		{
			printf("%d\n", size(l));
		}
		else if (strcmp(a, "empty") == 0)
		{
			if (empty(l))
			{
				printf("true");
			}
			else
			{
				printf("false");
			}
			printf("\n");
		}
		else if (strcmp(a, "print") == 0)
		{
			print(l);
		}
		else if (strcmp(a, "clear") == 0)
		{
			clear(l);
		}
		else if (strcmp(a, "destroy") == 0)
		{
			destroy(l);
			printf("destroy");
			break;
		}
	}
	return 0;
}