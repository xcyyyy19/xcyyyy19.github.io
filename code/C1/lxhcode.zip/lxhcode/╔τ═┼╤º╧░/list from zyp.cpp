#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <math.h>
#include <stddef.h>

//Iterator迭代器
//byte字节
//datatype数据类型
//base基础

//DataType begin
typedef int8_t byte_type;
typedef size_t size_type;
typedef struct
{
	byte_type *base;
	size_type size;
} DataType;
void initData(DataType *datatype, size_t size)
{
	datatype->size = size;
	datatype->base = (byte_type *)malloc(size);
}

void setValue(DataType *datatype, const void *data)
{
	memcpy(datatype->base, data, datatype->size);
}

void *getValue(DataType *datatype)
{
	return datatype->base;
}

void destroyData(DataType *datatype)
{
	if (datatype->base)
		free(datatype->base);
}
//DataType end

//Node begin
typedef struct node
{
	struct node *previous;
	struct node *next;
	DataType data;
} Node;

typedef Node *Pointer;

void initNode(Pointer *P, size_t size)
{
	*P = (Pointer)malloc(sizeof(Node));
	(*P)->previous = NULL;
	(*P)->next = NULL;
	initData(&((*P)->data), size);
}

void setData(Pointer P, const void *others)
{
	setValue(&(P->data), others);
}

void *getData(Pointer P)
{
	return getValue(&(P->data));
}

void DestroyNode(Pointer P)
{
	destroyData(&((P)->data));
	free(P);
}
//Node end

//List begin
typedef struct
{
	Pointer header;
	Pointer tail;
	size_type len;
} Head;

typedef Head *List;

void initList(List *L)
{
	*L = (List)malloc(sizeof(Head));
	(*L)->header = NULL;
	(*L)->tail = NULL;
	(*L)->len = 0;
}

int empty(List L)
{
	return L->len == 0;
}

int size(List L)
{
	return L->len;
}

void insert_first_node(List L, const void *others, size_t size)
{
	Pointer newNode;
	initNode(&newNode, size);
	setData(newNode, others);

	L->header = newNode;
	L->tail = newNode;
	L->len = L->len + 1;
}

void push_back(List L, const void *others, size_t size)
{
	if (L->len == 0)
		insert_first_node(L, others, size);
	else
	{
		Pointer newNode;
		initNode(&newNode, size);
		setData(newNode, others);
		L->tail->next = newNode;
		newNode->previous = L->tail;
		L->tail = newNode;
		L->len = L->len + 1;
	}
}
void push_front(List L, const void *others, size_t size)
{
	if (L->len == 0)
		insert_first_node(L, others, size);
	else
	{
		Pointer newNode;
		initNode(&newNode, size);
		setData(newNode, others);
		L->header->previous = newNode;
		newNode->next = L->header;
		L->header = newNode;
		L->len = L->len + 1;
	}
}

void erase_last_node(List L)
{
	DestroyNode(L->header);
	L->header = NULL;
	L->tail = NULL;
	L->len = 0;
}

void pop_front(List L)
{
	if (L->len == 1)
		erase_last_node(L);
	else
	{
		L->header = L->header->next;
		DestroyNode(L->header->previous);
		L->header->previous = NULL;
		L->len = L->len - 1;
	}
}

void pop_back(List L)
{
	if (L->len == 1)
		erase_last_node(L);
	else
	{
		L->tail = L->tail->previous;
		DestroyNode(L->tail->next);
		L->tail->next = NULL;
		L->len = L->len - 1;
	}
}

void destoryList(List *L)
{
	while (!empty(*L))
		pop_back(*L);
	free(*L);
	*L = NULL;
}

//List End

//Iterator begin
typedef struct
{
	Pointer P;
} Iterator;

Iterator begin(List L)
{
	Iterator res;
	res.P = L->header;
	return res;
}

Iterator end(List L)
{
	Iterator res;
	res.P = NULL;
	return res;
}

Iterator getNext(Iterator iter)
{
	Iterator res;
	res.P = iter.P->next;
	return res;
}

Iterator getPrevious(Iterator iter)
{
	Iterator res;
	res.P = iter.P->previous;
	return res;
}

int equals(Iterator lsh, Iterator rsh)
{
	return lsh.P == rsh.P;
}

void *get(Iterator iter)
{
	return getData(iter.P);
}
//Iterator end

//Algorithm begin
void for_each(Iterator first, Iterator last, void (*function)(Iterator))
{
	while (!equals(first, last))
	{
		function(first);
		first = getNext(first);
	}
}
//Algorithm end

//User
//
void print(Iterator iter)
{
	printf("%d\n", *(int *)get(iter));
}

int main()
{
	List L;
	initList(&L);
	for (int j = 0; j != 10; j++)
		push_back(L, &j, sizeof(j));

	for_each(begin(L), end(L), print);

	for (int j = 0; j != 10; j++)
		pop_back(L);

	//    auto print = [](Iterator iter){
	//       printf("%d\n",*(int*)get(iter));
	//  }

	for_each(begin(L), end(L), print);

	destoryList(&L);
	return 0;
}
