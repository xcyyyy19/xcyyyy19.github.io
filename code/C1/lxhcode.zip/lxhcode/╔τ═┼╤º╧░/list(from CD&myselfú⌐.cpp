/*init_list   //表示建表  init(初始化)
push_back value   //表示向链表的尾部添加值value
push_front value   //表示向链表的首部添加值value
insert pos value    //表示向链表的pos位置插入值value(pos下标从零开始，既pos ＝ 0时表示链表的第一个元素)
erase pos    //表示删除链表在pos位置的元素(pos下标从0开始)
get_value pos     //打印链表在pos位置的元素的值
size     //打印链表的大小，占一行
empty     //若链表为空，打印true，不为空，打印false，占一行。
print     //遍历链表，打印链表中所有元素的值，每个值之间用空格间隔，占一行。
clear      //清空链表中的所有元素
destroy     //销毁链表，表示打印结束,输出destroy */
#include <cstdio>
#include <cstdlib>

struct S	  //typedef struct {
{			  //					struct S*next;
	int data; //				}S;
	S *next;  //c语言中类型别名要这样用，不能直接叫S。
	S *prev;  //previous先前的
};

struct List
{
	S *head;
	S *tail;
	int size;
};

List *Head() //开了个头节点叫h，此时他的两个指针都指向空，链表的长度为0；
{
	List *h = (List *)malloc(sizeof(List));
	h->head = NULL;
	h->tail = NULL;
	int size = 0;
	return h;
}

void push_back(List *l, int value)
{
	S *t = (S *)malloc(sizeof(S));
	t->data = value;
	t->prev = NULL;
	t->next = NULL;
	if (l->size)
	{
		l->tail->next = t;
		t->prev = l->tail;
		l->tail = t;
		++l->size;
	}
	else
	{
		l->head = t;
		l->tail = t;
		++l->size;
	}
}

void push_front(List *l, int value)
{
	S *nh = (S *)malloc(sizeof(S));
	nh->data = value;
	nh->next = NULL;
	nh->prev = NULL;
	if (l->size)
	{
		l->head->prev = nh;
		nh->next = l->head;
		l->head = nh;
		l->size++;
	}
	else
		push_back(l, value);
}

void insert(List *l, int pos, int value)
{
	S *i = (S *)malloc(sizeof(S));
	i->data = value;
	i->prev = NULL;
	i->next = NULL;
	if (pos == 0)
		push_front(l, value);
	else if (pos == l->size)
		push_back(l, value);
	else
	{
		S *p = l->head;
		for (int i = 1; i < pos; ++i)
		{
			p = p->next;
		}
		i->next = p->next;
		p->next->prev = i;
		p->next = i;
		i->prev = p;
		l->size++;
	}
}

void pop_back(List *l)
{
	if (l->size == 0)
		return;
	else if (l->size == 1)
	{
		free(l->head);
		l->head = NULL;
		l->tail = NULL;
		l->size = 0;
	}
	else
	{
		l->tail = l->tail->prev;
		free(l->tail->next);
		l->tail->next = NULL;
	}
	l->size--;
}

void pop_front(List *l)
{
	if (l->size < 2)
		pop_back(l);
	else
	{
		l->head = l->head->next;
		free(l->head->prev);
		l->head->prev = NULL;
		l->size--;
	}
}

void erase(List *l, int pos)
{
	if (pos == 0)
		pop_front(l);
	else if (pos + 1 == l->size)
		pop_back(l);
	else
	{
		S *p = l->head;
		for (int i = 0; i < pos; ++i)
			p = p->next;
		p->prev->next = p->next;
		p->next->prev = p->prev;
		free(p);
		l->size--;
	}
}

int main()
{

	return 0;
}