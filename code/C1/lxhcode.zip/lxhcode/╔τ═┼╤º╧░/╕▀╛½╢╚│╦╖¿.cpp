#include <iostream>
#include <cstring>

using namespace std;

int main()
{
	ios::sync_with_stdio(false);
	cin.tie(0);

	char a[1005], b[1005];
	scanf("%s%s", a, b);
	int lena = strlen(a);
	int lenb = strlen(b);
	for (int i = 0, j = lena - 1; i < lena; i++, j--)
	{
		
	}
		return 0;
}