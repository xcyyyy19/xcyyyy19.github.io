#include <cstdio>
#include <cstdlib>
#include <iostream>

using namespace std;

struct Node
{
	int key;
	Node *left;
	Node *right;
};

typedef Node *Pointer;

void init_Node(Pointer &p, int key)
{
	p = (Pointer)malloc(sizeof(Node));
	p->left = NULL;
	p->right = NULL;
	p->key = key;
}

struct Head
{
	size_t size;
	Node *root; //(根)
};
typedef Head *Tree;

void initTree(Tree &tree)
{
	tree = (Tree)malloc(sizeof(Head));
	tree->root = 0;
	tree->size = 0;
}

void insert(Tree &tree, int value)
{
	Pointer p;
	init_Node(p, value);
	while (tree->root->key != p->key)
	{
		if (tree->root->key > p->key)
		{
		}
		else
		{
		}
	}
}

void search(Tree &tree, int value)
{
}

int main()
{
	return 0;
}