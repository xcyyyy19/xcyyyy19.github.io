#include <iostream>

using namespace std;

int sum;

int dfs(int x, int y)
{
	int i, nx, ny;

	if (a[x][y] == 'e')
	{
		ans++;
		return 1;
	}

	char temp = a[x][y];
	a[x][y] = '1';
	for (i = 0; i < 4; i++)
	{
		nx = x + ;
		ny = y + ;
		if (nx < M && nx >= 0 && ny < N && nx >= 0 && (a[nx][ny] == '0' || a[nx][ny] == 'e'))
			dfs(nx, ny);
	}
	a[x][y] = temp;
	return 0;
}
int main()
{
	ios::sync_with_stdio(false);
	cin.tie(0);

	int M, N;
	cin >> M >> N;
	int a[M][N];
	for (int i = 0; i < N; i++)
	{
		for (int j = 0; j < M; j++)
		{
			cin >> a[i][j];
		}
	}
	int d[4][2] = {0, 1, 0, -1, -1, 0, 1, 0};
	return 0;
}
