/*【顺序结构】一年大约有3.156*10的7次方秒。编写一个程序，提示用户输入年龄，然后显示该年龄对应的秒数。(提示：使用 %g 来输出）
    例如：输入：19
          输出：599640000
    【测试数据有多组，每组输出结果后必须换行】*/
#include <stdio.h>
#include <math.h>

int main()
{
    int a;
    double b=3.156;
    scanf ("%d",&a);
    printf ("%.0lf\n",a*b*pow (10,7));

    return 0;
}