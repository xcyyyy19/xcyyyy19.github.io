/*【顺序结构】编写程序，输入两个整数，将它们的值互换后再输出。
例如：输入：12 5
      输出：5 12      
【测试数据有多组，每组输出结果后必须换行】*/
#include <stdio.h>

int main()
{
    int a,b;
    scanf ("%d%d",&a,&b);
    printf ("%d %d\n",b,a);

    return 0;
}