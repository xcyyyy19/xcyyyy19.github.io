/*顺序结构】编写程序，输入两个double类型数m，n（输入均不为0），分别计算并输出它们的 和、差、积、商的结果，
按顺序，每行显示一个值。
例如：输入：3.0 5.0
      输出：8.000000
            -2.000000
            15.000000
            0.600000           
【测试数据有多组，每组输出结果后必须换行】*/
#include <stdio.h>

int main()
{
    double m,n;
    scanf ("%lf%lf",&m,&n);
    printf ("%lf\n",m+n);
    printf ("%lf\n",m-n);
    printf ("%lf\n",m*n);
    printf ("%lf\n",m/n);
    return 0;
}