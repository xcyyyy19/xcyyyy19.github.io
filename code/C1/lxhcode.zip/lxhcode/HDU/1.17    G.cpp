/*数据的第一行有一个正整数T，表示测试的组数。接下来有T组测试。 
每组数据包括两行。 
第一行有两个正整数N K(0<N<1000,0<K<=N),分别表示成绩单上一共的学生数目，和Lele的学号. 
第二行有N个整数Xi（0<=Xi<=100）分别表示各个学生的成绩，以学号递增顺序给出，第一个学生学号为1。
Output
对于每组数据，请在一行里输出班里一共有多少个学生成绩高于Lele 
Sample Input
1
3 2
81 72 63 
Sample Output
1 
Hint
班级一共3人，LeLe的学号是2，三个学生的分数分别是81， 72和63，所以有一个人的分数比他的高*/
#include <iostream>
#include <algorithm>
using namespace std;

int main()
{
	ios::sync_with_stdio(false);
	cin.tie(0);

	int t, s[1000] = {0}, k;
	cin >> t;
	while (t--)
	{
		int all, le;
		cin >> all >> le;
		for (int j = 0; j < all; j++)
		{
			cin >> s[j];
			if (j + 1 == le)
			{
				k = s[j];
			}
		}
		sort(s, s + all);
		for (int i = 0; i < all; i++)
		{
			if (i == all - 1 && s[i] <= k)
			{
				cout << '0' << endl;
			}
			if (s[i] > k)
			{
				cout << all - i << endl;
				break;
			}
		}
	}
	return 0;
}