/*有一座山，周围有N个洞。这些孔是从0到n-1签名的。
兔子必须藏在一个洞里。一只狼逆时针顺序搜索兔子。他进的第一个洞是0号洞。
然后他每m洞都进洞。例如，M = 2，n = 6，狼将进入签字0,2,4,0的孔。
如果兔子藏在签署了1,3或5洞，她将生存。所以我们称这些洞为安全孔。
 
输入
输入以一个正整数p开头，它表示测试用例的数量。然后在下面的p行上，每一行包含2个正整数m和n（0＜m，n＜2147483648）。
 
输出
对于每个输入m n，如果存在安全漏洞，则应输出“是”，否则在一行输出“否”。*/
#include <iostream>

using namespace std;
int gcd(int m, int n)
{
	if (n == 0)
	{
		return m;
	}
	return gcd(n, m % n);
}
int main()
{
	ios::sync_with_stdio(false);
	cin.tie(0);

	int p;
	cin >> p;
	for (int i = 0; i < p; i++)
	{
		int m, n, a;
		cin >> m >> n;
		a = gcd(m, n);
		if (a == 1)
		{
			cout << "NO" << endl;
		}
		else
		{
			cout << "YES" << endl;
		}
	}
	return 0;
}