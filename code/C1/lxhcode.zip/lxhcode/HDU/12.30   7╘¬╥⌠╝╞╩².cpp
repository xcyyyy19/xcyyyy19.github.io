/*“元音计数字”（VCW）符合以下条件。
单词中的每个元音都必须是大写的。
每个辅音（除了元音之外的字母）都必须是小写的。
例如，“ApplE”是“apple”的VCW，“jUhUA”是“Juhua”的VCW。
给你一些话; 你的任务是获得每个单词的“元音计数单词”。
输入
输入的第一行包含一个整数T（T <= 20），这意味着测试用例的数量。
对于每种情况，都有一行包含单词（仅包含大写和小写）。 单词的长度不超过50。
产量
对于每种情况，输出它的元音计数字。
示例输入
4
XYZ
应用
qwcvb
aeioOa
示例输出
XYZ
应用
qwcvb
AEIOOA
tolower()
toupper()
*/
#include <iostream>

using namespace std;

int main()
{
	char a[50];
	int m;
	cin >> m;
	for (int p = 0; p < m; p++)
	{
		scanf("%s", a);
		for (int i = 0; a[i] != '\0'; i++)
		{
			if (a[i] == 'A' || a[i] == 'a' || a[i] == 'E' || a[i] == 'e' || a[i] == 'I' || a[i] == 'i' || a[i] == 'O' || a[i] == 'o' || a[i] == 'U' || a[i] == 'u')
			{
				if (a[i] == 'a' || a[i] == 'e' || a[i] == 'i' || a[i] == 'o' || a[i] == 'u')
				{
					a[i] = a[i] + 'A' - 'a';
				}
			}
			else if (a[i] > 'A' && a[i] <= 'Z')
			{
				a[i] = a[i] - 'A' + 'a';
			}
		}
		cout << a << endl;
	}

	return 0;
}
