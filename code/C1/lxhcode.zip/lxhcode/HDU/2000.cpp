/*输入三个字符后，按各字符的ASCII码从小到大的顺序输出这三个字符。
Input
输入数据有多组，每组占一行，有三个字符组成，之间无空格。
Output
对于每组输入数据，输出一行，字符中间用一个空格分开。
Sample Input
qwe
asd
zxc
Sample Output
e q w
a d s
c x z
Author
lcy*/
#include <iostream>

using namespace std;

int main()
{
	ios::sync_with_stdio(false);
	cin.tie(0);

	char a[10];
	while (scanf("%s", a) != EOF)
	{
		char max = a[0];
		if (max < a[1])
		{
			a[0] = a[1];
			a[1] = max;
			max = a[1];
		}
		if (a[2] >= a[0])
		{
			cout << a[1] << ' ' << a[0] << ' ' << a[2] << endl;
		}
		else if (a[2] >= a[1])
		{
			cout << a[1] << ' ' << a[2] << ' ' << a[0] << endl;
		}
		else
		{
			cout << a[2] << ' ' << a[1] << ' ' << a[0] << endl;
		}
	}
	return 0;
}