#include <iostream>

using namespace std;

int main()
{
	ios::sync_with_stdio(false);
	cin.tie(0);

	int p;
	cin >> p;
	for (int i = 0; i < p; i++)
	{
		int m, n, a;
		cin >> m >> n;
		if (m > n)
		{
			int t;
			t = m;
			m = n;
			n = t;
		}
		while (1)
		{
			a = m % n;
			if (a == 0 && n == 1)
			{
				cout << "NO" << endl;
				break;
			}
			if (a != 0)
			{
				m = n;
				n = a;
				continue;
			}
			else
			{
				cout << "YES" << endl;
				break;
			}
		}
	}
	return 0;
}