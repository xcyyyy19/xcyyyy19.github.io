/*给定一个日期，输出这个日期是该年的第几天。
Output
对于每组输入数据，输出一行，表示该日期是该年的第几天。
Sample Input
1985/1/20
2006/3/12
Sample Output
20
71*/
#include <iostream>
#include <cstdio>

using namespace std;

int main()
{
	int n, y, r, k = 0;
	while (scanf("%d/%d/%d", &n, &y, &r) != EOF)
	{
		k = 0;
		switch (y - 1)
		{
		case 11:
			k += 30;
		case 10:
			k += 31;
		case 9:
			k += 30;
		case 8:
			k += 31;
		case 7:
			k += 31;
		case 6:
			k += 30;
		case 5:
			k += 31;
		case 4:
			k += 30;
		case 3:
			k += 31;
		case 2:
			k += 28 + (n % 400 == 0 || (n % 100 != 0 && n % 4 == 0));
		case 1:
			k += 31;
		case 0:
			k += r;
		}
		cout << k << endl;
	}
	return 0;
}