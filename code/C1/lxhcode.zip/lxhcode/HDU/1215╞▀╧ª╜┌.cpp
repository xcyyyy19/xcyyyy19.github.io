/*数字N的因子就是所有比N小又能被N整除的所有正整数,如12的因子有1,2,3,4,6.
你想知道你的另一半吗?
Input
输入数据的第一行是一个数字T(1<=T<=500000),它表明测试数据的组数.然后是T组测试数据,每组测试数据只有一个数字N(1<=N<=500000).
Output
对于每组测试数据,请输出一个代表输入数据N的另一半的编号.
Sample Input
3
2
10
20
Sample Output
1
8
22*/
#include <iostream>
#include <cmath>

using namespace std;

int main()
{
	ios::sync_with_stdio(false);
	cin.tie(0);

	int n, num, flag = 0, sum = 0, a[500000] = {0}, m;
	cin >> n;
	m = sqrt(500000);
	while (n--)
	{
		cin >> num;
		for (int i = 2, j = 2; i < 500000; i--, j--)
		{
			while (j--)
			{
				if (i % j != 0)
				{
					continue;
				}
				else
				{
					flag = 1;
				}
			}
			if (flag == 0)
			{
				for (int k = i; k < 50000; k = k + k)
				{
					a[k] += i;
				}
			}
		}

		cout << a[num] << endl;
		sum = 0;
	}
	return 0;
}