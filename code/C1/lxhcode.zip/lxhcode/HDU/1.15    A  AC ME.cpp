
#include <iostream>
#include <cstring>

using namespace std;

int main()
{
	char a[1000000];
	while (gets(a))
	{
		int coun[26] = {0};
		int len = strlen(a);
		for (int i = 0; i < len; i++)
		{
			if (a[i] >= 'a' && a[i] <= 'z')
			{
				coun[a[i] - 'a']++;
			}
		}
		for (int j = 0; j < 26; j++)
		{
			cout << char('a' + j) << ':' << coun[j] << endl;
		}
		cout << endl;
	}
	return 0;
}