/*给定三个正整数A，B和C（A,B,C<=1000000），求A^B mod C的结果. 
希望各位都能体会到比赛中AC的快乐，绝对的量身定制，很高的待遇哟，呵呵... 
Input
输入数据首先包含一个正整数N,表示测试实例的个数，然后是N行数据，每行包括三个正整数A,B,C。 
Output
对每个测试实例请输出计算后的结果，每个实例的输出占一行。 
Sample Input
3
2 3 4
3 3 5
4 4 6 
Sample Output
0
2
4*/
#include <iostream>

using namespace std;

int main()
{
	ios::sync_with_stdio(false);
	cin.tie(0);

	unsigned long long n, a, b, c;
	for (int i = 0; i < n; i++)
	{
		cin >> a >> b >> c;
		cout << (b * (a % c) % c) << endl;
	}

	return 0;
}