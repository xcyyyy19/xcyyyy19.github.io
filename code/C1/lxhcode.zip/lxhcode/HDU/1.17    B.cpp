/*现在请你编程判断HDU的用地是凸多边形还是凹多边形呢？ 
Input
输入包含多组测试数据，每组数据占2行，首先一行是一个整数n，表示多边形顶点的个数，
然后一行是2×n个整数，表示逆时针顺序的n个顶点的坐标（xi,yi），n为0的时候结束输入。 
Output
对于每个测试实例，如果地块的形状为凸多边形，请输出“convex”,否则输出”concave”，每个实例的输出占一行。*/
#include <iostream>

using namespace std;

int main()
{
	ios::sync_with_stdio(false);
	cin.tie(0);

	int n, x1, y1, x2, y2, k, flag = 0, flag2 = 0;
	while (cin >> n && (n != 0))
	{
		k = n / 2;
		if (n % 2 != 0)
		{
			cin >> x1 >> y1;
			int a = x1, b = y1;
			while (k--)
			{
				cin >> x2 >> y2 >> x1 >> y1;
				if (flag == 0)
				{
					if (a * y1 - x1 * b < 0)
					{
						flag2 = 1;
						cout << "concave" << endl;
						break;
					}
				}
				if (k == 1)
				{
					if (x1 * b - a * y1 < 0)
					{
						flag2 = 1;
						cout << "concave" << endl;
						break;
					}
				}
				else if (x1 * y2 - x2 * y1 < 0)
				{
					flag2 = 1;
					cout << "concave" << endl;
					break;
				}
				flag = 1;
			}
			if (flag2 == 0)
			{
				cout << "convex" << endl;
			}
			else
			{
				flag2 = 0;
			}
		}
		else
		{
			while (k--)
			{
				cin >> x1 >> y1 >> x2 >> y2;
				if (x1 * y2 - x2 * y1 < 0)
				{
					flag = 1;
					cout << "concave" << endl;
					break;
				}
			}
			if (flag == 0)
			{
				cout << "convex" << endl;
			}
			else
			{
				flag = 0;
			}
		}
	}
	return 0;
}