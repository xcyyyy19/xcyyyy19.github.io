/*奇奇喜欢旅行。 有一天，她发现了一个神奇的灯，不幸的是，灯中的精灵并不那么友善。 琪琪必须回答一个问题，然后精灵会意识到她的一个梦想。
问题是：给你一个整数，你可以删除准确的m位。 左边的数字将形成一个新的整数。 你应该尽量减少。
你不允许改变的数字顺序。 现在你能帮助琪琪实现她的梦想吗？
输入
有几个测试用例。
每个测试用例都将包含一个给定的整数（最多可以包含1000个数字）和整数m（如果整数包含n个数字，则m不会大于n）。 给定的整数将不包含前导零。
产量
对于每种情况，输出可以在一行中获得的最小结果。
如果结果包含前导零，则忽略它。
示例输入
178543 4
1000001 1
100001 2
12345 2
54321 2
示例输出
13
1
0
123
321*/
#include <iostream>
#include <algorithm>

using namespace std;

int main()
{
	ios::sync_with_stdio(false);
	cin.tie(0);
	int n;
	char a[1000];
	while (scanf("%s", a))
	{
		cin >> n;
		char b[1000] = {0};
		int len = strlen(a);
		for (int k = 0; k < len; k++)
		{
			b[k] = a[k];
		}
		sort(b, b + len, less<char>());
		for (int i = 0; i < n; i++, n--)
		{
			b[len - n] = 0;
		}
		for (int j = 0; j < len; j++)
		{
			for (int i = 0; i < len - n; i++)
		}
		cout << a << endl;
	}
	return 0;
}