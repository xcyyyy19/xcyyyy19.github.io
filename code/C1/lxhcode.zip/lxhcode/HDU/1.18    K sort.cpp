/*给你n个整数，请按从大到小的顺序输出其中前m大的数。 
Input
每组测试数据有两行，第一行有两个数n,m(0<n,m<1000000)，第二行包含n个各不相同，且都处于区间[-500000,500000]的整数。 
Output
对每组测试数据按从大到小的顺序输出前m大的数。 
Sample Input
 5 3
3 -35 92 213 -644 
Sample Output
 213 92 3 */
#include <iostream>
#include <algorithm>
#include <functional>
using namespace std;
int main()
{
	ios::sync_with_stdio(false);
	cin.tie(0);
	int *a = (int *)malloc(sizeof(int) * 1000000);
	int n, m;
	while (cin >> n >> m)
	{
		for (int i = 0; i < n; i++)
		{
			cin >> a[i];
		}
		sort(a, a + n, greater<int>());
		for (int j = 0; j < m; j++)
		{
			if (j != 0)
			{
				cout << ' ';
			}
			cout << a[j];
		}
		cout << endl;
	}
	return 0;
}
