/*
3
Manchester VS Portsmouth 3:0
Liverpool VS Manchester 1:1
Liverpool VS Portsmouth 0:0
Portsmouth VS Manchester 1:1
Manchester VS Liverpool 2:1
Liverpool VS Portsmouth 1:2 
  
Sample Output
Manchester 8
Portsmouth 5
Liverpool 2 */
#include <iostream>

using namespace std;

int main()
{
	ios::sync_with_stdio(false);
	cin.tie(0);

	int n;
	cin >> n;
	int m = n * (n - 1);
	while(m--)
	{
		
	}
	return 0;
}