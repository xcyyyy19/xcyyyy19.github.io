#include <iostream>

using namespace std;

int main()
{
	ios::sync_with_stdio(false);
	cin.tie(0);

	int n;
	while (cin >> n)
	{
		cout << n * n * n * (n * n * n - 1) / 2 - n * n * (n - 1) * 3 << endl;
	}

	return 0;
}