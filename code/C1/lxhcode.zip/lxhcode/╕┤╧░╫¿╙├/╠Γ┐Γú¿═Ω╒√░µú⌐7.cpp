/*【if语句】编写程序，从键盘上输入三角形的三边a,b,c，判断能否构成三角形，若能，计算并输出该三角形面积，若不能，则提示：不能构成三角形。
提示：假设有一个三角形，边长分别为a、b、c，三角形的面积S可由以下公式求得： S=sqrt(p(p-a)(p-b)(p-c)),而公式里的p为半周长： p=(a+b+c)/2。
例如：输入：3 1 1
      输出：不能构成三角形
      输入：3 4 5
      输出：6.00
【测试数据有多组，每组输出结果后必须换行】*/
#include <iostream>
#include <cmath>
using namespace std;

int main()
{
	ios::sync_with_stdio(false);
	cin.tie(0);
	double a, b, c;
	cin >> a >> b >> c;
	if (a >= b) //a>=b>=c
	{
		int t = 0;
		a = t;
		b = a;
		t = b;
	}
	if (b >= c)
	{
		int t = 0;
		b = t;
		c = b;
		t = c;
	}
	if (b + a >= c)
	{
		printf("%.2lf\n", sqrt(((a + b + c) / 2) * ((a + b + c) / 2 - a) * ((a + b + c) / 2 - b) * ((a + b + c) / 2 - c)));
	}
	else
		cout << "不能构成三角形" << endl;
	return 0;
}
