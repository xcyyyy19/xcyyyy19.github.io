/*【顺序结构】编写程序，输入两个数字字符，计算它俩对应的整数值的和及积，每行显示一个结果。
例如：输入：45
      输出：9
            20
【测试数据有多组，每组输出结果后必须换行】*/
#include <iostream>

using namespace std;

int main()
{
	ios::sync_with_stdio(false);
	cin.tie(0);

	char a = 0, b = 0;
	scanf("%c%c", &a, &b);
	int A = a - '0';
	int B = b - '0';
	printf("%d\n%d\n", A + B, A * B);
	return 0;
}