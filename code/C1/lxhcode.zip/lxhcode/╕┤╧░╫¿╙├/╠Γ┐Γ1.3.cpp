/*【if语句】编写程序，输入一个年份，判断该年是否为闰年，若是，输出“Yes”，若不是，输出“No”。
【提示】闰年的判断条件：年份满足以下两个条件之一即是闰年：
（1）能被400整除；（2）能被4整除，但不能被100整除。
例如：输入：2016
      输出：Yes
 【测试数据有多组，每组输出结果后必须换行】*/

#include <iostream>

using namespace std;

bool judge(int year)
{
	if ((year % 400 == 0) || (year % 4 == 0 && year % 100 != 0))
		return 1;
	else
		return 0;
}

int main()
{
	ios::sync_with_stdio(false);
	cin.tie(0);
	int year;
	cin >> year;
	if (judge(year))
		cout << "Yes" << endl;
	else
		cout << "No" << endl;

	return 0;
}