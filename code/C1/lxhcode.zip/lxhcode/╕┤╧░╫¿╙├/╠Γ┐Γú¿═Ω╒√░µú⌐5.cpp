/*【顺序结构】编写一个程序，把用秒表示的时间转换成用小时、分钟和秒表示的时间。
例如：输入：5000
      输出：1小时23分20秒
【测试数据有多组，每组输出结果后必须换行】*/
#include <iostream>

using namespace std;

int main()
{
	ios::sync_with_stdio(false);
	cin.tie(0);
	int s;
	cin >> s;
	int h = s / 3600;
	int min = s / 60 - h * 60;
	int ss = s % 60;
	printf("%d小时%d分%d秒\n", h, min, ss);
	return 0;
}