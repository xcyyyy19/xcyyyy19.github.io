/*【单循环】Fibonacci数列为：
1   1   2   3   5   8   13   21   34   55   …
编写程序， 输入一个正整数n，输出该数列前n项的和。
例如：输入：4
      输出：7
【测试数据有多组，每组输出结果后必须换行】*/
#include <iostream>

using namespace std;

int main()
{
	ios::sync_with_stdio(false);
	cin.tie(0);

	int a[100], i, n, sum;
	a[0] = 1;
	a[1] = 1;
	sum = 2;
	cin >> n;
	for (i = 2; i < n; i++)
	{
		a[i] = a[i - 1] + a[i - 2];
		sum += a[i];
	}
	printf("%d\n", sum);
	return 0;
}