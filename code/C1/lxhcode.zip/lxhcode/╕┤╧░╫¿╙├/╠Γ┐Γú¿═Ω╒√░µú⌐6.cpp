/*【顺序结构】大连东联路从联合路入口到南关岭出口全长11.3公里，全程限速70公里/小时。编写程序，输入要行驶的里程数，
计算在东联路上最短的行驶时间是多少分钟多少秒？
例如：输入：11.3
      输出：9分41秒
【测试数据有多组，每组输出结果后必须换行】*/
#include <iostream>

using namespace std;

int main()
{
	ios::sync_with_stdio(false);
	cin.tie(0);

	double v = 70.0 / 3600, m = 0, min = 0, s = 0;
	cin >> v;
	m = 11.3 / v;
	min = m / 60;
	s = m - min * 60;
	cout << min << "分钟" << s << "秒" << endl;
	return 0;
}