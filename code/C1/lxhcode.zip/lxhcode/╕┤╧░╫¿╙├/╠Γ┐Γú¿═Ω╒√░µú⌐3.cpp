/*【顺序结构】编写程序，输入一个人的身高（以厘米为单位）和体重（以公斤为单位），计算其标准体重
（公式：标准体重（单位：公斤）=（身高（单位：厘米）-100）*0.9 ）；再计算其体重BMI值
（公式：bmi = 体重 / (身高（以米为单位）的平方) ）。输出形式：分两行，第一行先输出 体重，
紧跟着再输出 标准体重， 第二行输出 BMI 值。
例如：输入：175.3  69.2
      输出：69.200 67.770 
            22.5
【测试数据有多组，每组输出结果后必须换行】*/
#include <iostream>

using namespace std;

int main()
{
	ios::sync_with_stdio(false);
	cin.tie(0);

	double a = 0, b = 0;
	scanf("%lf%lf", &a, &b);
	double bztz = (a - 100) * 0.9;
	double bmi = b * 10000 / (a * a);
	printf("%.3lf\n%.3lf\n%.1lf\n", b, bztz, bmi);
	return 0;
}