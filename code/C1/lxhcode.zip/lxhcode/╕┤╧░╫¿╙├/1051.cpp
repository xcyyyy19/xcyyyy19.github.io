#include <stdio.h>
#include <string.h>

int main()
{ //用得到前面的数的时候再开数组！！！！！！！！
	int i;
	char a[4] = {0}, b[100];
	gets(b);
	int len = strlen(b);
	//scanf("%s", b);
	for (i = 0; i < len; i++)
	{
		if (('a' <= b[i] && b[i] <= 'z') || ('A' <= b[i] && b[i] <= 'Z'))
			++a[0];
		else if ('0' <= b[i] && b[i] <= '9')
			++a[1];
		else if (b[i] == ' ')
			++a[2];
		else
			++a[3];
	}
	printf("%c", a[i]);

	return 0;
}