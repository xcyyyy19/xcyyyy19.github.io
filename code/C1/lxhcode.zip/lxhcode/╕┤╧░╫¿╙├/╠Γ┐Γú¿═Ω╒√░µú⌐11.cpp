/*【单循环】编写程序，循环输入一对浮点数，打印两数之差除以两数之和的结果（一行一个结果）。输入两个数均为0时，程序停止。
例如：输入：1 4
      输出：-0.600000
【测试数据有多组，每组输出结果后必须换行】*/
#include <iostream>

using namespace std;

int main()
{
	ios::sync_with_stdio(false);
	cin.tie(0);
	double x, y;
	scanf("%lf%lf", &x, &y);
	while (x || y)
	{
		
	}

	return 0;
}