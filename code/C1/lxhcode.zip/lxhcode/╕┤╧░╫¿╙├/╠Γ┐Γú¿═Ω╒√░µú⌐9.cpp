/*【单循环】编写程序，输入一个极小值e，用公式 π/4 = 1 - 1/3 + 1/5 - 1/7 + … ,求π的近似值，
直到最后一项的绝对值小于e为止。输出保留10位小数。
例如：输入：0.0000001
      输出：3.1415928536
【测试数据有多组，每组输出结果后必须换行】*/
#include <iostream>

using namespace std;

int main()
{
	ios::sync_with_stdio(false);
	cin.tie(0);

	double e, sum, n, i;
	cin >> e;
	while (1)
	{

		if ((1.0 / i) < e)
		{
			break;
		}
		i = -i;
	}
	sum *= 4;
	return 0;
}