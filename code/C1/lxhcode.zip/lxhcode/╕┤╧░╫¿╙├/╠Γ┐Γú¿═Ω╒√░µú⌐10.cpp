/*【单循环】编写程序，输入整型数m（偶数），计算如下
      公式的值：y=1.0/2!+1.0/4!+…+1.0/m!（m是偶数），结果保留10位小数。
例如：输入：2
      输出：0.5000000000
【测试数据有多组，每组输出结果后必须换行】*/
#include <iostream>

using namespace std;

int main()
{
	ios::sync_with_stdio(false);
	cin.tie(0);
	int m, i;
	double n = 0, y = 0;
	cin >> m;
	for (i = 2; i <= m; i = i + 2)
	{
		n = 1.0 / i;
		y += n;
	}
	printf("%.10lf\n", y);
	return 0;
}
