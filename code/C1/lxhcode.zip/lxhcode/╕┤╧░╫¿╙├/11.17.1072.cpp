/*写一函数，将两个字符串中的元音字母复制到另一个字符串，然后输出。
Input
一行字符串
Output
顺序输出其中的元音字母（aeiuo）
Sample Input
abcde
Sample Output
ae*/
#include <iostream>
#include <string>

using namespace std;

int main()
{
	ios::sync_with_stdio(false);
	cin.tie(0);

	string a, b;
	getline(cin, a);
	for (int i = 0; i < a.size(); i++)
	{
		if (a[i] == 'a' || a[i] == 'e' || a[i] == 'i' || a[i] == 'o' || a[i] == 'u')
		{
			b.push_back(a[i]); //pushback(b);
		}
	}
	cout << b << endl;
	return 0;
}