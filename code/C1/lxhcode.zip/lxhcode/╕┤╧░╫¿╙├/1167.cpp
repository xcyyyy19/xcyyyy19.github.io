/*编制函数，其功能是在float类型一维数组中查找最大值、最小值，并将它们返回到调用程序。
* 输出保留两位小数
Input
n
n个浮点数
Output
最大值 最小值
Sample Input
10
1.0
2.0
3.0
4.0
5.0
6.0
7.0
8.0
9.0
10.0
Sample Output
10.00 1.00*/
#include <iostream>

using namespace std;

int main()
{
	ios::sync_with_stdio(false);
	cin.tie(0);

	int n;
	double arr[1000];
	scanf("%d", &n);
	for (int i = 0; i < n; i++)
	{
		scanf("%lf", &arr[i]);
	}
	for (int i = 0; i < n; i++)
	{
		int min = i;
		for (int j = i + 1; j < n; j++)
		{
			if (arr[min] > arr[j])
			{
				min = j;
			}
		}
		double t = arr[min];
		arr[min] = arr[i];
		arr[i] = t;
	}

	printf("%.2lf %.2lf\n", arr[n - 1], arr[0]);

	return 0;
}