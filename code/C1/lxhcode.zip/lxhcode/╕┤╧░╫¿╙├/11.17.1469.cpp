/*花朵数是指一个n位数，它各个数位的n次方的和，恰等于此数。
例如 153 是3阶花朵数（水仙花数，水仙花有三瓣），54748是5阶花朵数（梅花数，梅花5瓣），548834是6阶花朵数（雪花数，雪花6瓣）
此题求各阶花朵数的个数
Input
整数n，表示数据个数，接下来的n行每行一个整数m，m小于7，大于0
Output
花朵数的个数
Sample Input
3
1
2
3
Sample Output
10
0
4*/
#include <iostream>
#include <cmath>

using namespace std;

int fun(int p,int n)
{
	int k = 0;
	while (p)
	{
		k = pow(p, n);
		p = p / 10;
	}
}

int main()
{
	ios::sync_with_stdio(false);
	cin.tie(0);

	int n;
	cin >> n;
	for (int i = 0; i < 1000000; i++)
	{
		if(fun(i,n))
		{
			
		}
	}
	return 0;
}