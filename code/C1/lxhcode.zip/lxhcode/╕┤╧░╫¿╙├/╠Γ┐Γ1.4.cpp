/*【if语句】编写程序，输入一个正整数，判断它能否被3、5、7整除，并输出下列信息之一：
（1）能同时被3、5、7整除；
（2）能被x和y整除；【注：x，y是3、5、7中的某两个值】
（3）只能被z整除；【注：z是3、5、7中的某一个值】
（4）不能被3、5、7中任一个整除
例如：输入：35
      输出：能被5和7整除
【测试数据有多组，每组输出结果后必须换行】*/

#include <iostream>

using namespace std;

/*bool f3(int a)
{
	if (a % 3 == 0 && a % 5 == 0 && a % 7 == 0)
		return true;
	return false;
}

bool f2(int b)
{
	if ((b % 3 == 0 && b % 5 == 0) || (b % 3 == 0 && b % 7 == 0) || (b % 5 == 0 && b % 7 == 0))
		return true;
	return false;
}

int f1(int a)
{
	if (a % 3 == 0 || a % 5 == 0 || a % 7 == 0)
		return true;
	return false;
}*/

void f(int x, bool *arr)
{
	arr[0] = arr[1] = arr[2] = false;
	if (x % 3 == 0)
		arr[0] = true;
	if (x % 5 == 0)
		arr[1] = true;
	if (x % 7 == 0)
		arr[2] = true;
}

int main()
{
	ios::sync_with_stdio(false);
	cin.tie(0);
	int X, a, b, c;
	cin >> X;
	bool arr[3];
	f(X, arr);
	int count = arr[0] + arr[1] + arr[2];
	if (count == 3)
		cout << "能同时被3、5、7整除" << endl;
	else if (count == 2)
	{
		if (!arr[0])
			cout << "能被5和7整除" << endl;
		else if (!arr[1])
			cout << "能被3和7整除" << endl;
		else
			cout << "能被3和5整除" << endl;
	}
	else if (count == 1)
	{
		if (arr[0])
			cout << "只能被3整除" << endl;
		else if (arr[1])
			cout << "只能被5整除" << endl;
		else
			cout << "只能被7整除" << endl;
	}
	else
		cout << "不能被3、5、7中任一个整除" << endl;

	return 0;
}