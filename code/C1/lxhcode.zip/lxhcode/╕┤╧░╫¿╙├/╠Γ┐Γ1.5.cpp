/*【if语句】某市不同品牌的出租车3公里的起步价和计费分别为：夏利7元，3公里以外2.1元/公里；富康8元，3公里以外2.4元/公里；桑塔纳9元，3公里以外2.7元/公里。
编写程序，输入乘车的车型（X代表夏利，F代表富康，S代表桑塔纳）及公里数，输出应付的车费（四舍五入到元）。【注：不考虑跳表问题】
例如：输入：F 6.5
      输出：16
【测试数据有多组，每组输出结果后必须换行】*/

#include <iostream>

using namespace std;

int main()
{
	ios::sync_with_stdio(false);
	cin.tie(0);
	char car;
	double km = 0, mon = 0;
	cin >> car >> km;
	if (car == 'X')
	{
		if (km <= 3)
			mon = km * 7;
		else
			mon = (km - 3) * 2.1 + 21;
		cout << mon << endl;
	}
	else if (car == 'F')
	{
		if (km <= 3)
			mon = km * 8;
		else
			mon = (km - 3) * 2.4 + 24;
		cout << mon << endl;
	}
	else if (car == 'S')
	{
		if (km <= 3)
			mon = km * 9;
		else
			mon = (km - 3) * 2.7 + 27;
		cout << mon << endl;
	}

	return 0;
}