/*[单循环] 编写程序，输入一个极小值e,用公式pi /4= 1- 1/3+ 1/5- 1/7
，求T 的近似值，直到最后一项的绝对值小于e为止。输出保留10位小数。
例如: 输入: 0.0000001
输出:3.1415927536
I测试数据有多组，每组输出结果后必须换行]*/

//输入了没有输出

#include <stdio.h>
#include <cmath>
#define PI 3.1415926535898
int main()
{
	int n = 1;
	double e, pi = 0;
	scanf("%lf",&e); 
	while(true)
	{
		pi += 1.0/n;
		if(n>0)
			n+=2;
		else
			n -= 2;
		n=-n;
		if (fabs(pi*4-PI) < e)
		break; 
	}
	pi = pi * 4;
	printf("%.10lf\n",pi);
	return 0;
}
