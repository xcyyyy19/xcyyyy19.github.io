/*【if语句】编写程序，计算以下分段函数的值，并将结果输出在屏幕上。

     X^2 + 2 X - 3  ( X>=30)
Y =  3X^2 - X^3     (-5 <= X < 30 )
     (X+5)^2 +4X +2 ( X<=-5 )
例如：输入：35.2 输出：1306.44
【测试数据有多组，每组输出结果后必须换行】*/
#include <iostream>
#include <cmath>

using namespace std;

double Y(double X)
{
      if (X >= 30)
            return pow(X, 2) + 2 * X - 3;
      else if (X >= -5)
            return 3 * pow(X, 2) - pow(X, 3);
      else
            return pow(X + 5, 2) + 4 * X + 2;
}

int main()
{
      ios::sync_with_stdio(false);
      cin.tie(0);

      double X;
      cin >> X;
      cout << Y(X) << endl;
      return 0;
}
