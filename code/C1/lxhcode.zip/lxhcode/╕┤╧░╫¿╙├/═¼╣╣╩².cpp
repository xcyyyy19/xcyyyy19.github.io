/*【单循环】编写程序，判断整数x是否是同构数。若是同构数，输出“Yes”；
      否则输出“No”。（假定输入时，x的值不大于100）
说明：所谓“同构数”是指这样的数，这个数出现在它的
      平方数的右边。例如：输入整数25，25的平方数是625，25是625中右侧的数，所
      以25是同构数。
例如：输入：25
      输出：Yes
【测试数据有多组，每组输出结果后必须换行】*/
#include <iostream>
#include <cmath>

using namespace std;

#include <iostream>

using namespace std;

int main()
{
	ios::sync_with_stdio(false);
	cin.tie(0);
	int x;
	cin >> x;
	while (x % 10 == 0)
	{
		if (x % 10 == x * x % 10)
			x = x % 10;
	}
	if (x % 10 != 0)
		cout << "Yes" << endl;
	else
		cout << "No" << endl;
	return 0;
}
/*int f(int i,int k)
{
	int n = i * i;
	while (i)
	{
		i = i / 10;
	}
	if(i=n%10)
		n = n % 10;
	for (k=1;k<7;k++) 
}

int main()
{
	ios::sync_with_stdio(false);
	cin.tie(0);

	int i, x, arr[100];
	cin >> x >>

		return 0;
}*/