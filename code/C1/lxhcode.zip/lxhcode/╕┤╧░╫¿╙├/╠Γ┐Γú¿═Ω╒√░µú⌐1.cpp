/*【顺序结构】编写程序，输入两个整数m，n（输入均不为0），分别计算并输出它们的 和、差、积、商和求余的结果，按顺序，每行显示一个值。
例如：输入：3 5
      输出：8
            -2
            15
            0.600000
            3
【测试数据有多组，每组输出结果后必须换行】*/
#include <iostream>

using namespace std;

int main()
{
	ios::sync_with_stdio(false);
	cin.tie(0);
	int m, n;
	cin >> m >> n;
	printf("%d%d%d%lf", m + n, m - n, m * n, m * 1.0 / n);

	return 0;
}