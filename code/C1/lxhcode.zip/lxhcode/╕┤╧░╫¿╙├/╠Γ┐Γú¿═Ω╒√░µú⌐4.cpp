/*【顺序结构】一年大约有3.156*10的7次方秒。编写一个程序，提示用户输入年龄，然后显示该年龄对应的秒数。(提示：使用 %g 来输出）
例如：输入：19
      输出：599640000
【测试数据有多组，每组输出结果后必须换行】*/
#include <iostream>
#include <cmath>
using namespace std;

int main()
{
	ios::sync_with_stdio(false);
	cin.tie(0);

	double age;
	cin >> age;
	age = age * 3.156 * pow(10, 7);
	cout << age << endl;

	return 0;
}