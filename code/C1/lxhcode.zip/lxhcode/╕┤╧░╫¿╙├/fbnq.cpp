/*有一分数序列： 2/1 3/2 5/3 8/5 13/8 21/13...... 求出这个数列的前N项之和，保留两位小数。
Input
N
Output
数列前N项和
Sample Input
10
Sample Output
16.48*/

// #include <iostream>

// using namespace std;

// int main()
// {
// 	ios::sync_with_stdio(false);
// 	cin.tie(0);

// 	int m = 1, z = 2, n;
// 	double sum = 0;
// 	cin >> n;
// 	for (int i = 0; i < n; i++)
// 	{
// 		sum += (z * 1.0) / m;
// 		int t = z;
// 		z = z + m;
// 		m = t;
// 	}
// 	printf("%.2lf", sum);

// 	return 0;
// }
#include <iostream>

using namespace std;
int main()
{
	ios::sync_with_stdio(false);
	cin.tie(0);

	int n, i, m = 0;
	double sum = 0;
	double a[10000];
	scanf("%d", &n);
	a[0] = 1;
	a[1] = 1;
	for (i = 2; i < n + 2; i++)
	{
		a[i] = a[i - 1] + a[i - 2];
		sum += a[i] * 1.0 / a[i - 1];
		cout << sum << endl;
	}

	return 0;
}