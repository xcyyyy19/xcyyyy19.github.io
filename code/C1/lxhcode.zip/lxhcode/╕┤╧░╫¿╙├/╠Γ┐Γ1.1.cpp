/*【顺序结构】从键盘上输入一个天数，将其转换成对应的年数、月数和天数（假设每年均为360天，每月均为30天）。
例如：输入：1000
      输出：2年9月10天
【测试数据有多组，每组输出结果后必须换行】*/
#include <stdio.h>

int main()
{

	/*int day, yea, mon;
	scanf("%d", &day);
	if (day >= 360)
	{
		yea = day / 360;
		day = day % 360;

		if (day >= 30)
		{
			mon = day / 30;
			day = day % 30;
			printf("%d年%d月%d天\n", yea, mon, day);
		}
		else
			printf("%d年%d天\n", yea, day);
	}
	else if (day >= 30)
	{
		mon = day / 30;
		day = day % 30;
		printf("%d月%d天\n", mon, day);
	}
	else
	{
		printf("%d天\n", day);
	}*/

	return 0;
}