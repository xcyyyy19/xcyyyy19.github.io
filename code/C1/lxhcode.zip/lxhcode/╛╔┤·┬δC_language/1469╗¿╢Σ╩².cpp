#include <stdio.h> 
#include <math.h>

 	int f(int i,int k);
	{
    	while(i)
    		{
        		sum=sum+pow(i%10,k);
        		i=i/10;
    		}
    	for (k=1;k<7;k++)
		printf ("%d\n",i);
		return sum;
	}











