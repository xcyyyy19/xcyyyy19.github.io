//如果有加入acm社团的同学 可能会用到排序。
//直接给大家上一个最简单的排序方法，用c++的STL

//使用C++ STL强大功能实现排序规则，  
//从小到大排序，比较函数设置为：less<数据类型>()
//从大到小排序，比较函数设置为：greater<数据类型>()

#include<stdio.h>
#include<iostream>
#include<algorithm>
using namespace std;

int main()
{
    int a[10]={9,6,3,0,5,2,7,4,1,8};
    for(int i=0;i<10;i++)
    {
        printf("%d ",a[i]);
    }
    printf("\n");
    sort(a,a+10,greater<int>());         //从大到小排序，从小到大则为less<int>
    for(int i=0;i<10;i++)
    {
        printf("%d ",a[i]);
    }
printf("\n");
    return 0;
}