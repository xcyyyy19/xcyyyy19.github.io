#include <stdio.h>
#include <string.h>

int main()
{
    int n;
    scanf("%d",&n);
    for(int i=2;i<=1000;++i)
    {
        int arr[i];
        memset(arr,0,sizeof(int)*i);
        int sum=0;
        for(int j=1;j<i;++j)
            if(i%j==0)
            {
                arr[j]=1;
                sum+=j;
            }
        if(sum==i)
        {
            printf("%d its factors are ",i);
            for(int j=1;j<i;++j)
                if(arr[j])
                    printf("%d ",j);
            printf("\n");
        }
    }

    return 0;
}