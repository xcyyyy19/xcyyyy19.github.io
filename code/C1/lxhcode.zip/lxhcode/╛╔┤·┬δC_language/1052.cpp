#include <stdio.h>


int main()
{
    int a;
    while(scanf("%d",&a)!=EOF)
    {
        printf("--%d\n",a);
    }
    printf("Over");

    return 0;
}