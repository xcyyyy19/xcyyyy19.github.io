int _strlen(char*arr)
{
    int i=-1;
    while(arr[++i]);
    return i;
}