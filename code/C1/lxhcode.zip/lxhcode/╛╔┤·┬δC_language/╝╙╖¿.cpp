# include <stdio.h>
int main () 
{
	int x,y,z;
	scanf ("%d%d", &y , &x);
	z=x+y;
	printf ("%d",z);
	return 0;
}
