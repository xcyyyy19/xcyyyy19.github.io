#include <stdio.h>
int main()
{
    int m,n,h,i;
    scanf("%d%d",&m,&n);
    for(i=1,i<=n;i++)
    {
        m/2;
        h+=m;
    }
    printf("%d",h);
    return 0;
}