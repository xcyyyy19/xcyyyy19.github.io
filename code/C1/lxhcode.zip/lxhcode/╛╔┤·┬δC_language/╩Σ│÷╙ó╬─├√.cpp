#include <iostream>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char** argv) 
{
	char cc[100];
	printf ("shuru name\n");
	scanf ("%s",cc);                 	//������Լ���ڵ�ַ num=&num[0] 
	printf ("my name is : %s\n",cc);
	return 0;
}
