#include <stdio.h>
#include <string.h>

int main()
{   
    int a=0,b=0,c=0,d=0,i;

    char arr[100];

    gets (arr);

    int len = strlen (arr);

    for (i=0;len>i;i++) 
    {
        if ('a'<=arr[i]&&'z'>=arr[i]||'Z'>=arr[i]&&'A'<=arr[i])
        {
            ++a;
        }
        else if (arr[i]>='0'&&arr[i]<='9')
        {
            ++b;
        }
        else if (arr[i]==' ')
        {
            ++c;
        }
        else
        {
            ++d;
        }
    }
    printf ("%d ",a);
    printf ("%d ",b); 
    printf ("%d ",c);
    printf ("%d",d);

    return 0;
}                                                                 
