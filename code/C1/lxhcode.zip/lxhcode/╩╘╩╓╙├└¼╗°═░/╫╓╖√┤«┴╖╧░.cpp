// #include <iostream>

// using namespace std;

// int main()
// {
// 	ios::sync_with_stdio(false);
// 	cin.tie(0);

// 	int sum = 0;
// 	char a[100];
// 	gets(a);
// 	for (int i = 0; a[i] != '\0'; i++)
// 	{
// 		if (a[i] >= 'A' && a[i] <= 'Z')
// 		{
// 			sum = sum + 1;
// 		}
// 	}
// 	cout << sum << endl;
// 	return 0;
// }
#include <iostream>

using namespace std;

int main()
{
	ios::sync_with_stdio(false);
	cin.tie(0);

	int flag = 0;
	char s[100];
	gets(s);
	int len = strlen(s);
	if (len % 2 == 0)
	{
		for (int i = len - 1, j = 0; i >= 0; i--, j++)
		{
			if (s[i] == s[j])
			{
				continue;
			}
			else
			{
				flag = 1;
			}
		}
	}

	return 0;
}