#include <stdio.h>
int main()
{
	char arr[3];
	int i=0;
	for (arr[i];i<3;++i)
		
}