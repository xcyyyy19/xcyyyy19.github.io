#include <iostream>

using namespace std;

int main()
{
	int flag=0;
	char a[100],b[100];
	gets(a);
	gets(b);
	for(int i = 0; a[i] != '\0'; i++)
	{
		if(a[i] != b[0])
		{
			flag = 1;
		}
		else
		{
			for(int k = 0 ; b[k] != '\0'; k++)
			{
				if(a[i] == b[k])
				{
					continue;
				}
				else
				{
					flag = 1;
				}
			}
		}
		if(flag==1)
		{
			printf("%c",a[i]);
		}
		flag=0;
	}


	return 0;
}