#include <iostream>

using namespace std;

/*int main()
{
	ios::sync_with_stdio(false);
	cin.tie(0);
	int a, b, c;
	cin >> a, b, c;
	if (a > b && a >= c)
		cout << a;
	else if (b >= a && b > c)
		cout << b;
	else if (c > a && c >= b)
		cout << c;

	return 0;
}*/

//更新女朋友的算法
int main()
{
	ios::sync_with_stdio(false);
	cin.tie(0);

	int a, b, c, max;
	cin >> a >> b >> c;
	int i, n;
	for (i = 0; i < 3; i++)
	{
		cin >> n;
		if (n > max)
			max = n;
	}
	cout << max;

	return 0;
}