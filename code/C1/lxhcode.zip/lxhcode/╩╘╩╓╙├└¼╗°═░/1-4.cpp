#include <iostream>

using namespace std;

void _dfs(int *arr, int n, int h)
{
}

void dfs(int n)
{
	int arr[n];
	_dfs(arr, n, 0);
}

int main()
{
	ios::sync_with_stdio(false);
	cin.tie(0);

	int n;
	cin >> n;
	dfs(n);

	return 0;
}