#include <stdio.h>
#include <math.h>

double fun(double a)
{
    double x=1.0;
    double y=1.0/2*(x+a/x);
    if(fabs(y-x)<0.00001)
    {
        x=y;
        y=1.0/2*(x+a/x);
    }
    return y;
}
 
int main()
{
	double a;
	scanf("%lf",&a);
	double b=fun(a);
    printf("%.3lf",b);
    return 0;
}