#include <iostream>

using namespace std;

int dfs(int n)
{
}

int main()
{
	ios::sync_with_stdio(false);
	cin.tie(0);

	int n;
	cin >> n;
	dfs(n);

	return 0;
}