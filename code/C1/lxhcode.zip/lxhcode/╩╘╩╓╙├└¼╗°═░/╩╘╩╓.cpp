/*********************************************************
【程序设计题】【题干】
【字符串】编写程序，输入一个字符串，判断该字符串是否回文。是回文，输出“Yes”， 

不是，则输出“No”。“回文”是指正读和倒读都一样的字符串。
例如：输入：12321
      输出：Yes
再如：输入：abcab
      输出：No
【测试数据有多组，每组输出结果后必须换行】
*********************************************************/

#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdlib.h>
#include <conio.h>


int main()
{
int b,j,i;
int gh=0;
char a[1000];
char c[1000];
gets(a);

b=strlen(a);
if(b%2==0)
{
 for(i=0;i<b/2;i++)
 {
  	c[i]=a[i];
 }	
 for(i=strlen(c)-1,j=b/2;j<b;i--,j++)
 {
 	if(c[i]!=a[j])
 	{
 	printf("No\n");
 	gh=1;
 	break;
 }
 }
}

else
{
   for(i=0;i<b/2;i++)
  {
  	c[i]=a[i];
  }	
   for(i=strlen(c)-1,j=b/2+1;j<b;i--,j++)
 {
 	if(c[i]!=a[j])
 	{
 	printf("No\n");
 	gh=1;
 	break;
 }
 }



}
if(gh==0)
{
printf("Yes\n");
}
}