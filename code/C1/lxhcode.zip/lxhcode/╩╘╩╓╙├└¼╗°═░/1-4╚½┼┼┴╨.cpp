#include <iostream>

using namespace std;

int a[4], b[5] = {0};

int dfs(int n)
{
	int i, j;
	if (n == 4)
	{
		for (j = 0; j < 4; j++)
		{
			printf("%d", a[j]);
		}
		printf("\n");
	}
	for (i = 1; i < 5; i++)
	{
		if (b[i] != -1)
		{
			a[n] = i;
			b[i] = -1;
			dfs(n + 1);
			a[n] = 0;
			b[i] = 0;
		}
	}
	return 0;
}

int main()
{
	ios::sync_with_stdio(false);
	cin.tie(0);

	int n = 0;
	dfs(n);

	return 0;
}