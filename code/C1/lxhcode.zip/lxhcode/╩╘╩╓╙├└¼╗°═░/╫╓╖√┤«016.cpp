#include <iostream>

using namespace std;

int main()
{
	ios::sync_with_stdio(false);
	cin.tie(0);

	char a[100];
	gets(a);
	int len = strlen(a);
	for (int i = 0; i < len; i++)
	{
		if ((a[i] >= 'A' && a[i] <= 'Z') || (a[i] >= 'a' && a[i] <= 'z'))
		{
			cout << a[i];
		}
	}
	cout << endl;
	return 0;
}