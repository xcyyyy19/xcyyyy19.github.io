#include <iostream>
#include <cmath>
using namespace std;

int main()
{
	ios::sync_with_stdio(false);
	cin.tie(0);

	int n;
	for(int i=1;i<=pow(1000,1/2);i++)
	{
		n=i*i;
		for(int j=0;j<1000;j++)
		{
			if()
		}
	}

	return 0;
}