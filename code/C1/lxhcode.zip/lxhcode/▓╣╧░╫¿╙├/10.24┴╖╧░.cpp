//函数指针
//swap函数
//strcat
//strcpy
//strcmp(a，b)(通过a与b每一位作差比较ab是否相等)
//strncmp(a,b,10)只比较前10个
//strlen
#include <stdio.h>
#include <string.h>

void swap(char *a, char *b) //返回值类型 函数名（参数列表）
{
	char temp;
	temp = *a, *a = *b, *b = temp;
}
int main()
{
	char arr[100] = {0}, m[100] = {0};
	int i = 0, j = 0;
	gets(arr);
	int len = strlen(arr);
	for (j = 0, i = len / 2; i < len; i++, j++)
	{
		m[i] = arr[i];
		m[j] = arr[j];
		if (strcmp(&arr[i], &arr[j]) != 0)
			swap(&arr[i], &arr[j]);
	}
	printf("%s", strcat(&arr[i], &m[j]));

	return 0;
}