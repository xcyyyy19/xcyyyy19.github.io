#include <iostream>

using namespace std;

// 编译的快捷键是 command + shift + B
// 格式化代码是 option + shift + F
// 运行程序不再是 ./a.exe, 而是 ./a.out
// 好像也没什么好讲的了，遇到问题再问我吧。
// 哦，对了，复制是 command + C, 粘贴是 command + V, 全选是 command + A
// 你就把 command 键当成 windows 下的 ctrl 键吧。
// 以上。

int main()
{
	ios::sync_with_stdio(false);
	cin.tie(0);

	cout << "Hello world!" << endl;

	return 0;
}
