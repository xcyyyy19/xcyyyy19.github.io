#include <stdio.h>
#include <stdlib.h>  // 包含rand函数，该函数可伪随机生成数据
#include <algorithm> // C++头文件，包含sort函数

using namespace std; // 命名空间，使 std::sort 可简写为 sort

void swap(int *x, int *y); // 函数声明

int main()
{
	int n;
	scanf("%d", &n);
	int arr[n];
	/*for (int i = 0; i < n; ++i)
	{
		scanf("%d", arr + i);
		// arr[i] = rand() % 100;// 随机生成数据
	}*/
	// 选择排序
	//************以下****************
	for (int i = 0; i < n; ++i)
	{
		int min = i;
		for (int j = i + 1; j < n; ++j) // 找到最小的
			min = arr[min] < arr[j] ? min : j;
		//swap(&arr[i], arr + min);
	}
	//**************以上**************
	// sort(arr, arr + n); // C++ STL库 排序函数
	for (int i = 0; i < n; ++i)
		printf("%d ", arr[i]);
	putchar(10); // '\n'的值为10
	return 0;
}

void swap(int *x, int *y) // 函数定义 (swap n.交换)
{
	int t;
	t = *x;
	*x = *y;
	*y = t;
}