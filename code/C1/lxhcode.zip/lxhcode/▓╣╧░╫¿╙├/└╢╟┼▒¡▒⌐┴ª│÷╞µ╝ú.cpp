#include <iostream>
#include <set>

#define For(i, a, b) for (int i = a; i <= b; ++i)
#define calc(a, b, c, d, e) (a * 10000 + b * 1000 + c * 100 + d * 10 + e)

using namespace std;

int judge(int a, int b, int c, int d, int e)
{
	set<int> s;
	s.insert(a);
	s.insert(b);
	s.insert(c);
	s.insert(d);
	s.insert(e);
	return s.size() == 5;
}

int main()
{
	ios::sync_with_stdio(false);
	cin.tie(0);

	For(a, 1, 9)
			For(b, 0, 9)
				For(c, 0, 9)
					For(d, 0, 9)
						For(e, 0, 9)
							For(k, 1, 9) if (judge(a, b, c, d, e)) if (calc(a, b, c, d, e) * k == calc(e, d, c, b, a))
								cout
		<< a << ' ' << b << ' ' << c << ' ' << d << ' ' << e << ' ' << k << endl;
	return 0;
}