#include<iostream>

using namespace std;

class myInt
{
	public:
		int x;
	myInt operator+(const myInt&b)const
	{
		myInt t;
		t.x=x+b.x;
		return t;
	}
};

int main()
{
	myInt a,b;
	a.x=1;
	b.x=2;
	cout<<(a+b).x<<endl;
	cout<<a.operator+(b).x<<endl;

	return 0;
}