//有负数不能用桶排，数学上的取模只有整数，计算机不是
//十进制下开了十个桶，同理，二进制判断01就行

#include <iostream>
#include <queue>

using namespace std;

int main()
{
	ios::sync_with_stdio(false);
	cin.tie(0);

	int n;
	cin >> n; //n为数据范围最大值
	int a[5]; //就排5个试试
	for (int i = 0; i < 5; i++)
	{
		cin >> a[i];
	}
	queue<int> tong[10];			 //因为先进先出符合队列，所以桶直接开成队列形式
	for (int k = 1; k <= n; k *= 10) //k用来表示位数
	{
		for (int i = 0; i < 5; i++)
		{
			tong[a[i] / k % 10].push(a[i]);
		}
		int j = 0;
		for (int i = 0; i < 10; i++)
		{
			while (tong[i].size()) //当桶里还有东西的时候，防止非法访问
			{
				a[j++] = tong[i].front(); //访问桶里的首元素，就是最先放进桶的那个，给丢回a【】中
				tong[i].pop();
			}
		}
	}
	for (int i = 0; i < 5; i++)
	{
		cout << a[i] << ' ';
	}
}