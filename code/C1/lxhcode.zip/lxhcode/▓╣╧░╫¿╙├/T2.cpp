// 保证输入的数字数位有偶数个，且在int的范围内，
// 请将数字的前半部分与后半部分交换后，开根号输出，保留2位小数。
// input:
// 123456
// output:
// 675.37
#include <stdio.h>
#include <math.h>
#include <string.h>

void swap(char *i, char *j)
{
	char temp;
	temp = *i;
	*i = *j;
	*j = temp;
}

long long Atoi(char *arr)
{
	long long sum = 0, i = 0;
	while (arr[i])
	{
		sum *= 10;
		sum += arr[i] - '0';
		i++;
	}
	return sum;
}

int main()
{
	char arr[50];
	gets(arr);
	int len = strlen(arr);
	for (int i = 0, j = len / 2; i < len / 2; i++, j++)
		swap(&arr[i], &arr[j]);
	long long x = Atoi(arr);
	printf("%.2lf\n", sqrt(x));
	return 0;
}