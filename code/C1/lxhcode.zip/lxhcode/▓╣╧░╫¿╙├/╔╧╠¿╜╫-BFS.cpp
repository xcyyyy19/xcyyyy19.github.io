//push将元素入队
//fornt读取队首元素
//pop删除队首元素
#include <iostream>
#include <queue>

using namespace std;

int main()
{
	queue<int> q; // 定义一个队列 q, 存储 int 类型数据
	q.push(20);   // 将 20 入队
	int count = 0;
	while (q.size()) // q.size() 即队列中元素个数
	{
		int t = q.front();
		q.pop();
		for (int i = 1; i <= 3; ++i)
		{
			int n = t - i;
			if (n > 0)
				q.push(n);
			else if (n == 0)
				++count;
		}
	}
	cout << count << endl;
	return 0;
}