#include <iostream>

using namespace std;

int main()
{
	ios::sync_with_stdio(false);
	cin.tie(0);
	int a[1000];
	int i = 0, n = 0;
	a[1] = 1;
	a[0] = 1;

	cin >> n;

	for (i = 1; i < n; i++)
	{
		if (i < 2)
			cout << a[0] << endl
				 << a[1] << endl;

		else
		{
			a[i] = a[i - 1] + a[i - 2];
			cout << a[i] << endl;
		}
	}

	return 0;
}