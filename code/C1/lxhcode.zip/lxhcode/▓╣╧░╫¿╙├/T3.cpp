// lzy曾经说过，冒泡排序算法就算是脑子冒泡的人都应该会写，
// 那么，为了证明你比脑子冒泡的人强一点，请你写一个排序算法。
// 这些数据中会有重复的数字，请你去重并排降序。
// input:
// 10
// 1 1 2 2 3 3 4 5 6 6
// output:
// 6 5 4 3 2 1
#include <iostream>
#include <algorithm>

using namespace std;

int main()
{
	ios::sync_with_stdio(false);
	cin.tie(0);

	int arr[50];
	int n = 0, i = 0;
	while (scanf("%d", &arr[n]) != EOF)
		++n;
	sort(arr, arr + n, greater<int>());
	cout << arr[0] << ' ';
	for (i = 1; i < n; i++)
		if (arr[i] != arr[i - 1])
			cout << arr[i] << ' ';
	return 0;
}