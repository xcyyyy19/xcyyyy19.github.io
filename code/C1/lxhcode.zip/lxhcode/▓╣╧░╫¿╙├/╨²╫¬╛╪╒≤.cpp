#include <iostream>
#include <cstdio>

using namespace std;

int main()
{
	int dx[4] = {+0, +1, +0, -1};
	int dy[4] = {+1, +0, -1, +0};

	int k, n;
	cin >> k >> n;
	cout << k << endl;
	int n2 = n * n;
	int x = 0, y = 0;
	int arr[n][n];
	int dir = 0;
	memset(arr, 0, sizeof(int) * n * n);
	for (int i = 1; i <= n2; ++i)
	{
		arr[x][y] = i;
		int nx = x + dx[dir], ny = y + dy[dir];
		if (nx < 0 || nx >= n || ny < 0 || ny >= n || arr[nx][ny])
		{
			dir = (dir + 1) % 4;
			nx = x + dx[dir];
			ny = y + dy[dir];
		}
		x = nx;
		y = ny;
	}
	for (int i = 0; i < n; ++i)
	{
		if (i != 0)
		{
			printf(" ");
		}
		for (int j = 0; j < n; ++j)
		{
			printf("%d", arr[j][i]);
		}
		cout << endl;
	}

	return 0;
}