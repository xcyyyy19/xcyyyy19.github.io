#include <iostream>
#include <string.h>

using namespace std;

void swap(char *a, char *b)
{
	char t;
	t = *a, *a = *b, *b = t;
}
int main()
{
	char arr[100], m[100];
	gets(arr);
	int len = strlen(arr);
	int i, j;
	for (i = 0, j = len / 2; j < len; i++, j++)
		m[i] = arr[j];
	arr[len / 2] = 0;
	m[i] = 0;
	len /= 2;
	if (strcmp(arr, m) != 0)
		for (int i = 0; i < len; ++i)
			swap(arr + i, m + i);
	strcat(arr, m);
	printf("%s", arr);
	return 0;
}
