#include<iostream>

using namespace std;

struct Student
{
	long long number;
	char name[100];
	char from[100];
	int math;
	int english;
	int c;
};

int main()
{
	struct Student x;
	x.c=1;
	x.english=2;
	cin>>x.number;
	struct Student y;
	y=x;
	cout<<y.english;
	struct Student* p;
	p=&x;
	p->c = p->english;//	(*p).c
	int i;
	return 0;
}