#include <iostream>

using namespace std;

int main()
{
	int n;
	cin >> n;
	int arr[n][n];
	memset(arr, 0, sizeof(int) * n * n);
	for (int i = 0; i < n; ++i) // 将第一列初始化为 1
		arr[i][0] = 1;
	for (int i = 1; i < n; ++i)							   // 从 1 开始, 因为第 0 行不需要计算
		for (int j = 1; j <= i; ++j)					   // 从 1 开始, 因为第一列不需要也不可以计算, 循环 j + 1 次, 因为第 i 行有 i + 1 个数字
			arr[i][j] = arr[i - 1][j - 1] + arr[i - 1][j]; // 每个数字等于其左上角与正上方数字之和
	for (int i = 0; i < n; ++i)							   // 打印第 i 行
	{
		for (int j = 0; j <= i; ++j) // 循环 j + 1 次, 因为第 i 行有 i + 1 个数字
			printf("%-4d", arr[i][j]);
		putchar(10);
	}

	return 0;
}