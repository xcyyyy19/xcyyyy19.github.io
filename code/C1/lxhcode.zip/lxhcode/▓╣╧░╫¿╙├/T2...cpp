// 保证输入的数字数位有偶数个，且在int的范围内，
// 请将数字的前半部分与后半部分交换后，开根号输出，保留2位小数。
// input:
// 123456
// output:
// 675.37
#include <iostream>

using namespace std;




int main()
{
	ios::sync_with_stdio(false);
	cin.tie(0);
	char arr[100];
	gets(arr);
	int len = strlen(arr);
	for (int i = 0, j = len / 2; i < len / 2;i++,j++)
	{
		if(arr[i]!=arr[j])
		swap(arr[i], arr[j]);
		
	}

	return 0;
}