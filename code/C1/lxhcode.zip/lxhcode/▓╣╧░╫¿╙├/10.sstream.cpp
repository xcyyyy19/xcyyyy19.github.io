#include <iostream>
#include <string>
#include <sstream> // stringstream 所在的头文件

using namespace std;

int main()
{
	ios::sync_with_stdio(false);
	cin.tie(0);

	// ********************构造 一
	stringstream ss1("123"); // stringstream 的构造函数之一，通过这种方式构造一个为"123"的字符串流
	int x1;
	ss1 >> x1;			// 使用方式与 cin 相同
	cout << x1 << endl; // 输出检验一下，为 123

	// ********************构造 二
	string s2 = "456";
	stringstream ss2(s2); // 构造一个为 s 的字符串流，本质与上一个相同
	int x2;
	ss2 >> x2;
	cout << x2 << endl; // 输出检验一下，为 456

	// ********************构造 三
	string s3 = "789";
	stringstream ss3; // 构造一个空的字符串流
	ss3 << s3;		  // 将字符串 s 导入 ss3
	int x3;
	ss3 >> x3;
	cout << x3 << endl; // 输出检验一下，为 456

	// 划重点的是，使用 stringstream 和使用 cin 可以说是一模一样的
	// 所以，使用 cin 的技巧在 stringstream 上也是可行的
	// 可以认为，它们的唯一不同就是数据来源
	// cin 的数据来源为键盘输入，而 stringstream 的数据来源为字符串

	// 下面举个例子
	stringstream ss4("1 23 456 7890"); // 可以理解为在程序运行时输入了这些内容，用 cin 是怎样的，用字符串流也是怎样的
	int x4;
	while (ss4 >> x4) // 因为使用起来是一样的，所以可以通过这种方式一直读取直到字符串流为空
	{
		cout << x4 << endl;
	}

	return 0;
}