#include <stdio.h>

int main()
{
	char arr[100];
	gets(arr);
	fgets(arr, sizeof(char) * 100, stdin);
	printf("%s", arr);

	return 0;
}