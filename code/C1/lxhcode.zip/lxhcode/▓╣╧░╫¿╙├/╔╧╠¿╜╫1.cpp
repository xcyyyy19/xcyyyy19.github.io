/*20个台阶，每次走一个，两个，三个台阶*/
#include <iostream>

using namespace std;

int main()
{
	ios::sync_with_stdio(false);
	cin.tie(0);

	int a[40] = {1, 1, 2, 4};
	for (int i = 4; i <= 20; i++)
	{
		a[i] = a[i - 1] + a[i - 2] + a[i - 3];
	}
	printf("%d", a[20]);
	return 0;
}