#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdbool.h>

void get_prime(bool *arr, int n)
{
	memset(arr, true, sizeof(bool) * n);
	arr[0] = arr[1] = false;
	int s = sqrt(n);
	for (int i = 2; i <= s; ++i)
		if (arr[i])
			for (int j = i * i; j < n; j += i)
				arr[j] = false;
}

int main(void)
{
	bool arr[100];
	get_prime(arr, 100);
	for (int i = 0; i < 100; ++i)
		printf("%3d %s 素数\n", i, arr[i] ? "  是" : "不是");

	return 0;
}