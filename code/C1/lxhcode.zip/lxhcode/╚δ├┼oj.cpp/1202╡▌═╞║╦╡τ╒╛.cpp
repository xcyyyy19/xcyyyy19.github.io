/*一个核电站有N个放核物质的坑，坑排列在一条直线上。如果连续M个坑中放入核物质，
则会发生爆炸，于是，在某些坑中可能不放核物质。 　　
任务：对于给定的N和M，求不发生爆炸的放置核物质的方案总数 
Input
只一行，两个正整数N，M( 1 < N < 50，2 ≤ M ≤ 5 )
Output
一个正整数S，表示方案总数。
Sample Input
4 3
Sample Output
13*/
#include <iostream>

using namespace std;

int main()
{
	ios::sync_with_stdio(false);
	cin.tie(0);

	return 0;
}