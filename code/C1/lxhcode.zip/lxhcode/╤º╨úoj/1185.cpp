/*从键盘输入任意20个整型数，统计其中的负数个数并求所有正数的平均值。
保留两位小数
1 2 3 4 5 6 7 8 9 10
-1 -2 -3 -4 -5 -6 -7 -8 -9 -10
Sample Output
10
5.5*/
#include <iostream>

using namespace std;

int main()
{
	ios::sync_with_stdio(false);
	cin.tie(0);

	int a, i = 0, sum1 = 0, sum2 = 0;
	double sum3=0;
	
	for (i = 0; i < 20; i++)
	{
		scanf("%d", &a);
		if (a < 0)
		{
			sum1++;
		}
		if (a > 0)
		{
			sum2++;
			sum3 += a;
		}
	}
	sum3=sum3/sum2;
	printf("%d\n%.2lf\n",sum1,sum3);
	return 0;
}