/*已知：Sn= 1＋1／2＋1／3＋…＋1／n。显然对于任意一个整数K，当n足够大的时候，Sn大于K。
现给出一个整数K（1<=k<=15），要求计算出一个最小的n；使得Sn＞K。
Input
键盘输入 k
Output
屏幕输出 n
Sample Input
1
Sample Output
2*/
#include <iostream>

using namespace std;

int main()
{
	ios::sync_with_stdio(false);
	cin.tie(0);

	int k;
	double sn, n;
	cin >> k;
	for (n = 1; n < 1000000000; n++)
	{
		sn += 1 / n;
		if (sn > k)
		{
			break;
		}
	}
	cout << n;

	return 0;
}