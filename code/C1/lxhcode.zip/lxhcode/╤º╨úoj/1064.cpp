/*已有一个已排好的9个元素的数组，今输入一个数要求按原来排序的规律将它插入数组中。
Input
第一行，原始数列。 第二行，需要插入的数字。
Output
排序后的数列
Sample Input
1 7 8 17 23 24 59 62 101
50
Sample Output
1
7
8
17
23
24
50
59
62
101*/
#include <iostream>
#include <algorithm>

using namespace std;

int main()
{
	ios::sync_with_stdio(false);
	cin.tie(0);

	int arr[50] = {0};
	for (int i = 0; i <= 9; i++)
	{
		scanf("%d", &arr[i]);
	}
	if (arr[0] > arr[8])
	{
		sort(arr, arr + 10, greater<int>());
		for (int i = 0; i <= 9; i++)
		{
			printf("%d\n", arr[i]);
		}
	}
	if (arr[0] < arr[8])
	{
		sort(arr, arr + 10);
		for (int i = 0; i <= 9; i++)
		{
			printf("%d\n", arr[i]);
		}
	}

	return 0;
}