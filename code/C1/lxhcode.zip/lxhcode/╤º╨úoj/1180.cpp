/*输入一个华氏温度，要求输出摄氏温度。公式为
c = (5 / 9) * (F - 32)
保留两位小数
Sample Input -
40 Sample Output - 40.00*/
#include <iostream>

using namespace std;

int main()
{
	ios::sync_with_stdio(false);
	cin.tie(0);

	int F;
	double c;
	scanf("%d", &F);
	c = (5.0 / 9) * (F - 32);
	printf("%.2lf\n", c);
	return 0;
}