#include <stdio.h>

int main()
{
    int m,n,i;
    scanf ("%d%d",&m,&n);
    i=m;
    while (m%i!=0||n%i!=0)
    {
        --i;
    }
    printf ("%d ",i);
    printf ("%d",m*n/i);
    return 0;
}
