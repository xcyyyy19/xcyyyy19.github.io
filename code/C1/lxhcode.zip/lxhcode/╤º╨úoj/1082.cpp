/*输入三个整数，按由小到大的顺序输出。
Input
三个整数
Output
由小到大输出成一行，每个数字后面跟一个空格
Sample Input
2 3 1
Sample Output
1 2 3 */
#include <iostream>

using namespace std;

int main()
{
	ios::sync_with_stdio(false);
	cin.tie(0);

	int a, b, c, min;

	return 0;
}