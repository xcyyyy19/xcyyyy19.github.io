/*输入一个正整数n.求1+1/2!+1/3!+....+1/n!
要求定义并调用函数fact(n)计算n的阶乘，函数返回值的类型是点单精度浮点型。
* 输出保留4位小数
Input
正整数n
Output
数列之和
Sample Input
2
Sample Output
1.5000*/
#include <iostream>

using namespace std;

float fact(int n)
{
	float j = 1;
	for (int m = 1; m <= n; m++)
		j *= m;
	j = 1.0 / j;
	return j;
}
int main()
{
	ios::sync_with_stdio(false);
	cin.tie(0);
	int n, i;
	cin >> n;
	float a = 0;
	for (i = 1; i <= n; i++)
	{
		a += fact(i);
	}
	printf("%.4f", a);
	return 0;
}