/*写一函数，将两个字符串中的元音字母复制到另一个字符串，然后输出。
Input
一行字符串
Output
顺序输出其中的元音字母（aeiuo）
Sample Input
abcde
Sample Output
ae*/
#include <iostream>
#include <string>

using namespace std;

int main()
{
	ios::sync_with_stdio(false);
	cin.tie(0);

	string s, n;

	getline(cin, s);

	for (int i = 0; i < s.size(); i++)
	{
		if (s[i] == 'a' || s[i] == 'e' || s[i] == 'i' || s[i] == 'o' || s[i] == 'u')
		{
			n.push_back(s[i]);
		}
	}
	cout << n;
	return 0;
}