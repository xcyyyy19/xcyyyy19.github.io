/*写一个函数，使给定的一个二维数组（３×３）转置，即行列互换。
Input
一个3x3的矩阵
Output
转置后的矩阵
Sample Input
1 2 3
4 5 6
7 8 9
Sample Output
1 4 7 
2 5 8 
3 6 9 */
#include <iostream>

using namespace std;

int main()
{
	ios::sync_with_stdio(false);
	cin.tie(0);

	int arr[3][3];
	for (int i = 0; i < 3; i++)
	{
		int j = 0;
		for (j = 0; j < 3; j++)
		{
			scanf("%d", &arr[i][j]);
		}
	}
	for (int i = 0; i < 3; i++)
	{
		int j = 0;
		for (j = 0; j < 3; j++)
		{
			printf("%d ", arr[j][i]);
		}
		printf("\n");
	}
	return 0;
}