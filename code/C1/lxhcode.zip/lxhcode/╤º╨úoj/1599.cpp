/*我们的学校在前年为了学生的安全新建了一座连通教学区和住宿区的桥，设桥长N米，宽2米，
现有铺桥的地砖，长2米，宽1米。现给出桥的长度N，请你编程计算出有多少铺桥的方式？（地砖放置的位置不同就算方式不同）
Input
第一行给出一个整数M，表示有M组测试样例。
接下来M行给出一个整数N，N的意思如上所示，N（0 < N <= 50）。
Output
输出一个整数表示有多少种铺桥的方式。
Sample Input
3
1
3
2
Sample Output
1
3
2*/
#include <iostream>

using namespace std;

int main()
{
	ios::sync_with_stdio(false);
	cin.tie(0);

	int p, m, n;
	long long a[100] = {1, 1};
	for (int i = 2; i <= 50; i++)
	{
		a[i] = a[i - 1] + a[i - 2];
	}
	scanf("%d", &m);
	for (int k = 0; k < m; k++)
	{
		scanf("%d", &p);
		printf("%lld\n", a[p]);
	}
	return 0;
}