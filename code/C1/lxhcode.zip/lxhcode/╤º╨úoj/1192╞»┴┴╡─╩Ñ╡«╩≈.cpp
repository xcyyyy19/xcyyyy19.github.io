/*打印出以下图形。
Input
Output
Sample Input
4
Sample Output
   *
  ***
 *****
*******
*/
#include <stdio.h>

int main()
{
	int a,i = 0;
	scanf("%d",&a);
	for(i = a-1;i >= 0;i--)
	{
		for(int j = 0;j < i ;j++)
		{
			printf(" ");
		}
		for(int j = 0;j < (a-i)*2-1 ;j++)//等差数列
		{
			printf("*");
		}
		
		printf("\n");
	}
	
	return 0;
}