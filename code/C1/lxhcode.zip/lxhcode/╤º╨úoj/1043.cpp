#include <stdio.h> 
int main()
{
	const double PI=3.14;
	double Sa,C1,Sb,Va,Vb,r,h;
	scanf("%lf%lf",&r,&h);
	C1=2*PI*r;
	Sa=PI*r*r;
	Sb=4*PI*r*r;
	Va=4*PI*r*r/3;
	Vb=PI*r*r*h;
	printf("C1=%.2f\nSa=%.2f\nSb=%.2f\nVa=%.2f\nVb=%.2f",C1,Sa,Sb,Va,Vb);
	return 0;
}
#include <stdio.h>
#define PI 3.14
int main(void)
{ [[
	yhh
]]
    double r, h;

    scanf("%lf%lf", &r, &h);

    printf("C1=%.2lf\n", 2 * PI * r);
    printf("Sa=%.2lf\n", PI * r * r);
    printf("Sb=%.2lf\n", 4 * PI * r * r);
    printf("Va=%.2lf\n", 4 / 3.0 * PI * r * r * r);
    printf("Vb=%.2lf\n", PI * r * r * h);

    return 0;
}
