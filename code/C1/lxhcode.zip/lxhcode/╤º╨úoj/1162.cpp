/*编制程序，输入m,n(M>=n>=0)后,计算下列表达式的值并输出：
         m!         
n! (m-n)!
Input
m n
Output
对应表达式的值
Sample Input
2 1
Sample Output
2
*/
#include <iostream>

using namespace std;

#include <stdio.h>

int fact(int n)
{
	int j = 1;
	for (int m = 1; m <= n; m++)
		j = j * m;
	return j;
}
int main()
{
	ios::sync_with_stdio(false);
	cin.tie(0);
	int n, m;
	cin >> m >> n;
	cout << fact(m) / (fact(n) * fact(m - n)) << endl;
	return 0;
}