/*输入一行电报文字，将字母变成其下一字母（如’a’变成’b’……’z’变成’ａ’其它字符不变）。
Input
一行字符
Output
加密处理后的字符
Sample Input
a b
Sample Output
b c*/
#include <iostream>

using namespace std;

int main()
{
	ios::sync_with_stdio(false);
	cin.tie(0);

	string s;
	getline(cin, s);
	for (int i = 0; i < s.size(); i++)
	{
		if ((s[i] >= 'a' && s[i] < 'z') || (s[i] >= 'A' && s[i] < 'Z'))
		{
			printf("%c", s[i] + 1);
		}
		else if ((s[i] == 'z') || (s[i] == 'Z'))
		{
			printf("%c", s[i] - ('Z' - 'A'));
		}
		else
			printf("%c", s[i]);
	}
	return 0;
}