/*输入一个正整数n(1≤ n ≤6), 再输入一个n行n列的矩阵，找出该矩阵中
绝对值最大的元素以及它的行下标和列下标。 Input
	n
	nxn
	Output
	数 行 列
	Sample Input
	2 1 2 3 4 
	Sample Output
	4 2 2*/

	#include <stdio.h>
	#include <math.h>

	int main()
	{
		int n=0,a=0,b=0,j=0;
		scanf("%d",&n);
		double arr[n][n];
		for(int i = 0;i < n;i++)
		{
			for(j = 0;j < n;j++)
			{
				scanf("%lf",&arr[i][j]);
				if(fabs(arr[a][b])<fabs(arr[i][j]))
					a=i,b=j;
			}
		}
		printf("%.lf %d %d\n",arr[a][b],a+1,b+1);
		return 0;
	}
	/*
	scanf("%lf",&arr[i][n]);
	if(fabs(arr[i][n])>m)
	{
		m = fabs(arr[i][n]);
		a = i,b = n;
	}
	scanf("%lf",&arr[n-1][i]);
	if(fabs(arr[n-1][i])>m)
	{
		m = fabs(arr[n-1][i]);
		a = n-1,b = i;
	}
	*/