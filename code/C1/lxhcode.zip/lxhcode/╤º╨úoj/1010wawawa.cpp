/*你的任务是计算一些整数的总和
输入
输入在第一行包含一个整数N，然后N行。 每行以一个整数M开始，然后M个整数跟在同一行
产量
对于每组输入整数，您应该在一行中输出它们的总和，并且必须注意输出之间有一个空行。
示例输入
3
4 1 2 3 4
5 1 2 3 4 5
3 1 2 3
示例输出
10
15
6*/

#include <iostream>

using namespace std;

int main()
{
	ios::sync_with_stdio(false);
	cin.tie(0);

	int n, m, a[1000], sum = 0;
	cin >> n;
	for (int k = 0; k < n; k++)
	{
		scanf("%d", &m);
		for (int i = 0; i < m; i++)
		{
			cin >> a[i];
			sum += a[i];
		}
		printf("%d\n", sum);

		sum = 0;
	}
	return 0;
}