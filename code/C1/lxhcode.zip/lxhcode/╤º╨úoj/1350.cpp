/*编一个程序，输入一个字符串，将组成字符串的所有非英文字母的字符删除后输出。
Input
一个字符串，长度不超过80个字符
Output
删掉非英文字母后的字符串。
Sample Input
abc123+xyz.5
Sample Output
abcxyz*/
#include <iostream>
#include <string>

using namespace std;

int main()
{
	ios::sync_with_stdio(false);
	cin.tie(0);

	string s;
	getline(cin, s);
	for (int i = 0; i <s.size(); i++)
	{
		if(('z'>=s[i]&&s[i]>='a')||('Z'>=s[i]&&s[i]>='A'))
		{
			cout << s[i];
		}
	}

	return 0;
}