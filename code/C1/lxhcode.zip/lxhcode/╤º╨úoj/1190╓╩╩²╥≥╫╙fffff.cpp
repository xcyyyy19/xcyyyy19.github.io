/*输入一个正整数，输出它的所有质数的因子（如180的质数因子为2、2、3、3、5）
Sample Input
180
Sample Output
2 2 3 3 5 */
#include <stdio.h>

int main()
{
	int a;
	int i=2;
	scanf("%d",&a);
	while(a!=1)
	{
		
		if(a%i==0)
		{
			a/=i;
			printf("%d ",i);
		}
		else i++;
	}
	return 0;
}