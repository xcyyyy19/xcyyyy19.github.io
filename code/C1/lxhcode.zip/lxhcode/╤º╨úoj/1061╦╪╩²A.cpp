/*用筛法求之N内的素数。 Input  N  Output  0～N的素数  Sample Input 100 Sample Output
2
3
5
7
11
13
17
19
23
29
31
37
41
43
47
53
59
61
67
71
73
79
83
89
97*/
#include <stdio.h>

int main()
{
	int n,j;
	scanf("%d",&n);
	for(int i = 2; i < n;i++)
	{
		for(j = 2; j < i;j++)
		{
			if(i%j==0)
			break;
		}
		if(i==j)
		{
			printf("%d\n",i);
		}
	}
	return 0;
}