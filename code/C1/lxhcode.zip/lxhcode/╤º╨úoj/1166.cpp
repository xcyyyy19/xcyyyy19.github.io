/*编程，输入n后：输入n个数，根据下式计算并输出y值。
     / x2-sinx    x<-2
y={  2x+x       -2<=x<=2
     \ √  X2+X+1                  x>2
* 输出保留两位小数
Input
n
n个数
Output
y
Sample Input
1
1
Sample Outpu
3.00*/
#include <iostream>
#include <cmath>
using namespace std;

int main()
{
	ios::sync_with_stdio(false);
	cin.tie(0);
	int i, n;
	double x, y;
	cin >> n;
	for (i = 0; i < n; i++)
	{
		cin >> x;
		if (x < -2)
		{
			y = x * x - sin(x);
		}
		else if (x > 2)
		{
			y = sqrt(x * x + x + 1);
		}
		else
			y = pow(2, x) + x;
		printf("%.2lf\n", y);
	}
	return 0;
}