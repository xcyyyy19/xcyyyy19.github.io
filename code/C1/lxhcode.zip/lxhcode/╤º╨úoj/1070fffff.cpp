/*写一函数，使输入的一个字符串按反序存放，在主函数中输入输出反序后的字符串。
Input
一行字符
Output
逆序后的字符串
Sample Input
123456abcdef 
Sample Output
fedcba654321*/
#include <iostream>
#include <string>

using namespace std;

int main()
{
	ios::sync_with_stdio(false);
	cin.tie(0);

	char arr[10000];
	gets(arr);
	int len = strlen(arr);
	for (int i = len - 1; i >= 0; i--) //注意len-1！！！数组下标和啊！！！
	{
		if (i == len - 1 && (arr[i] == ' '))
			continue;
		printf("%c", arr[i]);
	}

	return 0;
}