/*我们经常会在一篇文章中查找某个关键词，其本质就是字符串搜索，请你编写一段程序判断一个指定的字符串在另一个字符串中出现的次数。
Input
每行两个字符串，中间用一个空格分开。
Output
第一个字符串在第二个字符串中出现的次数。
Sample Input
自 上海自来水来自海上
自来水 上海自来水来自海上
abc abdefgadcbef
Sample Output
2
1
0*/
#include <iostream>

using namespace std;

int main()
{
	ios::sync_with_stdio(false);
	cin.tie(0);

	char a[1000], b[1000];
	while (scanf("%s", a) != EOF)
	{
		scanf("%s", b);
		int lenb = strlen(b);
		int lena = strlen(a);
		for (int i = 0; i < lenb; i++)
		{
			for (int j = 0; j < lena; j++)
			{
				if (a[j] == b[i])
				{
					continue;
				}
			}
		}
	}

	return 0;
}