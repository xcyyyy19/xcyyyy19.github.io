/*我们的学校在去年开始新建了一座连通教学区和住宿区的桥，设桥长N米，宽3米，
现有铺桥的地砖两种，第一种地砖2X2米，第二种地砖1X1米。现给出桥的长度N，请你编程计算出有多少铺桥的方式？（地砖放置的位置不同就算方式不同）
Input
第一行给出一个整数M，表示有M组测试样例。
接下来M行给出一个整数N，N的意思如题意所示。(1 <= N <= 30)
Output
输出一个整数表示有多少种铺桥的方式。
Sample Input
3
1
2
3
Sample Output
1
3
5*/
#include <iostream>

using namespace std;

int main()
{
	ios::sync_with_stdio(false);
	cin.tie(0);

	int n, a[32] = {1, 1}, m, k;
	for (int i = 2; i <= 30; ++i)
	{
		a[i] = a[i - 1] + 2 * a[i - 2];
	}
	scanf("%d", &n);
	for (int i = 0; i < n; i++)
	{
		scanf("%d", &m);
		printf("%d\n", a[m]);
	}
	return 0;
}