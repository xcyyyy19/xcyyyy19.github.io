/*求Sn=1!+2!+3!+4!+5!+…+n!之值，其中n是一个数字。
Input
n
Output
和
Sample Input
5
Sample Output
153*/
#include <stdio.h>

long long fun(int n)
{
    long long p = 1;
    for (int i = 1; i <= n; i++)
    {
        p *= i;
    }
    return p;
}

int main()
{
    int n;

    long long Sn = 0;
    scanf("%d", &n);
    for (int i = 1; i <= n; i++)
    {
        Sn += fun(i);
    }
    printf("%lld\n", Sn);
    return 0;
}