/*ACM是一个奇怪的社团，每一个人都有一个他不喜欢的数字。
所以在数数的时候，他们会特意的跳过这些数字不去进行计算。
而且不只有数字3，任何包含3的数字AunSmile都是不喜欢的。
现在请你计算在一个区间内的数字数量，如果这个区间内存在包含一个不喜欢的数字，则这个数字将不会计算在数量中。
Input
包含多组测试数据。
每组数据包含三个整数,num,begin,end，分别表示不喜欢的数字，左区间，以及右区间（注意这个区间是闭合的）
(1 <= num <= 9,1 <= begin <= end <= 1000)
输入0 0 0表示数据的结束
Output
输出包含一个整数，表示该区间的数字数量
Sample Input
3 1 5
1 1 10
0 0 0
Sample Output
4
8*/
#include <iostream>

using namespace std;

bool judge(int k, int b)
{
	while (k)
	{
		if (k != b)
		{
			k = k / 10;
		}
	}
}
// while (k % 10)
// {
// 	if (k % 10 != b)
// 	{
// 		k = k / 10;
// 		if (k == 0)
// 		{
// 			return false;
// 		}
// 		continue;
// 	}
// 	else if (k % 10 == b)
// 	{
// 		return true;
// 	}
// }
// if (k == b || k / 10 == b)
// {
// 	return true;
// }
// else
// {
// 	return false;
// }
}

int main()
{
	ios::sync_with_stdio(false);
	cin.tie(0);

	int a, b, c, k;
	int sum;
	while (scanf("%d%d%d", &a, &b, &c) != EOF && (a == 0 || b == 0 || c == 0))
	{
		for (int i = b; i <= c; i++)
		{
			if (judge(i, a))
			{
				sum++;
			}
		}
	}
	printf("%d", sum);

	return 0;
}
