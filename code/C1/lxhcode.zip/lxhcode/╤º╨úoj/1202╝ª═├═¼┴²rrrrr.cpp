/*现在，他已经知道有这些鸽子和兔子一共有n个头和m只脚。请你帮他写个程序计算一下一共有多少只鸽子和兔子。
Input
输入包括多组数据。 
每行包括2个数据：n、m(代表上面题目中提到的意思1≤n, m≤230)。 n、m都是整数。 输入以0 0作为结束。
Output
每组数据的输出都只有一行，分别是鸽子的数量和兔子数量。 如果输入的测试数据不能求得结果，
那肯定是redraiment这个马大哈数错了，就输出"Error"提示他。
Sample Input
35 94
1 3
0 0
Sample Output
23 12
Error*/
#include <iostream>

using namespace std;

int main()
{
	ios::sync_with_stdio(false);
	cin.tie(0);

	int m, n, j;
	double t;
	while (scanf("%d%d", &m, &n) != EOF && (m != 0 || n != 0))
	{
		t = (n - m * 2) / 2;j = m - t;
		if(m>0 && n>0 && n%2==0 && j>=0 && t>=0)
		{
			
			cout << j << ' ' << t << endl;
		}
		else
		{
			cout << "Error" << endl;
		}
	}
	return 0;
}