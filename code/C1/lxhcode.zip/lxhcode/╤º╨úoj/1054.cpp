/*求以下三数的和,保留2位小数 1~a之和 1~b的平方和 1~c的倒数和
Input
a b c
Output
1+2+...+a + 1^2+2^2+...+b^2 + 1/1+1/2+...+1/c
Sample Input
100 50 10
Sample Output
47977.93*/
#include <stdio.h>

int main()
{
	int a, b, c, A = 0, B = 0, sum1 = 0;
	double C = 0, sum2 = 0;
	scanf("%d%d%d", &a, &b, &c);
	for (int i = 1; i <= a; i++)
	{
		A += i;
	}
	for (int i = 1; i <= b; i++)
	{
		B = i * i;
		sum1 += B;
	}
	for (int i = 1; i <= c; i++)
	{
		C = 1.0 / i;
		sum2 += C;
	}
	printf("%.2lf", A + sum1 + sum2);
	return 0;
}