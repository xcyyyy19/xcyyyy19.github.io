/*你的任务是计算一些整数的总和。
输入
输入包含多个测试用例。 每个测试用例都包含一个整数N，然后N个整数在同一行中。 以0开始的测试用例终止输入，并且这个测试用例不被处理。
产量
对于每组输入整数，您应该在一行中输出它们的总和，并在输入中为每一行输出一行。
示例输入
4 1 2 3 4
5 1 2 3 4 5
0
示例输出
10
15*/
#include <iostream>

using namespace std;

int main()
{
	ios::sync_with_stdio(false);
	cin.tie(0);

	int n, a, sum = 0;
	while (scanf("%d", &n) != EOF && n != 0)
	{
		for (int i = 0; i < n; i++)
		{
			scanf("%d", &a);
			sum += a;
		}
		printf("%d\n", sum);
		sum = 0;
	}
	return 0;
}