/*三角形面积=SQRT(S*(S-a)*(S-b)*(S-c)) 其中S=(a+b+c)/2，a、b、c为三角形的三边。 定义两个带参的宏，一个用来求area， 另一个宏用来求S。 写程序，在程序中用带实参的宏名来求面积area。
Input
a b c三角形的三条边,可以是小数。
Output
三角形面积，保留3位小数
Sample Input
3 4 5
Sample Output
6.000*/
#include <iostream>
#include <cmath>

using namespace std;

int main()
{
	ios::sync_with_stdio(false);
	cin.tie(0);

	double a, b, c, s;
	cin >> a >> b >> c;
	printf("%.3lf", sqrt(((a + b + c) / 2) * (((a + b + c) / 2) - a) * (((a + b + c) / 2) - b) * (((a + b + c) / 2) - c)));
	return 0;
}