/*写一个判断素数的函数，在主函数输入一个整数，输出是否是素数的消息。
Input
一个数
Output
如果是素数输出prime 如果不是输出not prime
Sample Input
97
Sample Output
prime*/
#include <stdio.h>

int main()
{
	int n, j;
	scanf("%d", &n);
	for (j = 2; j < n; j++)
	{
		if (n % j == 0)
			break;
	}
	if (n == j)
	{
		printf("prime\n");
	}
	else
	{
		printf("not prime\n");
	}

	return 0;
}