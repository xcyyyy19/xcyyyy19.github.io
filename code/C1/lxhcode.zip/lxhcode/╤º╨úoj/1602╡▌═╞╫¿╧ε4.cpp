/*现有一个数字由1,2,3三个数字组成，且数字1不能连续出现两次，现在给出数字的长度N，求出数字有多少种可能组合。
Input
第一行给出一个整数M，表示有M组测试样例。
接下来M行给出一个整数N，N的意思如题意所示。(0 <= N <= 39)
Outpu
输出一个整数表示有数字的组合可能数量。
Sample Input
2
1
2
Sample Output
3
8*/
#include <iostream>

using namespace std;

int main()
{
	long long a[100], k[100];
	a[0] = 3;
	k[0] = 1;
	int n, m;
	cin >> m;
	for (int q = 0; q < m; q++)
	{
		scanf("%d", &n);
		if (n == 1)
		{
			cout << '3' << endl;
			continue;
		}
		for (int i = 1; i < n; i++)
		{
			k[i] = a[i - 1] - k[i - 1];
			a[i] = k[i] * 3 + k[i - 1] * 2;
		}
		cout << a[n - 1] << endl;
	}
	return 0;
}