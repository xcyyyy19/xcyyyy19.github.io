#include <iostream>

using namespace std;

int main()
{
	ios::sync_with_stdio(false);
	cin.tie(0);

	double x, y = 0;
	scanf("%lf", &x);
	if (x < 1)
	{
		y = x;
	}
	else if (x >= 10)
	{
		y = 3 * x - 11;
	}
	else
	{
		y = 2 * x - 1;
	}
	printf("%.2lf\n", y);
	return 0;
}