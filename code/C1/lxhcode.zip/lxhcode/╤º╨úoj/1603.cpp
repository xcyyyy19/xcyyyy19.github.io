/*现有一个数字由1,2,3三个数字组成，相邻的数字不能相同且首尾数字不能相同，现在给出数字的长度N，求出数字有多少种可能组合。
Input
第一行给出一个整数M，表示有M组测试样例。
接下来M行给出一个整数N，N的意思如题意所示。(0 <= N <= 50)
Output
输出一个整数表示有数字的组合可能数量。
Sample Input
2
1
2
Sample Output
3
6*/

#include <iostream>

using namespace std;

int main()
{
	ios::sync_with_stdio(false);
	cin.tie(0);

	int m, n, a = 1, sum = 0, k = 1;
	cin >> m;
	for (int i = 0; i < m; i++)
	{
		cin >> n;
		if (n == 1)
		{
			cout << '3' << endl;
		}
		else
		{
			for (int j = 1; j <= n; j++)
			{
				if (j == 2)
				{
					a = 2;
					sum += a;
				}
				if (j > 2)
				{
					if (j == 3)
					{
						k = 2;
					}
					else
					{
						k += 2 * k + 2;
					}
					a *= 2;
					sum += a;
				}
			}
			sum -= k;
			sum *= 3;
			cout << sum << endl;
		}
	}

	return 0;
}