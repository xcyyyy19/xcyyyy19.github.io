/*编制函数，其功能是在float类型一维数组中查找最大值、最小值，并将它们返回到调用程序。
* 输出保留两位小数
Input
n
n个浮点数
Output
最大值 最小值
Sample Input
10
1.0
2.0
3.0
4.0
5.0
6.0
7.0
8.0
9.0
10.0
Sample Output
10.00 1.00*/
#include <iostream>

using namespace std;

int main()
{
	ios::sync_with_stdio(false);
	cin.tie(0);

	int i = 0, n;
	double a, q, r;
	cin >> n;
	cin >> a;
	q = r = a;
	for (i = 1; i < n; ++i)
	{
		cin >> a;
		q = a > q ? a : q;
		r = a < r ? a : r;
	}
	printf("%.2lf %.2lf\n", q, r);
	return 0;
}