/*编写一个程序，打印输出半径为1到10的圆的面积，若面积在40到90之间则予以打印，否则，不予打印。
Input
Output
r=? area=??.??
....
保留两位小数*/
#include <stdio.h>
# define PI 3.14159
int main()
{
	double area;
	for(int i = 1;i <= 10;i++)
	{
		area=PI*i*i;
		if(area>=40 && area<=90)
		{
			printf("r=%d area=%.2lf\n",i,area);
		}
	}
	return 0;
}