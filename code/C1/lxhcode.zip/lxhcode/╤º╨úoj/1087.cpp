/*有一字符串，包含n个字符。写一函数，将此字符串中从第m个字符开始的全部字符复制成为另一个字符串。
Input
数字n 一行字符串 数字m
Output
从m开始的子串
Sample Input
6
abcdef
3
Sample Output
cdef*/
#include <iostream>
#include <string>

using namespace std;

int main()
{
	ios::sync_with_stdio(false);
	cin.tie(0);

	int m, p;
	cin >> p;
	string s;
	getline(cin, s);
	getchar();
	cin >> m;
	for (int i = m + 1; i < s.size(); i++)
	{
		cout << s[i];
	}
	return 0;
}