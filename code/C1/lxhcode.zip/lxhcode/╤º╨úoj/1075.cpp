/*定义一个带参的宏，使两个参数的值互换，并写出程序，输入两个数作为使用宏时的实参。输出已交换后的两个值。
输入
两个数，空格隔开
输出
交换后的两个数，空格隔开
样例输入
1 2
样例输出
2 1*/
#include <iostream>

using namespace std;

int main()
{
	ios::sync_with_stdio(false);
	cin.tie(0);

	int a, b;
	cin >> a >> b;
	cout << b << ' ' << a;

	return 0;
}