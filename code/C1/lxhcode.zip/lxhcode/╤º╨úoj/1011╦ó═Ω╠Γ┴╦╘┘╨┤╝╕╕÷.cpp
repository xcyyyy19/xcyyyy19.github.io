/*将一个字符串str的内容颠倒过来，并输出。str的长度不超过100个字符。
Input
输入包括一行。 第一行输入的字符串。
Output
输出转换好的逆序字符串。
Sample Input
I am a student
Sample Output
tneduts a ma I
思路1:无脑入栈出栈
思路2:无脑fgets
思路3:无脑string*/

//33333
#include <iostream>
#include <string>

using namespace std;

int main()
{
	ios::sync_with_stdio(false);
	cin.tie(0);

	string s;
	getline(cin, s);
	for (int i = s.size() - 1; i >= 0; i--)
	{
		cout << s[i];
	}

	return 0;
}