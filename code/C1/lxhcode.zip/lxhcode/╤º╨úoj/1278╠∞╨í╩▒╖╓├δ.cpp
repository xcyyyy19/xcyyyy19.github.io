/*程序设计大赛对于在计算机专业的学生形成良好的专业氛围起着非常重要的作用。
大家知道，上学期由于机房问题，我们没有开展ACM程序设计大赛，实在是非常可惜。
现在给定一个整数t，表示距离我们上一次比赛的时间（单位：秒），现在要求输出我们已经多少天、多少小时、多少秒没有开展比赛了。
Input
有多组测试数据，每一行为一个整数t(1<=t<=1000,0000)。
Output
对于每一组数据，按如下格式输出结果(下划线表示空格)：
d_days_h_hours_m_minutes_s_seconds
Sample Input
1
100000
Sample Output
0 days 0 hours 0 minutes 1 seconds
1 days 3 hours 46 minutes 40 seconds*/
#include <iostream>

using namespace std;

int main()
{
	ios::sync_with_stdio(false);
	cin.tie(0);

	long long t;
	int d, h, m, s;
	while (scanf("%lld", &t) != EOF)
	{
		s = t % 60;
		m = t / 60 % 60;
		h = t / 60 / 60 % 24;
		d = t / 60 / 60 / 24;
		printf("%d days %d hours %d minutes %d seconds\n", d, h, m, s);
	}

	return 0;
}