/*编写一函数，由实参传来一个字符串，统计此字符串中字母、数字、空格和其它字符的个数，在主函数中输入字符串以及输出上述结果。 只要结果，别输出什么提示信息。
Input
一行字符串
Output
统计数据，4个数字，空格分开。
Sample Input
!@#$%^QWERT    1234567
Sample Output
5 7 4 6 */
#include <stdio.h>
#include <string.h>

int main()
{
	int a = 0, b = 0, c = 0, d = 0, i;

	char arr[100];

	gets(arr);

	int len = strlen(arr);

	for (i = 0; len > i; i++)
	{
		if (('a' <= arr[i] && 'z' >= arr[i]) || ('Z' >= arr[i] && 'A' <= arr[i]))
		{
			++a;
		}
		else if (arr[i] >= '0' && arr[i] <= '9')
		{
			++b;
		}
		else if (arr[i] == ' ')
		{
			++c;
		}
		else
		{
			++d;
		}
	}
	printf("%d ", a);
	printf("%d ", b);
	printf("%d ", c);
	printf("%d ", d);

	return 0;
}
