/*编制程序，输入m,n(M>=n>=0)后,计算下列表达式的值并输出：
         m!         
n! (m-n)!
Input
m n
Output
对应表达式的值
Sample Input
2 1
Sample Output
2
*/
#include <iostream>

using namespace std;

int f(int i, int q)
{
	i *= q;
	return i;
}

int main()
{
	ios::sync_with_stdio(false);
	cin.tie(0);
	int i = 0, j = 0, k = 0, m = 0, n = 0, q = 0, r = 0, s = 0;
	cin >> m >> n;
	for (i = 0; i < m; i++)
	{
		q = f(i, m);
	}
	for (i = 0; i < n; i++)
	{
		r = f(i, n);
	}
	for (i = 0; i < m - n; i++)
	{
		s = f(i, m - n);
	}
	cout << q / (r * s);
	return 0;
}