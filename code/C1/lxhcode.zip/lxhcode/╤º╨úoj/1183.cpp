/*sum=2+5+8+11+14+…，输入正整数n，求sum的前n项和。
Input
Output
Sample Input
2
Sample Output
7*/
#include <iostream>

using namespace std;

int main()
{
	ios::sync_with_stdio(false);
	cin.tie(0);
	int i, n, a = 2, sum = 0;
	cin >> n;
	for (i = 0; i < n; i++)
	{
		sum += a;
		a += 3;
	}
	printf("%d\n", sum);

	return 0;
}