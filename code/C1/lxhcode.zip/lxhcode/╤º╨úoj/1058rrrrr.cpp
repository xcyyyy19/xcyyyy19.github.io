/*一球从M米高度自由下落，每次落地后返回原高度的一半，再落下。 
它在第N次落地时反弹多高？共经过多少米？ 保留两位小数
Input
M N
Output
它在第N次落地时反弹多高？共经过多少米？保留两位小数，空格隔开，放在一行
Sample Input
1000 5
Sample Output
31.25 2875.00*/
#include <stdio.h>

double fun(int m, int n)
{
    double sum = m;
    for (int i = 2; i <= n; i++)
    {
        sum += m;
        m = m / 2;
    }
    return sum;
}
int main()
{
    int m, n, h, i;
    scanf("%d%d", &m, &n);
    printf("%.2lf", fun(m, n));

    return 0;
}