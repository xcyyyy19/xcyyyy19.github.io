/*求方程 的根，用三个函数分别求当b^2-4ac大于0、等于0、和小于0时的根，并输出结果。从主函数输入a、b、c的值。
Input
a b c
Output
x1=? x2=?
Sample Input
4 1 1
Sample Output
x1=-0.125+0.484i x2=-0.125-0.484i*/
#include <iostream>

using namespace std;

int main()
{
	ios::sync_with_stdio(false);
	cin.tie(0);

	
	return 0;
}