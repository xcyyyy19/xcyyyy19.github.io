/*写两个函数，分别求两个整数的最大公约数和最小公倍数，用主函数调用这两个函数，并输出结果两个整数由键盘输入。
Input
两个数
Output
最大公约数 最小公倍数
Sample Input
6 15
Sample Output
3 3*/