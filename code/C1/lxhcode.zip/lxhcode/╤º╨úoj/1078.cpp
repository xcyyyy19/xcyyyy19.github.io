/*给年份year，定义一个宏，以判别该年份是否闰年。提示：宏名可以定义为LEAP_YEAR，形参为y，既定义宏的形式为 #define LEAP_YEAR(y) （读者设计的字符串）
Input
一个年份
Output
根据是否闰年输出，是输出"L",否输出"N"
Sample Input
2000
Sample Output
L*/
#include <iostream>

using namespace std;

int main()
{
	ios::sync_with_stdio(false);
	cin.tie(0);

	int year;
	cin >> year;
	if ((year % 4 == 0 && year % 100 != 0) || year % 400 == 0)
	{
		cout << 'L';
	}
	else
	{
		cout << 'N';
	}

	return 0;
}
