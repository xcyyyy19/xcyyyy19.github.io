/*第一行整数意味着输入整数a和b的数量。 你的任务是计算a + b。
输入
你的任务是计算a + b。 第一行整数意味着输入整数对的数量。
产量
对于每一对输入整数a和b，你应该在一行中输出a和b的和，在输入中输出每一行的一行输出。
示例输入
2
1 5
10 20
示例输出
6
30*/

#include <stdio.h>

int main()
{
    int a, b, n;
    scanf("%d", &n);
    for (int i = 0; n > 0; n--)
    {
        scanf("%d%d", &a, &b);
        printf("%d\n", a + b);
    }
    return 0;
}