/*用选择法对10个整数排序。
Sample Input
9 8 7 6 5 4 3 2 1 0
Sample Output
0
1
2
3
4
5
6
7
8
9*/
#include <iostream>
#include <algorithm>
#include <cstdio>

using namespace std;

int main()
{
	int a[10];
	for(int i = 0;i < 10;i++)
	{
		scanf("%d",&a[i]);
	}
	sort(a, a + 10, less<int>());
	for(int i = 0;i < 10;i++)
	{
		printf("%d\n",*(a+i));
	}
	return 0;
}