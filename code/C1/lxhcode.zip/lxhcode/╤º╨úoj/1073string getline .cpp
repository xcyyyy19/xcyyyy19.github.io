/*写一函数，输入一个四位数字，要求输出这四个数字字符，但每两个数字间空格。如输入1990，应输出"1 9 9 0"。
Input

一个四位数
Output

增加空格输出
Sample Input

1990
Sample Output

1 9 9 0 */
/*#include <iostream>
#include <string>

using namespace std;

int main()
{
	ios::sync_with_stdio(false);
	cin.tie(0);

	string s;
	getline(cin, s);
	for (int i = 1; i < 5; i++)
	{
		cout << i;
		if (i != 4)
		{
			cout << ' ';
		}
	}

	return 0;
}*/
#include <stdio.h>

int main()
{
	int i;
	char a[4];
	for (i = 0; i < 4; i++)
	{
		scanf("%c", &a[i]);
		printf("%c", a[i]);
		if (i < 3)
		{
			printf(" ");
		}
	}
	getchar();
	return 0;
}