/*输入10个数，求它们的平均值，并输出大于平均值的数据的个数。
Input
10个数
Output
大于平均数的个数
Sample Input
1 2 3 4 5 6 7 8 9 10
Sample Output
5*/
#include <iostream>

using namespace std;

int main()
{
	ios::sync_with_stdio(false);
	cin.tie(0);
	int arr[10] = {0}, i = 0, j = 0, b = 0;
	double a = 0;
	for (i = 0; i < 10; i++)
	{
		cin >> arr[i];
		a += arr[i];
	}
	a /= 10;
	for (j = 0; j < 10; j++)
	{
		if (arr[j] > a)
			b++;
	}
	cout << b << endl;
	return 0;
}