#include <stdio.h>
int main ()
{
    int I,P,m;
    int a=100000,b=200000,c=400000,d=600000,e=1000000;
    scanf ("%d",&I);
    if (I<=a)
    m=1;
    if (I>a&&I<=b)
    m=2;
    if (I>b&&I<=c)
    m=3;
    if (I>c&&I<=d)
    m=4;
    if (I>d&&I<=e)
    m=5;
    if (I>e)
    m=6;

    switch(m)
    {
        case 1:
            P=0.1*I;
            printf ("%d",P);
            break;      
        case 2:
            P=a/10+(I-a)*0.075;
            printf ("%d",P);
            break;
        case 3:
            P=10000+a*0.075+(I-b)*0.05;
            printf ("%d",P);
            break;
        case 4:
            I>c&&I<=d;
            P=10000+a*0.075+b*0.05+(I-c)*0.03;
            printf ("%d",I);
            break;
        case 5:
            I>d&&I<=e;
            P=10000+a*0.075+b*0.05+b*0.03+(I-d)*0.015;
            printf ("%d",I);
            break;
        case 6:
            I>e;
            P=10000+a*0.075+b*0.05+b*0.03+c*0.015+(I-e)*0.01;
            printf ("%d",I);
            break;
        }
    return 0;
}