
#include <stdio.h>
int main()
{
    int n, i, m, sum = 0, a = 2;
    scanf("%d", &n);
    for (i = 0; i < n; i++)
    {
        if (n == 1)
            m = a;
        else
            m = m * 10 + a;
        sum = sum + m;
    }
    printf("%d\n", sum);
}