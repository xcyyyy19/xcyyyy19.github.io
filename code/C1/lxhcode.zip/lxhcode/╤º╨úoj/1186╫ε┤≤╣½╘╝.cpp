/*输入两个正整数m和n，求其最大公约数和最小公倍数。
Input

Output

Sample Input

2 3
Sample Output

1
6*/
