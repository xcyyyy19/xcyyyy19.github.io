#include <stdio.h>
#include <string.h>
int main ()
{
    int i;
    char arr[10];
    scanf("%s",arr);
    int len = strlen(arr);
    printf ("%d\n",len);
    for  (i=0;i<len;i++)
    {
        if(i)
            printf(" ");
        printf("%c",arr[i]);
    }
    printf ("\n");
   
    for  (i=len-1;i>=0;i--)    //下标是从0开始的，所以要i=len-1
    {
        printf("%c",arr[i]);
    }
    return 0;
}