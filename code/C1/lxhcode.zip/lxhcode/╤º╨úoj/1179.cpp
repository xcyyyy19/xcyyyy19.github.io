/*编程，输入一个１０进制正整数，然后输出它所对应的八进制数。
Sample Input 10 
Sample Output 12*/
#include <iostream>

using namespace std;

int main()
{
	ios::sync_with_stdio(false);
	cin.tie(0);
	int a;
	scanf("%d", &a);
	printf("%o\n", a);
	return 0;
}