/*有n个整数，使前面各数顺序向后移m个位置，最后m个数变成前面m个数，见图。写一函数：实现以上功能，在主函数中输入n个数和输出调整后的n个数。
Input
输入数据的个数n n个整数 移动的位置m
Output
移动后的n个数
Sample Input
10
1 2 3 4 5 6 7 8 9 10
2
Sample Output
9 10 1 2 3 4 5 6 7 8 */
#include <iostream>

using namespace std;

int main()
{
	ios::sync_with_stdio(false);
	cin.tie(0);

	
	return 0;
}