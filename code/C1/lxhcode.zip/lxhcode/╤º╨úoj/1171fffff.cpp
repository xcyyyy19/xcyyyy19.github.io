/*输入两个正整数m和n(m<n)，求m到n之间(包括m和n)所有素数的和，
要求定义并调用函数isprime(x)来判断x是否为素数(素数是除1以外只能被自身整除的自然数)。
Input
m n
Output
素数和
Sample Input
2 3
Sample Output
5*/
#include <iostream>

using namespace std;

int main()
{
	ios::sync_with_stdio(false);
	cin.tie(0);
	int m = 0, n = 0, i = 0, j = 0, sum = 0;
	cin >> m >> n;
	for (i = m; i <= n; i++)
	{
		bool flag = i>1;
		for (j = 2; j < i; j++)
		{
			if (i % j == 0)
				flag=false;
		}
		if(flag)
			sum += i;
	}
	cout << sum << endl;
	return 0;
}