#include <stdio.h> 
int main ()
{
	int x,y;
	scanf ("%d",&x);
    if (x<1)
    printf ("%d",y=x);
    else if (1<=x&&x<10)
    printf ("%d",y=2*x-1);  	
	else if (x>=10)
	printf ("%d",y=3*x-11); 
	return 0;
}
#include<stdio.h>

int main(void)
{
	int x,y;
	
    scanf("%d",&x);
    
	if (x<1)
	    y=x;
	else if (x>=1 && x<10)
	    y=2*x-1;
	else
	    y=3*x-11;
	    
	printf("%d",y);
	    
	return 0;
}
