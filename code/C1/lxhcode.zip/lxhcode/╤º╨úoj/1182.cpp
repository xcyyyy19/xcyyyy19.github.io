/*编制程序，输入n个整数（n从键盘输入，n>0），输出它们的偶数和。
Sample Input
2
1 2
Sample Output
2*/
#include <iostream>

using namespace std;

int main()
{
	ios::sync_with_stdio(false);
	cin.tie(0);

	int a,n,sum=0;
	scanf("%d",&n);
	for(int i=0;i<n;++i)
	{
		scanf("%d",&a);
		if(a%2==0)
			sum+=a;
	}
	printf("%d\n",sum);
	return 0;
}