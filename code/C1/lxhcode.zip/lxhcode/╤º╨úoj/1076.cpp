/*输入两个整数，求他们相除的余数。用带参的宏来实现，编程序。
Input
a b两个数
Output
a/b的余数
Sample Input
3 2
Sample Output
1*/
#include <iostream>

using namespace std;

int main()
{
	ios::sync_with_stdio(false);
	cin.tie(0);

	int a, b;
	cin >> a >> b;
	cout << a % b;

	return 0;
}