/*你的任务是计算a + b。
输入
输入将由一系列由整数a和b组成的对，由一个空格隔开，每行一对整数。
产量
对于每对输入整数a和b，您应该输出a和b的总和，然后输出一个空行。
示例输入
1 5
10 20
示例输出
6
30*/
#include <iostream>

using namespace std;

int main()
{
	ios::sync_with_stdio(false);
	cin.tie(0);

	int a, b;
	while (scanf("%d %d", &a, &b) != EOF)
	{
		printf("%d\n\n", a + b);
	}

	return 0;
}