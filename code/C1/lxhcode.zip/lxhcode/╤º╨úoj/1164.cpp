/*编制程序，输入n个整数（n从键盘输入, n > 0）, 输出它们的偶数和。
Input
n个整数
Output
其中偶数的和
Sample Input
	10 
	1 2 3 4 5 6 7 8 9 10 
	Sample Output
	30


我写的是对的！！！
#include <iostream>

using namespace std;

int main()
{
	ios::sync_with_stdio(false);
	cin.tie(0);
	int a = 0, n = 0, i = 0;
	int arr[500] = {0};
	cin >> n;
	for (int i = 0; i < n; ++i)
	{
		scanf("%d", &arr[i]);
		if (arr[i] % 2 == 0)
		{
			a += arr[i];
		}
	}
	cout << a << endl;
	return 0;
}*/
#include <stdio.h>

int main(void)
{
	int n;
	scanf("%d", &n);
	int i, a[n], sum;
	for (i = 0; i < n; i++)
		scanf("%d", &a[i]);
	for (i = 0, sum = 0; i < n; i++)
	{
		if (a[i] % 2 == 0)
			sum += a[i];
	}
	printf("%d\n", sum);
	return 0;
}
