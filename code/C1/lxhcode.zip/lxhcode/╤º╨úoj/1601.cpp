/*现有一个数字由1,2,3三个数字组成，且相邻的三个数字之中1,2,3不会同时出现，现在给出数字的长度N，求出数字有多少种可能组合。
Input
第一行给出一个整数M，表示有M组测试样例。
接下来M行给出一个整数N，N的意思如题意所示。(0 <= N <= 39)
Output
 输出一个整数表示有数字的组合可能数量。
Sample Input
2
2
3
Sample Output
9
21*/
#include <iostream>
#include <cmath>
using namespace std;

int main()
{
	ios::sync_with_stdio(false);
	cin.tie(0);

	int m, n, a = 1, sum = 0;
	cin >> m;
	for (int i = 0; i < m; i++)
	{
		cin >> n;
		for (int j = 0; j < n; j++)
		{
			sum += (a * 2);
		}

		cout << sum << endl;
	}

	return 0;
}