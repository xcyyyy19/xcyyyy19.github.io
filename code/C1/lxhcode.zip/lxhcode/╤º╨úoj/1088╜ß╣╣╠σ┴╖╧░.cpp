/*定义一个结构体变量（包括年、月、日）。计算该日在本年中是第几天，注意闰年问题。
Input
年月日
Output
当年第几天
Sample Input
2000 12 31
Sample Output
366*/
#include <stdio.h>

struct Date
{
	int y;
	int m;
	int d;
};
int main()
{
	struct Date date;
	int m[30] = {31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31}, i = 0, n = 0;
	scanf("%d%d%d", &date.y, &date.m, &date.d);
	if ((date.y % 4 == 0 && date.y % 100 != 0) || date.y % 400 == 0)
	{
		for (i = 0; i < date.m - 1; i++)
		{
			n += m[i];
		}
		printf("%d", n + date.d);
	}
	else
	{
		m[1] = 28;
		for (i = 0; i < date.m - 1; i++)
		{
			n += m[i];
		}
		printf("%d", n + date.d);
	}
	return 0;
}