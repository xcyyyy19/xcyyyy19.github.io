/*编写程序，输入一个正整数n，求下列算式的值。要求定义和调用函数
fact(k)计算k的阶乘，函数返回值的类型是double。
1+1/2+ .... +1/n!
输出保留5位小数。
Sample Input
5
Sample Output
sum=1.71667*/
#include<stdio.h>
double fact(int k)
{
	double m = 1.0;
	for(int i = 1;i <= k;i++)
	{
		m*=i;
	}
	return m;
}
int main()
{
	int a;
	double m=0;
	scanf("%d",&a);
	for(int i = 1;i <= a;i++)
	{
		m +=(1/fact(i));
	}
	printf("sum=%.5lf\n",m);
	return 0;
}