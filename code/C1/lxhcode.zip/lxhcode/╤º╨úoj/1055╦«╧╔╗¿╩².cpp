#include <stdio.h> 
int main()
{
	int a,b,c,i; 
	for (i=100;i<1000;i++)
	{
		a = i%10;
		b = i/10%10;
		c = i/100;
		if (a*a*a+b*b*b+c*c*c==i)
		printf ("%d\n",i);
	} 
	return 0;
}

/*int f(int a)
{
	int a = i%10;
	int b = i/10%10;
	int c = i/100;
	if (a*a*a+b*b*b+c*c*c==i)
	printf ("%d\n",i);
}*/