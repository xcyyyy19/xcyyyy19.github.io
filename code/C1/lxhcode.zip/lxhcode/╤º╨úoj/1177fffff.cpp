/*编写程序，输入一批学生的成绩，遇0或负数则输入结束，要求统计并输出
优秀（大于85）、通过（60～84）和不及格（小于60）的学生人数。 
运行示例：
Input
Output
Sample Input 
88 71 68 70 59 81 91 42 66 77 83 0 
Sample Output
>= 85 : 2 
60 - 84 : 7 
<60 : 2*/

#include <stdio.h>

int main()
{
	int i,y=0,b=0,t=0;
	while(scanf("%d",&i),i>0)//遇0或负数则输入结束,假如用EOF会把0或负数都读进来
	{
		if(i>85)
		{
			y++;
		}
		else if(i<60)
		{
			b++;
		}
		else
		{
			t++;
		}
		i++;
	}
	printf(">=85:%d\n60-84:%d\n<60:%d\n",y,t,b);
	return 0;
}