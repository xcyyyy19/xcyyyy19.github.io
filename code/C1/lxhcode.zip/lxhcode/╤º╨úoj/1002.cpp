#include <stdio.h>

int main()
{
	int n,j;
	scanf("%d",&n);
	for(int i = 2; i < n;i++)
	{
		for(j = 2; j < i;j++)
		{
			if(i%j==0)
			break;
		}
		if(i==j)
		{
			printf("%d\n",i);
		}
	}
	return 0;
}