/*输入
gaohan  85
zhouyu 81.1
wuzhirui 86 
zhengfulin 70.8
guanweibo 87.6
tangzhenbo 87.5
lizhicheng 87.6
按从高到底输出 名字*/
#include <iostream>

using namespace std;

struct S
{
	char a[100];
	double c;
} a[6];

int main()
{
	for (int i = 0; i < 6; i++)
	{
	}

	return 0;
}
