/*假设有X支方队等待检阅，我们的问题是：习总书记共说了多少次“同志们好”和“同志们辛苦了”。
再问如果你在第Y支方队中(方队编号从1开始计算)，总书记对你的问候是什么？
Input
输入的第一行有X和N两个整数，X代表有X支方队，N代表下面有N个问题，下面的N行中，每1行1个整数Y，Y代表你在第N支队伍中。
Output
你的输出有N+1行，每1行2个整数分别代表习总书记说“同志们好”和“同志们辛苦了”的次数。
下面N行每行为1行文本是输入中Y对应习总书记的问候“同志们好”，“同志们辛苦了”，或“队伍编号越界”。
Sample Input
70 4
1
6
-8
71
Sample Output
47 23
同志们好
同志们辛苦了
队伍编号越界
队伍编号越界*/
#include <iostream>

using namespace std;

int main()
{
	int n, k, num, tx = 0, th = 0;
	cin >> k >> n;
	for (int p = 1; p <= k; p++)
	{
		if (p % 3 == 0)
		{
			tx++;
		}
		else
		{
			th++;
		}
	}
	for (int i = 0; i < n; i++)
	{
		cin >> num;
		if (i == 0)
		{
			cout << th << ' ' << tx << endl;
		}
		if (num <= 0 || num > k)
		{
			cout << "队伍编号越界" << endl;
		}
		else
		{

			if (num % 3 == 0)
			{
				cout << "同志们辛苦了" << endl;
			}
			else
			{
				cout << "同志们好" << endl;
			}
		}
	}

	return 0;
}