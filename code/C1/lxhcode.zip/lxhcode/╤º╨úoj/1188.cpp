/*求1+2!+3!+4!+…+30!。
科学计数法，保留两位小数。*/
#include <stdio.h>

double fun(int p)
{
	double m = 1.0;
	for(int i = 1;i <= p;i++)
	{
		m*=i;
	}
	return m;
}
int main()
{
	double m =0;
	for(int i = 1;i <= 30;i++)
	{
		m+=fun(i);
	}
	printf("%.2e",m);
	return 0;
}
