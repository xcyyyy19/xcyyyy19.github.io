/*写一函数，将两个字符串连接
Input
两行字符串
Output
链接后的字符串
Sample Input
123
abc
Sample Output
123abc*/

#include <iostream>
#include <cstring>

using namespace std;

int main()
{
	ios::sync_with_stdio(false);
	cin.tie(0);

	char a[1000], b[1000];
	gets(a);
	gets(b);
	strcat(a, b);
	cout << a;
	return 0;
}