/*求一个3×3矩阵对角线元素之和。
Sample Input
1 2 3
4 5 6
7 8 9
Sample Output
15*/
#include <stdio.h>

int main()
{
	int a[3][3];
	for(int i = 0; i < 3;i++)
	{
		for(int j = 0;j < 3; j++)
		{
			scanf("%d",&a[i][j]);
		}
	}
	printf("%d\n",a[0][0]+a[1][1]+a[2][2]);
	return 0;
}