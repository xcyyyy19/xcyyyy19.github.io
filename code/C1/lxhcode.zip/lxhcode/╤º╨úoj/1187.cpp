/*输入一行字符，分别统计出其中英文字母、空格、数字和其它字符的个数。
Input
Output
Sample Input
a 1,
Sample Output
1
1
1
1*/
#include <stdio.h>
#include <string.h>

int main()
{
    int a = 0, b = 0, c = 0, d = 0, i;

    char arr[100];

    gets(arr);

    int len = strlen(arr);

    for (i = 0; len > i; i++)
    {
        if (('a' <= arr[i] && 'z' >= arr[i]) || ('Z' >= arr[i] && 'A' <= arr[i]))
        {
            ++a;
        }
        else if (arr[i] >= '0' && arr[i] <= '9')
        {
            ++b;
        }
        else if (arr[i] == ' ')
        {
            ++c;
        }
        else
        {
            ++d;
        }
    }
    printf("%d\n", a);
    printf("%d\n", c);
    printf("%d\n", b);
    printf("%d\n", d);

    return 0;
}