/*有一分数序列： 2/1 3/2 5/3 8/5 13/8 21/13...... 求出这个数列的前N项之和，保留两位小数。
Input
N
Output
数列前N项和
Sample Input
10
Sample Output
16.48*/

#include <iostream>

using namespace std;

int main()
{
	ios::sync_with_stdio(false);
	cin.tie(0);

	int n;
	cin >> n;
	int z = 2, m = 1;
	double sum = 0;
	while (n--)
	{
		sum += z * 1.0 / m;
		int t = z;
		z = z + m;
		m = t;
	}
	printf("%.2lf", sum);

	return 0;
}

// #include <iostream>

// using namespace std;

// int fun(int n)
// {
// 	int a[1000], i, sum, p;
// 	a[0] = 1;
// 	a[1] = 1;
// 	sum = 2;
// 	for (i = 2; i < n; i++)
// 	{
// 		a[i] = a[i - 1] + a[i - 2];
// 	}
// 	return a[n - 1];
// }
// int main()
// {
// 	ios::sync_with_stdio(false);
// 	cin.tie(0);

// 	int a, b, N;
// 	double sum = 0;
// 	scanf("%d", &N);
// 	for (int i = 3; i <= N + 3; i++)
// 	{
// 		sum += fun(i) * 1.0 / fun(i - 1);
// 	}
// 	printf("%.2lf", sum);
// 	return 0;
// }