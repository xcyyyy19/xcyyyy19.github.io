/*输入10个数字，然后逆序输出。
Input
十个整数
Output
逆序输出，空格分开
Sample Input
1 2 3 4 5 6 7 8 9 0
Sample Output
0 9 8 7 6 5 4 3 2 1
HINT
数组？堆栈*/

#include <iostream>
#include <stack>

using namespace std;

int main()
{
	ios::sync_with_stdio(false);
	cin.tie(0);

	stack<int> num;
	for (int i = 0; i < 10; ++i)
	{
		int t;
		cin >> t;
		num.push(t);
	}

	for (int i = 0; i < 10; ++i)
	{
		if (i != 0)
		{
			cout << ' ';
		}
		cout << num.top();
		num.pop();
	}

	return 0;
}