#include <stdio.h> 
int main(void)
{   
	float F,c;                   
	scanf("%f",&F);
	c=5*(F-32)/9;
	printf("c=%.2f",c);       
	return 0;
}