/*输入一行字符，分别统计出其中英文字母、空格、数字和其他字符的个数。
Input
一行字符
Output
统计值
Sample Input
aklsjflj123 sadf918u324 asdf91u32oasdf/.';123
Sample Output
23 16 2 4*/

#include <stdio.h>
#include <string.h>

int main()
{
	int a = 0, b = 0, c = 0, d = 0, i;

	char arr[100];

	gets(arr);

	int len = strlen(arr);

	for (i = 0; len > i; i++)
	{
		if (('a' <= arr[i] && 'z' >= arr[i]) || ('Z' >= arr[i] && 'A' <= arr[i]))
		{
			++a;
		}
		else if (arr[i] >= '0' && arr[i] <= '9')
		{
			++b;
		}
		else if (arr[i] == ' ')
		{
			++c;
		}
		else
		{
			++d;
		}
	}
	printf("%d %d %d %d\n", a, b, c, d);

	return 0;
}
