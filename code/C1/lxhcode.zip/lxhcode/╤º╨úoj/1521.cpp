/*整数n，接下来有n个字符串，每串1行
Output
Y或N
Sample Input
2
abccba
abccbA
Sample Output
Y
N*/
#include <iostream>

using namespace std;

int main()
{
	ios::sync_with_stdio(false);
	cin.tie(0);

	int n;
	char a[1000];
	cin >> n;
	for (int i = 0; i < n; i++)
	{
		scanf("%s", &a[i]);
	}
	int p = n / 2;
	for ()

		return 0;
}