/*只用遍历一遍字符串，跳过指定字符即可
编制函数del_char
函数原型为 void del_char(char *,char),函数的功能是删除a指向的字符串中值为ch的字符，例如从字符串"AscADef"中删除'A'后，字符串为"scDef"。
Input
需要删除的字符ch
需要处理的字符串
Output
处理后的字符串
Sample Input
A
AscADef
Sample Output
scDef*/
#include <iostream>

using namespace std;

int main()
{
	ios::sync_with_stdio(false);
	cin.tie(0);
	int i = 0;
	char arr[500], a;
	scanf("%c", &a);
	getchar();
	gets(arr);
	int len = strlen(arr);
	for (i = 0; i < len; i++)
	{
		if (arr[i] != a)
			printf("%c", arr[i]);
	}
	return 0;
}