/*链表是一种基本的数据结构
AunSmile为链表给出了10个接口，现在你需要在你的程序当中模拟这些操作,(为简化模拟过程，程序只有一张链表)。
init_list   //表示建表  init(初始化)
push_back value   //表示向链表的尾部添加值value
push_front value   //表示向链表的首部添加值value
insert pos value    //表示向链表的pos位置插入值value(pos下标从零开始，既pos ＝ 0时表示链表的第一个元素)
erase pos    //表示删除链表在pos位置的元素(pos下标从0开始)
get_value pos     //打印链表在pos位置的元素的值
size     //打印链表的大小，占一行
empty     //若链表为空，打印true，不为空，打印false，占一行。
print     //遍历链表，打印链表中所有元素的值，每个值之间用空格间隔，占一行。
clear      //清空链表中的所有元素
destroy     //销毁链表，表示打印结束,输出destroy 
Input
若题意所示，只有一组测试数据，以init_list为开始，以destroy为程序的结束。
Output
如题意所示，每组输出占一行
Sample Input
init_list
push_back 1
push_back 2
push_back 3
print
size
empty
push_front -1
print
insert 1 0
print
clear
empty
destroy
Sample Output
1 2 3
3
false
-1 1 2 3
-1 0 1 2 3
true
destroy*/
#include <iostream>

using namespace std;

struct S
{
	S *prov;
	S *next;
	int data;
};

struct List
{
	int size;
	S *head;
	S *tail;
};

List *Head()
{
	List *h = (List *)malloc(sizeof(List));
	int size = 0;
	h->head = NULL;
	h->tail = NULL;
	return h;
}

void push_back(List *l, int value)
{
	S *b = (S *)malloc(sizeof(S));
	b->prov = NULL;
	b->next = NULL;
	b->data = value;
	if (l->size)
	{
		b->prov = l->tail;
		l->tail->next = b;
		l->tail = b;
	}
	else
	{
		l->tail = b;
		l->head = b;
	}
	l->size++;
}

void push_front(List *l, int value)
{
	S *f = (S *)malloc(sizeof(S));
	f->prov = NULL;
	f->next = NULL;
	f->data = value;
	if (l->size == 0)
	{
		push_back(l, value);
	}
	else
	{
		f->next = l->head;
		l->head = f;
		l->size++;
	}
}

void insert(List *l, int pos, int value)
{
	if (pos == 0)
	{
		push_front(l, value);
	}
	else if (pos == l->size)
	{
		push_back(l, value);
	}
	else
	{
		S *i = (S *)malloc(sizeof(S));
		i->data = value;
		i->next = NULL;
		i->prov = NULL;
		S *m = l->head;
		for (int j = 1; j < pos; j++)
		{
			m = m->next;
		}
		i->prov = m;
		i->next = m->next;
		m->next = i;
		i->next->prov = i;
		l->size++;
	}
}

void pop_back(List *l)
{
	if (l->size == 1)
	{
		free(l->head);
		l->head = NULL;
		l->tail = NULL;
		l->size--;
	}
	else if (l->size > 1)
	{
		l->tail = l->tail->prov;
		free(l->tail->next);
		l->tail->next = NULL;
		l->size--;
	}
}

void pop_front(List *l)
{
	if (l->size > 1)
	{
		l->head = l->head->next;
		free(l->head->prov);
		l->head->prov = NULL;
		l->size--;
	}
	else if (l->size == 1)
	{
		pop_back(l);
	}
}

void erase(List *l, int pos)
{
	if (pos == 0)
	{
		pop_front(l);
	}
	else if (pos == l->size - 1) //!!!!!!!
	{
		pop_back(l);
	}
	else if (pos > 0 && pos < l->size)
	{
		S *m = l->head;
		for (int i = 0; i < pos; i++)
		{
			m = m->next;
		}
		m->prov->next = m->next;
		m->next->prov = m->prov;
		free(m);
		l->size--;
	}
}

int get_value(List *l, int pos)
{
	S *m = l->head;
	for (int i = 0; i < pos; i++)
	{
		m = m->next;
	}
	return m->data;
}
int size(List *l)
{
	return l->size;
}

bool empty(List *l)
{
	return l->size == 0; // if(l->size==0)
						 // {
						 // 	return true;
						 // }
						 // else
						 // {
						 // 	return false;
						 // }
}

void print(List *l)
{
	S *m = l->head;
	for (int i = 0; i < l->size; i++)
	{
		if (i != 0)
		{
			cout << ' ';
		}
		cout << m->data;
		m = m->next;
	}
	cout << endl;
}

void clear(List *l)
{
	S *m = l->head;
	for (int i = 0; i < l->size - 1; i++)
	{
		m = m->next;
		free(m->prov);
	}
	free(m);
	l->size = 0;
	l->head = NULL;
	l->tail = NULL;
}

void destroy(List *l)
{
	clear(l);
	free(l);
}

int main()
{
	ios::sync_with_stdio(false);
	cin.tie(0);

	char a[100];
	List *l;
	while (scanf("%s", a) != EOF)
	{
		if (strcmp(a, "init_list") == 0)
			l = Head(); //!!!!!!!!!!!!!!!!!!!
		else if (strcmp(a, "push_back") == 0)
		{
			int value;
			scanf("%d", &value);
			push_back(l, value);
		}
		else if (strcmp(a, "push_front") == 0)
		{
			int value;
			scanf("%d", &value);
			push_front(l, value);
		}
		else if (strcmp(a, "insert") == 0)
		{
			int value, pos;
			scanf("%d%d", &pos, &value);
			insert(l, pos, value);
		}
		else if (strcmp(a, "erase") == 0)
		{
			int pos;
			scanf("%d", &pos);
			erase(l, pos);
		}
		else if (strcmp(a, "get_value") == 0)
		{
			int pos;
			scanf("%d", &pos);
			cout << get_value(l, pos) << endl;
		}
		else if (strcmp(a, "size") == 0)
		{
			cout << size(l) << endl;
		}
		else if (strcmp(a, "empty") == 0)
		{
			if (empty(l))
			{
				cout << "true";
			}
			else
			{
				cout << "false";
			}
			cout << endl;
		}
		else if (strcmp(a, "print") == 0)
		{
			print(l);
		}
		else if (strcmp(a, "clear") == 0)
		{
			clear(l);
		}
		else if (strcmp(a, "destroy") == 0)
		{
			destroy(l);
			cout << "destroy" << endl;
			break;
		}
	}
	return 0;
}
