/*输入10个数，找出其中绝对值    b=abs(a);    最小的数，将它和最后一个数交换，然后输出这10个数。
Input
十个数
Output
交换后的十个数
Sample Input
10 2 30 40 50 60 70 80 90 100
Sample Output
10 100 30 40 50 60 70 80 90 2*/
#include <iostream>
#include <cmath>

using namespace std;

int main()
{
	ios::sync_with_stdio(false);
	cin.tie(0);

	double a[21]={0},b;
	int min;
	for(int i=0;i<10;i++)
	{
		scanf("%lf",&a[i]);
		if(i==0)
		{
			min=0;
		}
		// min = abs(a[min]) < abs(a[i]) ? min : i;
		if(abs(a[min]) > abs(a[i]))
			min = i;
	}
	double t;
	t=a[min];
	a[min]=a[9];
	a[9]=t;
	for(int i=0;i<10;i++)
	{
		if(i)
			putchar(' ');
		printf("%.lf",a[i]);
	}
	return 0;
}