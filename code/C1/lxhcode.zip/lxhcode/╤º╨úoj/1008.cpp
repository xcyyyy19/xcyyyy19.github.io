/*你的任务是计算一些整数的总和。
输入
输入包含多个测试用例，一个用例一行。 每个情况都以一个整数N开始，然后N个整数跟在同一行。
产量
对于每个测试用例，您应该在一行中输出N个整数的总和，并在输入中输出每行的一行输出。
示例输入
4 1 2 3 4
5 1 2 3 4 5
示例输出
10
15*/
#include <iostream>

using namespace std;

int main()
{
	ios::sync_with_stdio(false);
	cin.tie(0);

	int n, a, sum = 0;
	while (scanf("%d", &n) != EOF)
	{
		for (int i = 0; i < n; i++)
		{
			scanf("%d", &a);
			sum += a;
		}
		printf("%d\n", sum);
		sum = 0;
	}
	return 0;
}