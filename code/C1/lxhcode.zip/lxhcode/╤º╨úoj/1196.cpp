/*输入20个整数，输出其中能被数组中其它元素整除的那些数组元素。
Sample Input
2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19 20 21
Sample Output
4
6
8
9
10
12
14
15
16
18
20
21*/
#include <cstdio>
#include <iostream>
#include <algorithm>

using namespace std;

int main()
{
	int arr[20];
	sort(arr, arr + 20, less<int>());
	for(int i = 10;i < 20;i++)
	{
		for(int j = 0; j < 10; i++)
		{
			if(arr[i]%arr[j]==0)
			{
				printf("%d",arr[i]);
			}
		}
	}
	return 0;
}