/*编制程序，统计文本中字符$出现的次数，并将结果输出
$次数
Sample Input
as$dfkjhkjkjdhf
asdfkj$lskdfj
werijweirjo$wie
Sample Output
3*/
#include <iostream>
#include <cstring>
using namespace std;

int main()
{
	ios::sync_with_stdio(false);
	cin.tie(0);

	char arr[1000];
	int i = 0, j = 0, m = 0;
	while (scanf("%c", &arr[i]) != EOF)
		i++;
	for (m = 0; m < i; m++)
	{
		if (arr[m] == '$')
			j++;
	}
	cout << j << endl;
	return 0;
}