/*This is the first problem for test. Since all we know the ASCII code, your job is simple: Input numbers and output corresponding messages.
Input

The input will contain a list of positive integers separated by whitespaces(spaces, newlines, TABs). Please process to the end of file (EOF). The integers will be no less than 32.
Output

Output the corresponding message. Note there is NOT a newline character in the end of output.
Sample Input

72 101 108 108 111 44
32 119 111 114 108 100 33
Sample Output

Hello, world!*/
#include <stdio.h>

int main()
{
	int arr[100], i = 0;
	while (scanf("%d", &arr[i++]) != EOF) //for (int i = 0; scanf("%d", &arr[i]) != EOF; i++)
	{
		printf("%c", arr[i - 1]);
	}
	return 0;
}