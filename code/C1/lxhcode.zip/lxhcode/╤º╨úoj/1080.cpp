/*分别用函数和带参的宏，从三个数中找出最大的数。
Input
3个实数
Output
最大的数,输出两遍，先用函数，再用宏。 保留3位小数。
Sample Input
1 2 3
Sample Output
3.000
3.000*/
#include <stdio.h>
int main(void)
{
	double a, b, c;
	scanf("%lf%lf%lf", &a, &b, &c);
	if (a > b && a >= c)
	{
		printf("%.3lf\n", a);
		printf("%.3lf\n", a);
	}
	else if (b >= a && b > c)
	{
		printf("%.3lf\n", b);
		printf("%.3lf\n", b);
	}
	else if (c > a && c >= b)
	{
		printf("%.3lf\n", c);
		printf("%.3lf\n", c);
	}
	return 0;
}