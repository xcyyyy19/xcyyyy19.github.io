/*请设计输出实数的格式，包括：⑴一行输出一个实数；⑵一行内输出两个实数；⑶一行内输出三个实数。实数用"6.2f"格式输出。
Input
一个实数，float范围
Output
输出3行，第一行打印一遍输入的数，第二行打印两遍，第三行打印三遍。 第二行和第三行，用空格分隔同一行的数字。 实数用"6.2f"格式输出。
Sample Input
0.618
Sample Output
  0.62
  0.62   0.62
  0.62   0.62   0.62*/
#include <iostream>

using namespace std;

int main()
{
	ios::sync_with_stdio(false);
	cin.tie(0);

	float a;
	cin >> a;
	for (int i = 0; i < 3; i++)
	{
		for (int j = 0; j <= i; j++)
		{
			if (j)
				printf(" ");
			printf("%6.2f", a);
		}
		printf("\n");
	}
	return 0;
}