/*有两个矩形在平面坐标系上, 它们可能相交.
它们坐标均在整数位上, 且每条边与x轴或y轴平行
如果相交则输出它们相交的面积,无相交面积就是0
input
共两行,每行为矩形的对角的两个点的坐标
- x11 y11 x12 y12
- x21 y21 x22 y22
output
- 输出它们相交的面积
Simple1
input
0 0 2 2
1 1 3 3
output
1
Simple2
input
0 0 2 2
5 5 3 3
output
0
Tips
输入的坐标值在 (-1000, 1000) 之内*/
#include <iostream>

using namespace std;

int main()
{
	ios::sync_with_stdio(false);
	cin.tie(0);

	
	return 0;
}