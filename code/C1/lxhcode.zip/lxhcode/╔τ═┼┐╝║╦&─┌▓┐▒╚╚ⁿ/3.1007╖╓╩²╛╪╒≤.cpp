/*我们定义如下矩阵:
1/1 1/2 1/3
1/2 1/1 1/2
1/3 1/2 1/1
矩阵对角线上的元素始终是1/1，对角线两边分数的分母逐个递增。
请求出这个矩阵的总和。
Input
每行给定整数N (N<50000)，表示矩阵为 N*N.当N为0时，输入结束。
Output
输出答案，保留2位小数。
Sample Input
1
2
3
4
0
Sample Output
1.00
3.00
5.67
8.83*/
#include <iostream>

using namespace std;

int main()
{
	ios::sync_with_stdio(false);
	cin.tie(0);

	int n, j;
	double sum = 0;
	while (scanf("%d", &n) != EOF && n != 0)
	{
		for (int i = 2, j = n - 1; i < n; i++, j--)
		{
			sum += (1.0 / j) * i * 2;
		}
		if (n == 1)
		{
			cout << "1.00" << endl;
			continue;
		}
		else
		{
			sum = sum + 2.0 / n + n;
		}
		printf("%.2lf\n", sum);
		sum = 0;
	}
	return 0;
}