/*一组正整数的最小公倍数（LCM）是可被该组中所有数字整除的最小正整数。 例如，5,7和15的LCM是105。
输入
输入将包含多个问题实例。 输入的第一行将包含一个表示问题实例数量的整数。 
每个实例将由m n1 n2 n3 ... nm形式的单行组成，其中m是集合中的整数数量，n1 ... nm是整数。 所有的整数都是正数，位于32位整数的范围内。
产量
对于每个问题实例，输出包含相应LCM的单个行。 所有结果将在32位整数的范围内。
示例输入
2
3 5 7 15
6 4 10296 936 1287 792 1
示例输出
105
10296
资源
东中北美2003年，实践*/

#include <iostream>

using namespace std;

long long _gcd(long long a, long long b)
{
	if (!b)
		return a;
	return _gcd(b, a % b);
}

long long gcd(long long a, long long b)
{
	if (a < 0 || b < 0)
		return -_gcd(abs(a), abs(b));
	return _gcd(a, b);
}

int main()
{
	ios::sync_with_stdio(false);
	cin.tie(0);

	long long n, n2, a[10005], k, q;
	cin >> n;
	for (int i = 0; i < n; i++)
	{
		cin >> n2;
		for (int j = 0; j < n2; j++)
		{
			cin >> a[j];
		}
		if (n2 == 1)
		{
			cout << a[0] << endl;
			continue;
		}
		q = a[0] * a[1] / gcd(a[0], a[1]);
		for (k = 2; k < n2; k++)
		{
			q = q * a[k] / gcd(q, a[k]);
		}
		cout << q << endl;
	}
	return 0;
}