/*输入一个字符串，判断其是否是C的合法标识符。
Input
输入数据包含多个测试实例，数据的第一行是一个整数n,表示测试实例的个数，然后是n行输入数据，每行是一个长度不超过50的字符串。
Output
对于每组输入数据，输出一行。如果输入数据是C的合法标识符，则输出"yes"，否则，输出“no”。
Sample Input
3
12ajf
fi8x_a
ff  ai_2
Sample Output
no
yes
no*/
#include <iostream>
#include <string>
using namespace std;

int main()
{
	ios::sync_with_stdio(false);
	cin.tie(0);

	int n, flag = 0, j = 0;
	cin >> n;
	cin.get();
	for (int i = 0; i < n; i++)
	{
		string S;
		getline(cin, S);
		for (j = 0; j < S.size(); j++)
		{
			if (flag == 0)
			{
				if (('a' <= S[j] && 'z' >= S[j]) || ('Z' >= S[j] && 'A' <= S[j]) || (S[j] == '_'))
				{
					flag = 1;
					continue;
				}
				else
				{
					cout << "no" << endl;
					break;
				}
				flag = 1;
			}
			if ((S[j] >= '0' && '9' >= S[j]) || ('a' <= S[j] && 'z' >= S[j]) || ('Z' >= S[j] && 'A' <= S[j]) || (S[j] == '_'))
			{
				continue;
			}
			else
			{
				cout << "no" << endl;
				break;
			}
				}
		flag = 0;
		if (j == S.size())
		{
			cout << "yes" << endl;
		}
	}
	return 0;
}