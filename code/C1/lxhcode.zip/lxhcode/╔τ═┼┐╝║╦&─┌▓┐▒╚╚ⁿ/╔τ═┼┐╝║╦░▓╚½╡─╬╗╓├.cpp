/*一天，有n个人玩游戏玩输了，而心吾就是这n个人之一。他们需要接受惩♂罚，
他们要站成一个圈，然后从第一个人开始一二报数，报到二的人就要退出圆圈去和夏迪摔♂跤。
只有最后剩下来的那一个人可以免受惩♂罚，因为心吾并不想跟夏迪摔♂跤，所以，
他希望你能够帮帮他，请你告诉他一开始站在第几个位置上，才能够逃脱夏迪的魔♂爪。
Input
输入只有一个值 n (2<=n<=50000)
Output
输出只有一个数，是安全的位置的位置的编号。      
(编号是从1开始的。
Sample 1
Input
10
Output
5*/
#include <iostream>

using namespace std;

int f(int i)
{
	if (i == 1)
		return 0;
	else
		return (f(i - 1) + 77) % i;
}

int main()
{
	ios::sync_with_stdio(false);
	cin.tie(0);
	int n = 8888;
	//cin >> n;
	cout << f(n) + 1;

	return 0;
}