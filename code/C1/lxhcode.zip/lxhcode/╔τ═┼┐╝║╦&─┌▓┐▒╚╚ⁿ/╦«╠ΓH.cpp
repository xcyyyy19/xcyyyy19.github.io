/*第一行输入一个整数n，第二行输入2n-1个整数ti表示每个人所投的成员编号，输入保证必定得票数超过n的成员，
其中1 <= n, ti <= 100
Output
输出得票数超过n的那位成员的编号
Sample Input
5
4 6 6 9 6 8 7 6 6
Sample Output
6*/
#include <iostream>
#include <algorithm>

using namespace std;

int main()
{
	ios::sync_with_stdio(false);
	cin.tie(0);

	int n, a[1000];
	while (cin >> n)
	{
		n = 2 * n - 1;
		for (int i = 0; i < n; i++)
		{
			cin >> a[i];
		}
		sort(a, a + n, less<int>());
		if (n % 2 == 0)
		{
			if (a[n / 2] == a[n / 2 - 1])
			{
				cout << a[n / 2] << endl;
			}
			else
			{
				if (a[n / 2 - 1] == a[0])
					cout << a[n / 2 - 1] << endl;
				else
					cout << a[n / 2] << endl;
			}
		}
		else
		{
			cout << a[n / 2] << endl;
		}
	}
	return 0;
}