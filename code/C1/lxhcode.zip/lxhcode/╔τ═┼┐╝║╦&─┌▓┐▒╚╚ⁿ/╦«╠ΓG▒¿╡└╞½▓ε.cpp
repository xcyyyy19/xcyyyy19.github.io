/*是不是没有太明白？低头看看你的键盘（QWERTY键盘，不是的话看坐你旁边老铁的键盘），
比如右偏差量=2，原文字母是R的时候，实际输入到电脑中的是Y，同理，G->J B->M  A->D，
现在给你一串字符串，字符串没有空格，并给出偏差量，偏差量为正代表往左偏差，偏差量为负代表往右偏差。
Input
多组数据，第一行n代表有n组数据 1≤n≤10 对于每组数据，都有两行 第一行一个整数s，代表偏差量 |s|≤5 第二行一行字符串，字符串保证全都是小写字母，无空格等其他字符，字符串长度≤50
Output
N行，每行代表修正偏差后的字符串
Sample Input
2
1
qwerasdfzxc
-1
poilkjmnb
Sample Output
wertsdfgxcv
oiukjhnbv*/
#include <iostream>
#include <string>

using namespace std;

int main()
{
	ios::sync_with_stdio(false);
	cin.tie(0);

	int n, k;
	string s;
	cin >> n;
	for (int i = 0; i < n; i++)
	{
		cin >> k;
		getline(cin, s);
		if (k > 0)
		{
			for (int j = 0; j < s.size(); j++)
			{
				cout << s[j];
			}
		}
	}

	return 0;
}