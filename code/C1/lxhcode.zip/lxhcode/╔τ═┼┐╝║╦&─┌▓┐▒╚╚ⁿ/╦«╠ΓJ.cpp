/*2、3、5是素数。
6、30是合数但它们所有的质因数两两不同；12、18也是合数它们的质因数有重复，
例如12=2*2*3、18=2*3*3。给你一个数n，如果n是素数输出1，n是6那样的合数输出2，否则输出3。
输入
一组整数以0结束
输出
输出每个数的分类信息。
样例输入
2 6 12 0
样例输出
123*/
#include <stdio.h>
#include <string.h>
#include <algorithm>
#include <iostream>

using namespace std;
int main()
{
	char k[100] = {0};
	int n, j, i = 2, m = 0, flag = 0;
	while (scanf("%d", &n) != EOF && n != 0)
	{
		for (j = 2; j < n; j++)
		{
			if (n % j == 0)
				break;
		}
		if (n == j)
		{
			printf("1");
		}
		else
		{
			if (n == 1 || n == 0)
			{
				printf("3");
			}
			while (n != 1 && n != 0)
			{
				if (n % i == 0)
				{
					n /= i;
					k[m] = i;
					m++;
				}
				else if (n % i == 1)
				{
					break;
				}
				else
				{
					i++;
					m++;
				}
			}
			for (int p = 1; p < m; p++)
			{
				sort(k, k + m, less<int>());
				for (int q = 0; q < m; q++)
				{
					if (q == m - 1)
					{
						flag = 1;
					}
					if (flag == 1)
					{
						if (k[q] != k[q + 1])
						{
							printf("");
						}
					}
					if (k[q] == k[q + 1])
					{
						break;
					}
					else
					{
						continue;
					}
				}
			}
		}
	}
	return 0;
}