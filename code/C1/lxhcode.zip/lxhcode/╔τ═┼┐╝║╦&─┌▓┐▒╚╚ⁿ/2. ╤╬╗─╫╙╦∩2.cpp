/*没有盐，做饭只能用酱油。 将所有的salt替换为soy sauce，不管大小写。 Input
包含salt的英文语料
Output
用soy sauce替换salt后的输出
Sample Input
Salt is necessary
Water is not sAlt as salT
as you can make it soy - bean
sauce can be saLt
soy -
bean sauce only
bean soy -
bean sauce

Sample Output
soy sauce is necessary
Water is not soy sauce as soy sauce
as you can make it soy -
bean
sauce can be soy sauce
soy -
bean sauce only
bean soy -
bean sauce*/

#include <stdio.h>
#include <string.h>
#include <ctype.h>

int main()
{
	int m = 0;
	char arr[100000] = {0}; //strlen 读的是字符串，有\0的
	while (scanf("%c", &arr[m]) != EOF)
	{
		m++;
	}

	for (int j = 0; j < strlen(arr); j++)
	{
		if (tolower(arr[j]) == 's' && tolower(arr[j + 1]) == 'a' && tolower(arr[j + 2]) == 'l' && tolower(arr[j + 3]) == 't')
		{
			printf("soy sauce");
			j = j + 3;
		}
		else
		{
			printf("%c", arr[j]);
		}
	}

	return 0;
}