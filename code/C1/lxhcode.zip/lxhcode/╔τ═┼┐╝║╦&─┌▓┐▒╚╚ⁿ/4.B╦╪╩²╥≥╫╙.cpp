/*一个大于6的偶数，都可以写成多个素数相乘的结果。例如120=2*2*2*3*5。编写程序，求出任意给定的大于6的偶数的素数因子乘式。
Input
有若干组测试数据。每一行是一个大于6的偶数N。
Output
每行输出一个等式。
Sample Input
24
26
120
Sample Output
24=2*2*2*3
26=2*13
120=2*2*2*3*5*/
#include <stdio.h>

int main()
{
	int a;
	int i = 2;
	scanf("%d", &a);
	while (a != 1)
	{
		if (a % i == 0)
		{
			a /= i;
			printf("%d ", i);
		}
		else
			i++;
	}
	return 0;
}