/*校园里沿着马路种了一排树，不同的区域种的树品种各不相同，柳树、梧桐等等。
每种树的高度各不相同。龙哥现在想知道校园里所有的树加在一起有多高，但他懒得去统计，所以这个活就让你来干了。
输入
多组数据
每组数据第一行一个n，代表有n棵树。
接下来一行有n个数字，代表每棵树的高度。
(1<=n<2^31,0<=高度<=2^31)
输出
对于每组输入数据，输出一行，所有树的高度和
样例输入
5
1 2 3 4 5
样例输出
15*/
#include <iostream>

using namespace std;

int main()
{

	int n;
	unsigned long long a[100], sum = 0;
	while (scanf("%d", &n) != EOF)
	{
		for (int i = 0; i < n; i++)
		{
			cin >> a[i];
			sum += a[i];
		}
		cout << sum << endl;
		sum = 0;
	}
	return 0;
}