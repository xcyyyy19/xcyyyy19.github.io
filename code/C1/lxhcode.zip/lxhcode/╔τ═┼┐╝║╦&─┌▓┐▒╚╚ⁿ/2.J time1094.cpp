/*数字时钟使用4位数字表示时间，每个数字用3 * 3个字符（包括“|”，“_”和“”）来表示。现在给出当前时间，请告诉我们如何用数字时钟表示。
输入
有几个测试用例。
每个案例在一行中包含4个整数，由空格分隔。
继续文件的结尾。
示例输入
1 2 5 6
2 3 4 2
示例输出
     _ _ _
  | _ || _ | _
   || _ _ || _ |
  _ _ _
 _|_||_|_|
| _ _ |||_*/
#include <iostream>
#define Print(top, x) printf("%c%c%c", top[x * 3], top[x * 3 + 1], top[x * 3 + 2]);

using namespace std;

int main()
{
	ios::sync_with_stdio(false);
	cin.tie(0);
	int arr[10];
	char *top = " _     _  _     _  _  _  _  _ "; //字符串特殊，直接储存在rodata区。
	char *mid = "| |  | _| _||_||_ |_   ||_||_|";
	char *tai = "|_|  ||_  _|  | _||_|  ||_| _|";
	while (scanf("%d%d%d%d", arr, arr + 1, arr + 2, arr + 3) != EOF)
	{
		Print(top, arr[0]);
		Print(top, arr[1]);
		Print(top, arr[2]);
		Print(top, arr[3]);
		printf("\n");
		Print(mid, arr[0]);
		Print(mid, arr[1]);
		Print(mid, arr[2]);
		Print(mid, arr[3]);
		printf("\n");
		Print(tai, arr[0]);
		Print(tai, arr[1]);
		Print(tai, arr[2]);
		Print(tai, arr[3]);
		printf("\n");
	}

	return 0;
}