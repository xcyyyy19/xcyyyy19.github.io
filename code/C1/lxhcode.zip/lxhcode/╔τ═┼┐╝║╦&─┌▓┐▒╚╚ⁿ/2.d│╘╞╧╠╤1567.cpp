/*输入的第一行有两个整数L（1 <= L <= 1000）和 M（1 <= M <= 10），L代表马路的长度，M代表区域(葡萄架)的数目，L和M之间用一个空格隔开。接下来的M行每行包含两个不同的整数，用一个空格隔开，表示一个区域的起始点和终止点的坐标。
Output
输出包括一行，这一行只包含一个整数，表示马路上剩余的有葡萄的葡萄架的数目。
Sample Input
200 3
150 170
100 200
5 10
Sample Output
94*/
#include <iostream>

using namespace std;

int main()
{
	ios::sync_with_stdio(false);
	cin.tie(0);

	int l, m, s, e, sum = 0, arr[1005];
	for (int i = 0; i < 1005; ++i)
	{
		arr[i] = 1;
	}
	scanf("%d%d", &l, &m);
	for (int i = 0; i < m; i++)
	{
		scanf("%d %d", &s, &e);
		for (int j = s; j <= e; j++)
		{
			arr[j] = 0;
		}
	}
	for (int k = 0; k <= l; k++)
	{
		sum += arr[k];
	}
	printf("%d\n", sum);
	return 0;
}