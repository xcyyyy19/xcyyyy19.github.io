/*十进制数 13，表示为十进制、二进制、七进制分别是 13、1101、16，含义是13=3*1+1*10；13=1*1+0*2+1*4+1*8；13=6*1+1*7。
Input
输入 若干行，每行两个数 R （1
Output
输出 若干行，与输入对应，即N在R进制下的表示，如果R超过10，数符以小写字母补充，例如36进制下数符为0~9a~z。
Sample Input
10 13
2  13
7  13
13 13
20 13
0 0
Sample Output
13
1101
16
10
d*/
#include <iostream>
#include <stack>

using namespace std;

int main()
{
	stack<int> s;

	int i, n, m;
	while (scanf("%d%d", &i, &n) && (i != 0 || n != 0))
	{
		if (n < 0)
		{
			cout << '-';
			n = -n;
		}
		do
		{
			s.push(n % i);
			n /= i;
		} while (n);

		while (s.size())
		{
			if (s.top() >= 10)
			{
				s.top() = s.top() - 10 + 'a';
				cout << (char)s.top();
			}
			else
				cout << s.top();
			s.pop();
		}
		cout << endl;
	}
	return 0;
}
