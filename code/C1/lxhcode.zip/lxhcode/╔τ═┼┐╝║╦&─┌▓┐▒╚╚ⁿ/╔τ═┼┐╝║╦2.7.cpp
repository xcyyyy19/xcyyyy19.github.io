/*这些数据中会有重复的数字，请你去重并排降序。
input
1 1 2 2 3 3 4 5 6 6
output
6 5 4 3 2 1 
读入以EOF作为结束
输出时每个数字后有一个空格*/

#include <iostream>
#include <algorithm>
#include <cstring>

using namespace std;

int main()
{
	ios::sync_with_stdio(false);
	cin.tie(0);
	int arr[1000] = {0};
	int i = 0, j = 0;
	while (scanf("%d", &arr[i]) != EOF)
	{
		++i;
	}
	sort(arr, arr + i, greater<int>());
	cout << arr[0];
	for (j = 1; j < i; j++)
	{
		if (arr[j] != arr[j - 1])
		{
			cout << ' ' << arr[j];
		}
	}
	return 0;
}
