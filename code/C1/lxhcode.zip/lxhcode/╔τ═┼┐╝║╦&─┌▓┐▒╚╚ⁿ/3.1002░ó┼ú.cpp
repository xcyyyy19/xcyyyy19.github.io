/*阿牛从家里拿来了一块上等的牛肉干，准备在上面刻下一个长度为n的只由"E" "O" "F"三种字符组成的字符串
（可以只有其中一种或两种字符，但绝对不能有其他字符）,阿牛同时禁止在串中出现O相邻的情况，他认为，"OO"看起来就像发怒的眼睛，效果不好。
你，NEW ACMer,EOF的崇拜者，能帮阿牛算一下一共有多少种满足要求的不同的字符串吗？
Input
输入数据包含多个测试实例,每个测试实例占一行,由一个整数n组成，(0<n<40)。
Output
对于每个测试实例，请输出全部的满足要求的涂法，每个实例的输出占一行。
Sample Input
1
2
Sample Output
3
8*/
#include <iostream>

using namespace std;

int main()
{
	ios::sync_with_stdio(false);
	cin.tie(0);

	
	return 0;
}

// #include <iostream>

// using namespace std;

// int main()
// {
// 	ios::sync_with_stdio(false);
// 	cin.tie(0);

// 	long long a[100], k[100];
// 	a[0] = 3;
// 	k[0] = 1;
// 	int n;

// 	while (scanf("%d", &n) != EOF)
// 	{
// 		if (n == 1)
// 		{
// 			cout << '3' << endl;
// 			continue;
// 		}
// 		for (int i = 1; i < n; i++)
// 		{
// 			k[i] = a[i - 1] - k[i - 1];
// 			a[i] = k[i] * 3 + k[i - 1] * 2;
// 		}
// 		cout << a[n - 1] << endl;
// 	}
// 	return 0;
// }