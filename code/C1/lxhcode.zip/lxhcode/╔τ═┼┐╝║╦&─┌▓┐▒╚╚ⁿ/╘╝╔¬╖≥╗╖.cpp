#include <stdio.h>

int fun(int n, int i, int m1, int m2)
{
	if (n == 1)
		return 0;

	if (i % 2)
		return (fun(n - 1, i + 1, m1, m2) + m1) % n;
	else
		return (fun(n - 1, i + 1, m1, m2) + m2) % n;
}

int main()
{
	int n, m1, m2;
	while (scanf("%d", &n) != EOF)
	{
		scanf("%d%d", &m1, &m2);
		printf("%d\n", fun(n, 1, m1, m2) + 1);
	}
	return 0;
}