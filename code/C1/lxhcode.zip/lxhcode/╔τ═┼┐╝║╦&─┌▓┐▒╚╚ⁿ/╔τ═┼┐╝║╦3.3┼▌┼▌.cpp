/*张大佬最近迷上了一个弱智游戏.
这个游戏规则是 
你每次可以指定两个泡泡进行融合成一个, 这个操作会消耗它们两个的质量之和大小的能量
一直进行上述操作, 直到还剩一个泡泡时, 停止游戏, 能量消耗最少的胜利
当然这个游戏很简单,他知道技巧后,每次都赢得了胜利
input
- 第一行 只有一个数字n, 表示游戏开始时泡泡的个数
- 第二行 有n个数, 表示每个泡泡的质量大小
output
- 所消耗最少的能量
Simple
input
5
2 3 1 4 6 
output
35
所有数均为正整数, 1 < n < 1000
保证结果在int范围*/
#include <iostream>

using namespace std;

int main()
{
	ios::sync_with_stdio(false);
	cin.tie(0);
	int arr[1000], i = 0, n = 0,sum;
	while (scanf("%d", &arr[i]) != EOF)
	{
		++i;
	}
	sort(arr, arr + i, less<int>());
	for(int k=0;k<i;k++)
	{
		int flag=k;
		int p = arr[k] + arr[k+1];
		while(1)
		{ 
			if (p <= arr[flag+2])
			{
				arr[flag+1] += p;
				break;
			}
			else
			{
				flag++;
			}
		}
	}
	return 0;
}