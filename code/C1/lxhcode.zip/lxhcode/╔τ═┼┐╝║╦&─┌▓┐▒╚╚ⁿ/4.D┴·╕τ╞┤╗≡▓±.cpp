/*龙哥喜欢拼火柴是众所周知的事情。现在他得到了4根火柴，但是这些火柴的长度是随机的，他很想知道能不能用这些火柴拼成一个四边形。
Input
第一行T，表示有T组数据。
接下来T组数据，每组数据包含四个整数 a,b,c,d，分别为四根巨型火柴的长度。
(1<=T<=1000,0<=a,b,c,d<=2^63-1)
Output
对于每个数据，如果能拼成一个四边形，输出“Yes”；否则输出“No”（不包括双引号）。
Sample Input
2
1 1 1 1
1 1 9 2
Sample Output
Yes
No
构成四边形的条件是任意三边之和大于第四边*/
#include <iostream>
#include <cstdlib>
using namespace std;

int main()
{
	ios::sync_with_stdio(false);
	cin.tie(0);

	int n;
	cin >> n;
	for (int i = 0; i < n; i++)
	{
		//cin >> a >> b >> c >> d;
		unsigned long long k[4]; // = {a, b, c, d};
		cin >> k[0] >> k[1] >> k[2] >> k[3];
		sort(k, k + 4, less<unsigned long long>());
		if (k[0] != 0 && (k[0] + k[1] > k[3] - k[2]))
		{
			cout << "Yes" << endl;
		}
		else
		{
			cout << "No" << endl;
		}
	}
	return 0;
}