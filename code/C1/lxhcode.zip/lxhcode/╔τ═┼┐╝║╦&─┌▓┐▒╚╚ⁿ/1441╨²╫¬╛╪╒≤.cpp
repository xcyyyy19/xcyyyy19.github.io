/*显示旋转矩阵
Input
正奇数n，以0结束
Output
显示n*n的矩阵，从1开始，逆时针旋转，每行两个数据使用空格分隔，最后的数字后无空格，具体见例子
Sample Input
1
5
3
0
Sample Output
1
1 16 15 14 13
2 17 24 23 12
3 18 25 22 11
4 19 20 21 10
5 6 7 8 9
1 8 7
2 9 6
3 4 5*/
#include <iostream>
#include <cstdio>

using namespace std;

int main()
{
	int dx[4] = {+0, +1, +0, -1};
	int dy[4] = {+1, +0, -1, +0};

	int n;
	while (scanf("%d", &n) != EOF)
	{
		int n2 = n * n;
		int x = 0, y = 0;
		int arr[n][n];
		int dir = 0;
		memset(arr, 0, sizeof(int) * n * n);
		for (int i = 1; i <= n2; ++i)
		{
			arr[x][y] = i;
			int nx = x + dx[dir], ny = y + dy[dir];
			if (nx < 0 || nx >= n || ny < 0 || ny >= n || arr[nx][ny])
			{
				dir = (dir + 1) % 4;
				nx = x + dx[dir];
				ny = y + dy[dir];
			}
			x = nx;
			y = ny;
		}
		for (int i = 0; i < n; ++i)
		{
			for (int j = 0; j < n; ++j)
			{
				if (j != 0)
				{
					printf(" ");
				}
				printf("%d", arr[j][i]);
			}
			cout << endl;
		}
	}
	return 0;
}