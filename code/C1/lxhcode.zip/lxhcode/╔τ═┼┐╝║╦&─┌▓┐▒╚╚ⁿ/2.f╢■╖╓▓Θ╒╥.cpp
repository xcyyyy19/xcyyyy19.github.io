/*给定一个从小到大的有序整数数列，再给定一个整数x, 编写程序， 
在有序数列中用二分法查找x, 输出查找到x所需要花费的比较次数，如果x不在序列中，
除了输出次数外，还要输出NO。 Input 输入数据包含多组测试数据。每组数据先是一个整数n, 
表示有序数列数的个数， 接着就是n个按从小到大排序好的整数。然后又是一个整数，表示待查找的数x。 
Output 
对于每组测试数据，输出在有序序列中查找到x需要的比较次数；如果没查找到x，也输出比较的次数，同时，还需要输出NO字样。
Sample Input 
Sample Output 3 3 
NO */
#include <stdio.h>

int fun(int x, int y, int *arr, int a)
{
	int sum = 0;
	int i = x + (y - x) / 2;
	if (x > y)
	{
		sum++;
		return 0;
	}
	else
	{
		if (arr[i] == a)
		{
			return sum;
			sum++;
		}
		else if (arr[i] > a)
		{
			return fun(x, i - 1, arr, a);
			sum++;
		}
		else
		{
			return fun(i + 1, y, arr, a);
			sum++;
		}
	}
}
int main()
{
	int a, x;
	int arr[1005];
	while (scanf("%d", &a) != EOF)
	{
		for (int i = 0; i < a; i++)
		{
			scanf("%d", &arr[i]);
		}
		scanf("%d", &x);
		if (fun(0, x, arr, a))
		{
			printf("%d", fun(0, x, arr, a));
		}
		else
		{
			printf("%d\n", fun(0, x, arr, a));
			printf("NO");
		}
	}
	return 0;
}
