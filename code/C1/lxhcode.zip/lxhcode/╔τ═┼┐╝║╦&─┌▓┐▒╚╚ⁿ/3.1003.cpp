/*给你两个数字A和B，如果A等于B，你应该打印“YES”，或打印“NO”。
输入
每个测试用例包含两个数字A和B.
产量
对于每种情况，如果A等于B，则应打印“是”，或打印“否”。
示例输入
1 2
2 2
3 3
4 3
示例输出
没有
是
是
没有
*/
#include <iostream>

using namespace std;

int main()
{
	ios::sync_with_stdio(false);
	cin.tie(0);

	
	return 0;
}