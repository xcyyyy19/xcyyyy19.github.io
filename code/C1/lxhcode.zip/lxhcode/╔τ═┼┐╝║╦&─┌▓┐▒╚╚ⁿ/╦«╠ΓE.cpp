/*这些列车有去往北京、天津方向的，我们称之为上行列车；
有去往上海、南京方向的，我们称之为下行列车。为了区分上下行车次，上行列车编为双数车次，
下行列车编为单数车次。如北京到上海T109次是下行列车，北京到南京T65次是下行列车；上海到北京1462次是上行列车，
上海到北京南D322次是上行列车。 现在已知停靠在车站的有若干列列车停靠你站，并知道他们已经晚点的时间，
现在你要对出站列车进行出站次序的调整，为了安抚旅客情绪，必须让晚点时间最长的车次优先出发；但是因为车站是双向的，
所以你需要给出上行列车的（去往北京天津方向）的出站顺序和下行列车（去往上海方向的）的出站顺序。
Input
第一行n，代表有n组列车等待出站1≤n≤100 接下来n行，每行两个字符串，第一个代表车次，第二个代表已经晚点时间（小时：分钟），
保证晚点的时间没有相同的，保证所有时间都在同一天。
Output
输出n+1行，先按顺序输出上行列车的出站序列 之后输出一行******* 之后再输出下行列车的出站序列
Sample Input
6
K102 8:32     8*60+32
1462 0:11
D322 6:12
T65 7:19
Z157 8:14
Z368 6:13*/
#include <iostream>
#include <algorithm>
#include <string.h>

using namespace std;

struct S
{
	char arr[100];
	double h;
	char sex;
} a[100];

void swap_arr(char *arr, char *ar)
{
	char a[1000] = {0};
	strcpy(a, arr);
	strcpy(arr, ar);
	strcpy(ar, a);
}
void swap_h(double *h, double *h2)
{
	double temp;
	temp = *h;
	*h = *h2;
	*h2 = temp;
}
void swap_sex(char *sex, char *se)
{
	char *temp;
	temp = sex;
	sex = se;
	se = temp;
}
void swap(struct S *a, struct S *b)
{
	swap_arr(a->arr, b->arr);
	swap_h(&(a->h), &(b->h));
	swap_sex(&a->sex, &b->sex);
}

int main()
{
	int n;
	cin >> n;
	for (int i = 0; i < n; i++)
	{
		cin >> a[i].arr[i] >> a[i].h >> a[i].sex;
	}
	for (int i = n; i > 0; i--)
	{
		for (int j = 0; j < n; j++)
		{
			if (a[j].arr[j] > a[j + 1].arr[j + 1])
			{
				swap(a[j], a[j + 1]);
			}
		}
	}
	return 0;
}