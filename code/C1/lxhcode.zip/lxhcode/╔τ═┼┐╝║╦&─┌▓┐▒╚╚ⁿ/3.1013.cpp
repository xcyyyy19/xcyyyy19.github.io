/*5
1 3 2 3 3
11
1 1 1 1 1 5 5 5 5 5 5
7
1 1 1 1 1 1 1
Sample Output
3
5
1*/
#include <iostream>
#include <algorithm>

using namespace std;

int main()
{
	ios::sync_with_stdio(false);
	cin.tie(0);

	int n, a[999999];
	while (cin >> n)
	{
		for (int i = 0; i < n; i++)
		{
			cin >> a[i];
		}
		sort(a, a + n, less<int>());
		if (n % 2 == 0)
		{
			if (a[n / 2] == a[n / 2 - 1])
			{
				cout << a[n / 2] << endl;
			}
			else
			{
				if (a[n / 2 - 1] == a[0])
					cout << a[n / 2 - 1] << endl;
				else
					cout << a[n / 2] << endl;
			}
		}
		else
		{
			cout << a[n / 2] << endl;
		}
	}
	return 0;
}