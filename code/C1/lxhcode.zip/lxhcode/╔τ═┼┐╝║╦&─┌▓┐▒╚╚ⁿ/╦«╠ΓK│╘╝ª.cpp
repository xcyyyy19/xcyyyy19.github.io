/*老朱经营一家养鸡场，每次肯德基的小凯来老朱厂里收N只鸡 (2≤N≤2^30,这个意思就是本题只用int就行)只鸡， 
老朱会把N只鸡提前编号号码从1到N5，并围成一个环。 老朱很重感情，但又重金钱。于是老朱决定在N只鸡里留下1只鸡。
决定留下哪只，由小凯决定，小凯会 随机说出 2个整数 M1 和 M2(2≤M1，M2≤2^30)，然后老朱开始从1号鸡点起， 
每次点到M1的鸡，被送上肯德基的车，被送上车的这只鸡的下一只鸡又从1点，这次点到M2的鸡被送上车。 
接着再从上车的下一只点，点到M1的送上车，再如此循环M2....M1....直到剩余最后一只鸡。 问最后剩的这只鸡 最初的编号是多少？
Input
input 输入三个整数 N M1 M2
Output
OUTPUT 活下来那只鸡的最初编号
Sample Input
5 2 3
8 6 3
Sample Output
1
2*/
#include <stdio.h>

int fun(int n, int i, int m1, int m2)
{
	if (n == 1)
		return 0;

	if (i % 2)
		return (fun(n - 1, i + 1, m1, m2) + m1) % n;
	else
		return (fun(n - 1, i + 1, m1, m2) + m2) % n;
}

int main()
{
	int n, m1, m2;
	while (scanf("%d", &n) != EOF)
	{
		scanf("%d%d", &m1, &m2);
		printf("%d\n", fun(n, 1, m1, m2) + 1);
	}

	return 0;
}
