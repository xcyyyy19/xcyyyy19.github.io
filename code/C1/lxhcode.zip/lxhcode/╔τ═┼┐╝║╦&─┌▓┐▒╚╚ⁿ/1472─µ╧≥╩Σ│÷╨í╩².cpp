/*如果读入是12.3456，显示6543.21；读入的1.00显示0.1
Input
若干个非0小数，以0结束
Output
一行一个，不含最后的0
Sample Input
12.3456 1.00 0
Sample Output
6543.21
0.1*/

#include <stdio.h>
#include <string.h>

int main()
{
	char arr[1000];
	while (scanf("%s", arr) != EOF && strcmp(arr, "0"))
	{
		int i;
		int len = strlen(arr);
		for (i = len - 1; i > 0; i--)
		{
			if (arr[i] != '0' || arr[i - 1] == '.')
			{
				break;
			}
		}
		while (i >= 0)
		{
			printf("%c", arr[i--]);
		}
	}
	return 0;
}