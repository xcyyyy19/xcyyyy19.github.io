#include <iostream>
#include <cstdlib>

using namespace std;

/*inline*/ void erase(int *arr, int *size, int pos) //内联函数
{
	for (int i = pos + 1; i < *size; ++i)
		arr[i - 1] = arr[i];
	(*size)--;
}

int main()
{
	ios::sync_with_stdio(false);
	cin.tie(0);

	int a[88888], i;

	return 0;
}