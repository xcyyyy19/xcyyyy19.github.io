/*统计a到b之间的闰年数，含a和b
Input
每行是a和b，0 0结束
Output
闰年个数
Sample Input
1995 1996
1996 1995
0 0
Sample Output
1
1*/
#include <stdio.h>

int main()
{
	int a, b, sum1 = 0, sum2 = 0, sum = 0;
	while (scanf("%d%d", &a, &b) && (b != 0 || a != 0))
	{
		if (a > b)
		{
			int temp;
			temp = a;
			a = b;
			b = temp;
		}
		sum1 = a / 4 - a / 100 + a / 400;
		sum2 = b / 4 - b / 100 + b / 400;
		sum = sum2 - sum1;
		if ((a % 4 == 0 && a % 100 != 0) || (a % 400 == 0))
			sum++;
		printf("%d\n", sum);
	}
	return 0;
}