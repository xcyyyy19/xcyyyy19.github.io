/*高数最重要的是什么?!当然是计算的准确性!但我们的龙哥不屑于做最简单的两个数相加，因此将这个工作交给了你
Input
第一行输入一个n(1<=n<=10)，代表有n组数据，接下来n行每行，每行输入包含2个正整数。（保证两数在long long范围内）
Output
输出两个数的和
Sample Input
1
2 3
Sample Output
5*/
#include <iostream>

using namespace std;

int main()
{
	ios::sync_with_stdio(false);
	cin.tie(0);

	int n;
	cin >> n;
	unsigned long long a, b;
	for (int i = 0; i < n; i++)
	{
		cin >> a >> b;
		cout << a + b << endl;
	}

	return 0;
}