/*cd同学经过漫长而又辛苦的比赛后,取得了一个不错的名次,本来他的非常开心的.
谁能想到公众号的小编在写文章的时候,居然把cd的名字写错了!
cd说:"I'm angry!!",生气归生气,可是木已成舟,改变不了什么了.
不过cd还是希望你能够找出字符串出错的位置.
Input
- 第一行为可能错误的字符串,长度不超过1000
- 第二行为正确的字符串,长度相同
Output
- 输出字符串中出错的位置,以空格隔开
I'm angry!!
Iam angry~~
Output
1 9 10*/
#include <iostream>
#include <cstring>
using namespace std;

int main()
{
	ios::sync_with_stdio(false);
	cin.tie(0);

	char a[1000], b[1000];
	int count = 0, j = 0;
	gets(a);
	gets(b);
	int len = strlen(a);
	for (int i = 0; i < len; i++)
	{
		if (a[i] != b[i])
		{
			if (count != 0)
			{
				cout << ' ';
			}
			j++;
			cout << i;
			count = 1;
		}
	}
	return 0;
}