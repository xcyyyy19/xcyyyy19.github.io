
#include <iostream>

using namespace std;

int main()
{
	ios::sync_with_stdio(false);
	cin.tie(0);

	int n, m, p, k;
	cin >> n >> m;
	for (int i = 0; i < n; i++)
	{
		cin >> p >> k;
		for (int j = 0; j < k; j++)
		{
			int
		}
	}

	return 0;
}