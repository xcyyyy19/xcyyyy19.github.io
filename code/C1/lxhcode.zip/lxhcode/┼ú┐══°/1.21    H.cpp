#include <iostream>

using namespace std;

int main()
{
	ios::sync_with_stdio(false);
	cin.tie(0);

	unsigned long long a[1000] = {0};
	a[0] = 1;
	a[1] = 1;
	int t, n;
	cin >> t;
	while (t--)
	{
		cin >> n;
		for (int k = 2; k <= n; k++)
		{
			a[k] = a[k - 1] + a[k - 2];
		}
		cout << a[n] << endl;
	}
	return 0;
}