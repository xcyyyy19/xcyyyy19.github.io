/*本题有T组数据。
每组数据有一行数字。
1≤T≤200
1≤数字个数≤1000
1≤数字大小≤100000
输出描述:
输出每行数的和，并换行。
示例1
输入
2
1 2 3 4 5 6
1 3 5
输出
21
9*/
#include <iostream>
#include <cstring>
using namespace std;

int main()
{
	ios::sync_with_stdio(false);
	cin.tie(0);

	long long a = 1;
	int t;
	cin>>t;
	for(int i=0;i<t;i++)
	{
		char p[1000];
		
		gets(p);
		getchar();
		int len=strlen(p);
		cout<<len<<endl;
		for(int q=0;q<2*len;q++)
		{
			a=p[q];
		}
		cout<<a<<endl;
	}
	return 0;
}