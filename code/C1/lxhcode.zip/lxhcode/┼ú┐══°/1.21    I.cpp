#include <iostream>

using namespace std;

int main()
{
	ios::sync_with_stdio(false);
	cin.tie(0);

	int n, a, b, count = 0;
	cin >> n;
	while (n--)
	{
		cin >> a >> b;
		int a1 = a, b1 = b, i, j, l, flag = 0;
		int an[6] = {0}, bn[6] = {0}, kn[4] = {0};
		for (i = 0; a1; i++)
		{
			an[i] = a1 % 10;
			a1 = a1 / 10;
		}
		for (j = 0; b1; j++)
		{
			bn[j] = b1 % 10;
			b1 = b1 / 10;
		}
		for (int k = 1; k <= 1000; k++)
		{
			int k1 = k;
			if ((k % a != 0) && (k % b != 0))
			{
				for (l = 0; k1; l++)
				{
					kn[l] = k1 % 10;
					k1 = k1 / 10;
				}
				for (int z = 0; z < l; z++)
				{
					for (int x = 0; x < j; x++)
					{
						if (bn[x] != kn[z])
						{
							continue;
						}
						else
						{
							flag = 1;
							break;
						}
					}
					for (int c = 0; c < i; c++)
					{
						if (an[c] != kn[z])
						{
							continue;
						}
						else
						{
							flag = 1;
							break;
						}
					}
				}
				if (flag == 0)
				{
					count++;
				}
				else
				{
					flag = 0;
				}
			}
		}
		cout << count << endl;
		count = 0;
	}

	return 0;
}