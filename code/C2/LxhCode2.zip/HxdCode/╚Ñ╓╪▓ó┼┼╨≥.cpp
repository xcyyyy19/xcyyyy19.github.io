#include <iostream>
#include <set>

using namespace std;

int main()
{
	set<int> s;
	int n;
	while (cin >> n)
		s.insert(n);
	for (set<int>::reverse_iterator iter = s.rbegin(); iter != s.rend(); ++iter)
		cout << *iter << ' ';
	return 0;
}