#include <iostream>

using namespace std;

inline int match(const string &a, const string &b, int x)
{
	if (a.size() + x > b.size())
		return -1;
	int i;
	for (i = 0; i < a.size(); ++i)
		if (a[i] != b[x + i])
			return -1;
	return x + i;
}

int main()
{
	string a, b;
	while (cin >> a >> b)
	{
		int count = 0;
		int i = 0, t = 0;
		while (i < b.size())
		{
			if ((t = match(a, b, i)) != -1)
			{
				++count;
				i = t;
			}
			else
				++i;
		}
		cout << count << endl;
	}
	return 0;
}