#include <iostream>
#include <cmath>

using namespace std;

bool judge(int x)
{
	if (x < 2)
		return false;

	int s = sqrt(x);
	for (int i = 2; i <= s; ++i)
		if (x % i == 0)
			return false;

	return true;
}

int main()
{
	ios::sync_with_stdio(false);
	cin.tie(0);

	int n;
	while (cin >> n, n)
	{
		if (judge(n))
			cout << "1";
		else
		{
			int i = 2, old_i = 0;
			bool flag = false;
			while (n != 1)
				if (n % i == 0)
				{
					n /= i;
					if (i == old_i)
					{
						flag = true;
						break;
					}
					else
						old_i = i;
				}
				else
					++i;
			cout << (flag ? '3' : '2');
		}
	}

	return 0;
}