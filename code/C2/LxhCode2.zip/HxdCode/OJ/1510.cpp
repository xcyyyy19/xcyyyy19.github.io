#include <iostream>

using namespace std;

int main()
{
	long long a, b;
	while (cin >> a >> b, a || b)
		cout << (a + b) / 2 << endl;
	return 0;
}