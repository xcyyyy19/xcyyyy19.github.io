#include <iostream>

using namespace std;

inline int calc(int y)
{
	return y / 4 - y / 100 + y / 400;
}

int main()
{
	int a, b;
	while (cin >> a >> b, a || b)
	{
		if (a > b)
		{
			int t;
			t = a, a = b, b = t;
		}
		int count = calc(b) - calc(a);
		count += a % 400 == 0 || a % 4 == 0 && a % 100 != 0;
		cout << count << endl;
	}

	return 0;
}