#include <iostream>

using namespace std;

int main()
{
	ios::sync_with_stdio(false);
	cin.tie(0);

	long long arr[22] = {0, 0, 1};
	for (int i = 3; i < 22; ++i)
		arr[i] = (i - 1) * (arr[i - 1] + arr[i - 2]);

	int m;
	cin >> m;
	while (m--)
	{
		int n;
		cin >> n;
		cout << arr[n] << endl;
	}

	return 0;
}