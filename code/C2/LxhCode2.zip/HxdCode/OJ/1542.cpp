#include <iostream>
#include <algorithm>
#include <cmath>

#define DIS(x1, y1, x2, y2) (pow((x1) - (x2), 2) + pow((y1) - (y2), 2))

using namespace std;

int main()
{
	int n;
	cin >> n;
	while (n--)
	{
		double x1, y1, x2, y2, x3, y3;
		cin >> x1 >> y1 >> x2 >> y2 >> x3 >> y3;
		double dis[3] = {DIS(x1, y1, x2, y2), DIS(x1, y1, x3, y3), DIS(x2, y2, x3, y3)};
		sort(dis, dis + 3);
		if (sqrt(dis[0]) + sqrt(dis[1]) > sqrt(dis[2]))
		{
			if (dis[0] + dis[1] > dis[2])
				cout << "钝角三角形" << endl;
			else if (dis[0] + dis[1] < dis[2])
				cout << "锐角三角形" << endl;
			else
				cout << "直角三角形" << endl;
		}
		else
			cout << "无法构成三角形" << endl;
	}
	return 0;
}
