#include <stdio.h>
int main()
{
	int n;
	int m[2];
	while (~scanf("%d%d%d", &n, m, m + 1))
	{
		int a = 0, i = 2;
		for (; i <= n; ++i)
			a = (a + m[(i & 1) ^ (n & 1)]) % i;
		printf("%d\n", -~a);
	}
}