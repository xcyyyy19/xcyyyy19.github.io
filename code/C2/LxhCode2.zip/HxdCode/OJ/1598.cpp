#include <iostream>

using namespace std;

struct List_node
{
	int data;
	List_node *next;
};

struct List
{
	int size;
	List_node *next;
};

List *init_list()
{
	List *l = (List *)malloc(sizeof(List));
	l->size = 0;
	l->next = NULL;
	return l;
}

void push_back(List *l, int value)
{
	List_node *np = (List_node *)malloc(sizeof(List_node));
	np->data = value;
	np->next = NULL;
	if (l->size)
	{
		List_node *p = l->next;
		while (p->next)
			p = p->next;
		p->next = np;
	}
	else
		l->next = np;
	l->size++;
}

void push_front(List *l, int value)
{
	if (l->size)
	{
		List_node *np = (List_node *)malloc(sizeof(List_node));
		np->data = value;
		np->next = l->next;
		l->next = np;
		l->size++;
	}
	else
		push_back(l, value);
}

void insert(List *l, int pos, int value)
{
	if (pos == 0)
		push_front(l, value);
	else if (pos == l->size - 1)
		push_back(l, value);
	else
	{
		List_node *p = l->next;
		for (int i = 1; i < pos; ++i)
			p = p->next;
		List_node *np = (List_node *)malloc(sizeof(List_node));
		np->data = value;
		np->next = p->next;
		p->next = np;
		l->size++;
	}
}

void pop_back(List *l)
{
	if (l->size > 1)
	{
		List_node *p = l->next;
		while (p->next->next)
			p = p->next;
		free(p->next);
		p->next = NULL;
		l->size--;
	}
	else if (l->size == 1)
	{
		free(l->next);
		l->next = NULL;
		l->size--;
	}
}

void pop_front(List *l)
{
	if (l->size < 2)
		pop_back(l);
	else
	{
		List_node *p = l->next->next;
		free(l->next);
		l->next = p;
		l->size--;
	}
}

void erase(List *l, int pos)
{
	if (pos == 0)
		pop_front(l);
	else if (pos == l->size - 1)
		pop_back(l);
	else
	{
		List_node *p = l->next;
		for (int i = 1; i < pos; ++i)
			p = p->next;
		List_node *tp = p->next;
		p->next = p->next->next;
		free(tp);
		l->size--;
	}
}

void get_value(List *l, int pos)
{
	List_node *p = l->next;
	while (pos--)
		p = p->next;
	cout << p->data << endl;
}

void size(List *l)
{
	cout << l->size << endl;
}

void empty(List *l)
{
	cout << (l->size ? "false" : "true") << endl;
}

void print(List *l)
{
	List_node *p = l->next;
	for (int i = 0; i < l->size; ++i)
	{
		if (i)
			cout << ' ';
		cout << p->data;
		p = p->next;
	}
	cout << endl;
}

void clear(List *l)
{
	List_node *p = l->next;
	while (p)
	{
		List_node *tp = p;
		p = p->next;
		free(tp);
	}
	l->size = 0;
	l->next = NULL;
}

void destroy(List *l)
{
	clear(l);
	free(l);
	cout << "destroy" << endl;
}

int main()
{
	string s;
	List *l = NULL;
	int pos, value;
	while (cin >> s)
	{
		if (s == "init_list")
			l = init_list();
		else if (s == "push_back")
		{
			cin >> value;
			push_back(l, value);
		}
		else if (s == "push_front")
		{
			cin >> value;
			push_front(l, value);
		}
		else if (s == "insert")
		{
			cin >> pos >> value;
			insert(l, pos, value);
		}
		else if (s == "erase")
		{
			cin >> pos;
			erase(l, pos);
		}
		else if (s == "get_value")
		{
			cin >> pos;
			get_value(l, pos);
		}
		else if (s == "size")
			size(l);
		else if (s == "empty")
			empty(l);
		else if (s == "print")
			print(l);
		else if (s == "clear")
			clear(l);
		else if (s == "destroy")
		{
			destroy(l);
			break;
		}
	}
	return 0;
}