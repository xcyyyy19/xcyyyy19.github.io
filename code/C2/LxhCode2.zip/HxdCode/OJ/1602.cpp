#include <iostream>

using namespace std;

int main()
{
	ios::sync_with_stdio(false);
	cin.tie(0);

	unsigned long long arr[40][3] = {1, 1, 1};
	for (int i = 1; i < 40; ++i)
	{
		arr[i][0] = arr[i - 1][1] + arr[i - 1][2];
		arr[i][1] = arr[i - 1][0] + arr[i - 1][1] + arr[i - 1][2];
		arr[i][2] = arr[i - 1][0] + arr[i - 1][1] + arr[i - 1][2];
	}
	int m;
	cin >> m;
	while (m--)
	{
		int n;
		cin >> n;
		if (n == 0)
			cout << 1 << endl;
		else
			cout << arr[n - 1][0] + arr[n - 1][1] + arr[n - 1][2] << endl;
	}

	return 0;
}