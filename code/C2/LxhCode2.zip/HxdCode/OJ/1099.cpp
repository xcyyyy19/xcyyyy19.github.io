#include <iostream>

using namespace std;

int main()
{
	//	for (int i = 0; i < 50; ++i)
	{
		int i = 500;
		cout << (i - 1) * (i - 1) << endl;
		cout << i << ": " << i * i << endl;
		cout << (i + 1) * (i + 1) << endl;
	}

	return 0;
}