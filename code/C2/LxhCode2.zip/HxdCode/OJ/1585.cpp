#include <iostream>

using namespace std;

int main()
{
	int n;
	cin >> n;
	while (n--)
	{
		unsigned long long a, b;
		cin >> a >> b;
		cout << a + b << endl;
	}

	return 0;
}