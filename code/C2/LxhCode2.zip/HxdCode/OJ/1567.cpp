#include <iostream>
#include <cstring>

using namespace std;

int main()
{
	ios::sync_with_stdio(false);
	cin.tie(0);

	int l, m;
	cin >> l >> m;
	int arr[l + 1];
	memset(arr, 0, sizeof(arr));
	while (m--)
	{
		int left, right;
		cin >> left >> right;
		for (int i = left; i <= right; ++i)
			arr[i] = 1;
	}
	int sum = 0;
	for (int i = 0; i < l + 1; ++i)
		sum += !arr[i];
	cout << sum << endl;

	return 0;
}