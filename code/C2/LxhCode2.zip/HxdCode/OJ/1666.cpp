#include <iostream>

using namespace std;

int main()
{
	ios::sync_with_stdio(false);
	cin.tie(0);

	unsigned long long n;
	while (cin >> n)
	{
		unsigned long long sum = 0;
		for (int i = 0; i < n; ++i)
		{
			unsigned long long t;
			cin >> t;
			sum += t;
		}
		cout << sum << endl;
	}

	return 0;
}