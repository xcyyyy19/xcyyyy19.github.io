#include <cstdio>
#include <cmath>
int main()
{
	double x1, y1, x2, y2, x, y;
	while (scanf("%lf%lf%lf%lf%lf%lf", &x1, &y1, &x2, &y2, &x, &y) != EOF)
		if (!x1 && !y1 && !x2 && !y2 && !x && !y)
			break;
		else
			printf("%.2lf\n", fabs((y1 - y2) * x - (x1 - x2) * y + x1 * y2 - x2 * y1) / sqrt(pow(y1 - y2, 2) + pow(x1 - x2, 2)));
	return 0;
}