#include <iostream>
#include <algorithm>
#include <functional>

using namespace std;

int main()
{
	ios::sync_with_stdio(false);
	cin.tie(0);

	int n;
	cin >> n;
	int arr[n];
	for (int i = 0; i < n; ++i)
		cin >> arr[i];

	sort(arr, arr + n, greater<int>());
	int b = arr[int(n * 0.1) - 1] - 360;
	for (int i = 0; i < n; ++i)
	{
		arr[i] -= b;
		if (arr[i] > 600)
			arr[i] = 600;
		else if (arr[i] < 0)
			arr[i] = 0;

		if (i)
			cout << ' ';
		cout << arr[i];
	}

	return 0;
}