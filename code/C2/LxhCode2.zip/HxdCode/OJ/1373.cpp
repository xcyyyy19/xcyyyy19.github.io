#include <iostream>
#include <queue>
#include <cstring>

using namespace std;

struct Location
{
	int x, y;
	Location(int a = 0, int b = 0) : x(a), y(b) {}
};

int main()
{
	const int dx[4] = {1, -1, 0, 0};
	const int dy[4] = {0, 0, 1, -1};
	int m, n;
	while (cin >> n >> m, m || n)
	{
		char arr[m][n];
		bool mark[m][n];
		memset(mark, false, sizeof(mark));
		queue<Location> q;
		for (int i = 0; i < m; ++i)
			for (int j = 0; j < n; ++j)
			{
				cin >> arr[i][j];
				if (arr[i][j] == '@')
				{
					q.push(Location(i, j));
					mark[i][j] = true;
				}
			}
		int count = 1;
		while (q.size())
		{
			Location tloc = q.front();
			q.pop();
			for (int i = 0; i < 4; ++i)
			{
				Location nloc = Location(tloc.x + dx[i], tloc.y + dy[i]);
				if (nloc.x >= 0 && nloc.x < m && nloc.y >= 0 && nloc.y < n &&
					arr[nloc.x][nloc.y] == '.' && mark[nloc.x][nloc.y] == false)
				{
					q.push(nloc);
					mark[nloc.x][nloc.y] = true;
					++count;
				}
			}
		}
		cout << count << endl;
	}

	return 0;
}