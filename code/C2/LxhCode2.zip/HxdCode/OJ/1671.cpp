#include <iostream>
#include <string>
#include <cstring>

using namespace std;

int main()
{
	ios::sync_with_stdio(false);
	cin.tie(0);

	const string book = "qwertyuiopasdfghjklzxcvbnm";

	int n;
	cin >> n;
	while (n--)
	{
		int s;
		string str;
		cin >> s >> str;
		for (int i = 0; i < str.size(); ++i)
			cout << book[book.find(str[i]) + s];
		cout << endl;
	}

	return 0;
}