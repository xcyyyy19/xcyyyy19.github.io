#include <iostream>

using namespace std;

int main()
{
	ios::sync_with_stdio(false);
	cin.tie(0);

	int n;
	cin >> n;
	n = 2 * n - 1;

	int b;
	cin >> b;
	int num = 1;
	for (int i = 1; i < n; ++i)
	{
		int t;
		cin >> t;
		if (b == t)
			++num;
		else
			--num;
		if (num == 0)
		{
			b = t;
			num = 1;
		}
	}
	cout << b << endl;

	return 0;
}