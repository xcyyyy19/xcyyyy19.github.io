#include <iostream>

using namespace std;

int main()
{
	int a, b, c, r1, r2, r3;
	while (cin >> a >> b >> c >> r1 >> r2 >> r3)
	{
		int y1 = a * b, y2 = a * c, y3 = b * c;
		int i = 1;
		while ((y1 * i) % c != 1)
			++i;
		y1 *= i;
		i = 1;
		while ((y2 * i) % b != 1)
			++i;
		y2 *= i;
		i = 1;
		while (y3 * i % a != 1)
			++i;
		y3 *= i;
		cout << (y3 * r1 + y2 * r2 + y1 * r3) % (a * b * c) << endl;
	}

	return 0;
}