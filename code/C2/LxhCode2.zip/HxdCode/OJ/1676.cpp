#include <iostream>
#include <stack>

using namespace std;

int main()
{
	ios::sync_with_stdio(false);
	cin.tie(0);

	int n;
	cin >> n;
	stack<int> s;
	do
	{
		s.push(n % 2);
		n /= 2;
	} while (n);

	while (s.size())
	{
		cout << s.top();
		s.pop();
	}
	cout << endl;

	return 0;
}