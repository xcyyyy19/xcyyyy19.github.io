#include <stdio.h>
#include <string.h>
#include <iostream>
#include <stack>
#include <string>

using namespace std;

int main()
{
	char s[1005];
	// while (scanf("%s", s) != EOF && strcmp(s, "0"))
	// {
	// 	int len = strlen(s);
	// 	int i, flag = 1;
	// 	for (i = len - 1; i > 0; --i)
	// 		if (s[i] != '0' || s[i - 1] == '.')
	// 			break;
	// 	while (i >= 0)
	// 		putchar(s[i--]);
	// 	putchar(10);
	// }
	while (scanf("%s", s) != EOF)
	{
		stack<char> ss;
		int len = strlen(s);
		for (int i = 0; i < len; ++i)
			ss.push(s[i]);
		if (ss.size() == 1 && ss.top() == '0')
			break;
		bool flag = 1;
		while (ss.size())
		{
			char c = ss.top();
			ss.pop();
			if (flag && c == '0')
			{
				if (ss.top() == '.')
					flag = 0, cout << c;
			}
			else
			{
				flag = 0;
				cout << c;
			}
		}
		cout << endl;
	}
	return 0;
}