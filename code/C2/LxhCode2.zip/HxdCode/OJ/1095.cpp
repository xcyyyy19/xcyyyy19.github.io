#include <iostream>
#include <vector>

using namespace std;

int find(const vector<string> &v, string s)
{
	for (int i = 0; i < v.size(); ++i)
		if (v[i] == s)
			return i;
	return -1;
}

int main()
{
	int a, b, c;
	while (cin >> a >> b >> c)
	{
		vector<string> sa, sb, sc;
		string t;
		for (int i = 0; i < a; ++i)
		{
			cin >> t;
			sa.push_back(t);
		}
		for (int i = 0; i < b; ++i)
		{
			cin >> t;
			sb.push_back(t);
		}
		for (int i = 0; i < c; ++i)
		{
			cin >> t;
			sc.push_back(t);
		}
		int count = 0;
		for (int i = 0; i < sa.size(); ++i)
		{
			if (find(sb, sa[i]) != -1 && find(sc, sa[i]) == -1)
			{
				if (count)
					cout << ' ';
				cout << sa[i];
				++count;
			}
		}
		if (!count)
			cout << "No enemy spy";
		cout << endl;
	}

	return 0;
}