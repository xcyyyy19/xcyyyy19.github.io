#include <iostream>
#include <cstdio>

using namespace std;

int main()
{
	ios::sync_with_stdio(false);
	cin.tie(0);

	int a, b;
	while (cin >> a >> b)
		printf("%.2lf\n", a * 1. / (a + b));

	return 0;
}