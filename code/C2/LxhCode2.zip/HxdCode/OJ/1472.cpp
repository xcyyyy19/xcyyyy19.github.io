#include <iostream>
#include <string>

using namespace std;

int main()
{
	string s;
	while (cin >> s, s != "0")
	{
		if (s[s.size() - 1] == '0')
			s.erase(s.size() - 1);
		while (s.size())
		{
			cout << s[s.size() - 1];
			s.erase(s.size() - 1);
		}
		cout << endl;
	}

	return 0;
}