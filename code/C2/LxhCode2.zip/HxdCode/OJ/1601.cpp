#include <iostream>

using namespace std;

inline unsigned long long sum(unsigned long long *arr)
{
	unsigned long long sum = 0;
	for (int i = 0; i < 9; ++i)
		sum += arr[i];
	return sum;
}

int main()
{
	ios::sync_with_stdio(false);
	cin.tie(0);

	unsigned long long arr[40][9] = {1, 1, 1, 1, 1, 1, 1, 1, 1};
	for (int i = 1; i < 40; ++i)
	{
		arr[i][0] = arr[i - 1][0] + arr[i - 1][3] + arr[i - 1][6];
		arr[i][1] = arr[i - 1][0] + arr[i - 1][3];
		arr[i][2] = arr[i - 1][0] + arr[i - 1][6];
		arr[i][3] = arr[i - 1][1] + arr[i - 1][4];
		arr[i][4] = arr[i - 1][1] + arr[i - 1][4] + arr[i - 1][7];
		arr[i][5] = arr[i - 1][4] + arr[i - 1][7];
		arr[i][6] = arr[i - 1][2] + arr[i - 1][8];
		arr[i][7] = arr[i - 1][5] + arr[i - 1][8];
		arr[i][8] = arr[i - 1][2] + arr[i - 1][5] + arr[i - 1][8];
	}
	int m;
	cin >> m;
	while (m--)
	{
		int n;
		cin >> n;
		if (n == 0)
			cout << 1 << endl;
		else if (n == 1)
			cout << 3 << endl;
		else
			cout << sum(arr[n - 2]) << endl;
	}

	return 0;
}