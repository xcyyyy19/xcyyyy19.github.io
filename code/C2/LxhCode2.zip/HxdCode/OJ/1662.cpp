#include <iostream>
#include <algorithm>
#include <vector>

using namespace std;

template <class T>
struct Greater
{
	bool operator()(const T &a, const T &b) const { return a > b; }
};

template <class T, class Cmp = Greater<T>>
class Priority_Queue
{
  public:
	Priority_Queue &push(const T &value)
	{
		v.push_back(value);
		up_adjust(v.size() - 1);
		return *this;
	}

	Priority_Queue &pop()
	{
		if (v.size())
		{
			v[0] = v[v.size() - 1];
			v.pop_back();
			down_adjust(0);
		}
		return *this;
	}

	T top() const { return v.front(); }

  private:
	vector<T> v;
	Cmp cmp;

	int left_child(int x) { return -~(x << 1); }
	int right_child(int x) { return -~-~(x << 1); }
	int father(int x) { return ~-x >> 1; }
	void swap(T &a, T &b)
	{
		T t;
		t = a, a = b, b = t;
	}

	void down_adjust(int pos)
	{
		int l = left_child(pos), r = right_child(pos);
		if (r < v.size())
		{
			if (cmp(v[pos], v[l]) && !cmp(v[l], v[r]))
			{
				swap(v[pos], v[l]);
				down_adjust(l);
			}
			else if (cmp(v[pos], v[r]) && !cmp(v[r], v[l]))
			{
				swap(v[pos], v[r]);
				down_adjust(r);
			}
		}
		else if (l < v.size() && cmp(v[pos], v[l]))
		{
			swap(v[pos], v[l]);
			down_adjust(l);
		}
	}
	void up_adjust(int pos)
	{
		if (pos)
		{
			int f = father(pos);
			if (cmp(v[f], v[pos]))
			{
				swap(v[f], v[pos]);
				up_adjust(f);
			}
		}
	}
};

int main()
{
	ios::sync_with_stdio(false);
	cin.tie(0);

	bool front = true;
	int n;
	while (cin >> n, n)
	{
		Priority_Queue<int> pq;
		for (int i = 0; i < n; ++i)
		{
			int t;
			cin >> t;
			pq.push(t);
		}
		if (!front)
			cout << endl;
		front = false;
		for (int i = 0; i < n; ++i)
		{
			if (i)
				cout << ' ';
			cout << pq.top();
			pq.pop();
		}
		cout << endl;
	}

	return 0;
}