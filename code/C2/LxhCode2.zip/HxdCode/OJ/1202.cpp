#include <stdio.h>

int main(void)
{
	int tou, jiao, ji, tu;

	while (scanf("%d%d", &tou, &jiao), tou != 0 && jiao != 0)
	{
		tu = (jiao - tou * 2) / 2;
		ji = tou - tu;

		if (tou > 0 && jiao > 0 && jiao % 2 == 0 && ji >= 0 && tu >= 0)
			printf("%d %d\n", ji, tu);
		else
			printf("Error\n");
	}

	return 0;
}