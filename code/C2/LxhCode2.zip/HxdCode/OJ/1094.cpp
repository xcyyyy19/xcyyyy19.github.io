#include <iostream>

using namespace std;

void print(int a, int b, int c, int d)
{
	const string upper[10] = {" _ ", "   ", " _ ", " _ ", "   ", " _ ", " _ ", " _ ", " _ ", " _ "};
	const string middl[10] = {"| |", "  |", " _|", " _|", "|_|", "|_ ", "|_ ", "  |", "|_|", "|_|"};
	const string lower[10] = {"|_|", "  |", "|_ ", " _|", "  |", " _|", "|_|", "  |", "|_|", " _|"};
	cout << upper[a] << upper[b] << upper[c] << upper[d] << endl;
	cout << middl[a] << middl[b] << middl[c] << middl[d] << endl;
	cout << lower[a] << lower[b] << lower[c] << lower[d] << endl;
}

int main()
{
	int a, b, c, d;
	while (cin >> a >> b >> c >> d)
		print(a, b, c, d);

	return 0;
}