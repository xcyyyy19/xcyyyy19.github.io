#include <iostream>

using namespace std;

int main()
{
	ios::sync_with_stdio(false);
	cin.tie(0);

	int flag = 10;

	1 ? flag = 1 : flag = 2;
	cout << flag << endl;

	return 0;
}