#include <iostream>
#include <ctime>
#include <cstring>

using namespace std;

inline bool judge(int i, bool *ty)
{
	do
	{
		if (ty[i % 10])
			return true;
		i /= 10;
	} while (i);
	return false;
}

int main()
{
	int n, m;
	cin >> n >> m;
	bool ty[10];
	memset(ty, false, sizeof(ty));
	for (int i = 0; i < m; ++i)
	{
		int t;
		cin >> t;
		ty[t] = true;
	}

	int t = clock();
	int count = 0;
	for (int i = 0; i <= n; ++i)
		count += judge(i, ty);
	cout << clock() - t << endl;
	cout << count << endl;

	return 0;
}