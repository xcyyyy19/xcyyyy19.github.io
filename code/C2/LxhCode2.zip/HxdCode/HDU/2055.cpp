#include <iostream>
#include <algorithm>
#include <cstdio>

using namespace std;

inline void change(double x1, double x2)
{
	if (x1 > x2)
		swap(x1, x2);
}

int main()
{
	double x1, y1, x2, y2, x3, y3, x4, y4;
	while (cin >> x1 >> y1 >> x2 >> y2 >> x3 >> y3 >> x4 >> y4)
	{
		change(x1, x2);
		change(y1, y2);
		change(x3, x4);
		change(y3, y4);
		double x5 = max(x1, x3);
		double y5 = max(y1, y3);
		double x6 = min(x2, x4);
		double y6 = min(y2, y4);
		if (x5 < x6 && y5 < y6)
			printf("%.2lf\n", (x6 - x5) * (y6 - y5));
		else
			printf("0\n");
	}
	return 0;
}