#include <iostream>

using namespace std;

int main()
{
	ios::sync_with_stdio(false);
	cin.tie(0);

	int n;
	while (cin >> n)
	{
		bool flag = false;
		for (int i = 1; i <= n; ++i)
			if (n % i == 0)
				flag = !flag;
		cout << flag << endl;
	}

	return 0;
}