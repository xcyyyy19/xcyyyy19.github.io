#include <iostream>
#include <string>
#include <cctype>

using namespace std;

int main()
{
	ios::sync_with_stdio(false);
	cin.tie(0);

	int n;
	cin >> n;
	while (n--)
	{
		string s;
		cin >> s;
		for (int i = 0; i < s.size(); ++i)
		{
			char c = tolower(s[i]);
			if (c == 'a' || c == 'e' || c == 'i' || c == 'o' || c == 'u')
				s[i] = toupper(c);
			else
				s[i] = c;
		}
		cout << s << endl;
	}

	return 0;
}