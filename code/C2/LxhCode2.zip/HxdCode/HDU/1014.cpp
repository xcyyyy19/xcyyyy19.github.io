#include <iostream>
#include <stdio.h>

using namespace std;

int gcd(int a, int b)
{
	if (!b)
		return a;
	return gcd(b, a % b);
}

int main()
{
	int step, mod;
	while (cin >> step >> mod)
	{
		printf("%10d%10d    ", step, mod);
		if (gcd(step, mod) == 1)
			printf("%s", "Good Choice\n\n");
		else
			printf("%s", "Bad Choice\n\n");
	}

	return 0;
}