#include <iostream>
#include <string>

using namespace std;

inline void erase(string &s)
{
	int begin;
	for (begin = 0; begin < s.size(); ++begin)
		if (s[begin] != '0')
			break;
	int end;
	for (end = begin; end < s.size(); ++end)
		if (s[end] == '0')
			break;
	int max = begin;
	for (int i = begin; i < end; ++i)
		max = s[max] >= s[i] ? max : i;
	s.erase(max, 1);
}

int main()
{
	ios::sync_with_stdio(false);
	cin.tie(0);

	string s;
	int n;
	while (cin >> s >> n)
	{
		if (n >= s.size())
		{
			cout << 0 << endl;
			continue;
		}
		while (n--)
			erase(s);
		int i;
		for (i = 0; i < s.size(); ++i)
			if (s[i] != '0')
				break;
		if (i == s.size())
			cout << 0;
		else
			for (; i < s.size(); ++i)
				cout << s[i];
		cout << endl;
	}

	return 0;
}