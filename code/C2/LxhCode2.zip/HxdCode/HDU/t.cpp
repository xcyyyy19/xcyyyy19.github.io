#include <iostream>

using namespace std;

int main()
{
	ios::sync_with_stdio(false);
	cin.tie(0);

	int a, b;
	while (cin >> a >> b)
	{
		int ans = 1;
		for (int i = 0; i < b; ++i)
		{
			ans *= a;
			ans %= 1000;
		}
		cout << ans << endl;
	}

	return 0;
}