#include <iostream>

using namespace std;

int main()
{
	ios::sync_with_stdio(false);
	cin.tie(0);

	int n;
	char a, b;
	bool front = true;
	while (cin >> n >> a >> b)
	{
		char arr[n][n];
		if (n == 1)
		{
			arr[0][0] = a;
			goto label;
		}
		{
			int m = n / 2;
			int o = n - m;
			for (int i = 0; i < o; ++i)
			{
				char c = i % 2 ? b : a;
				for (int j = 0; j < n; ++j)
				{
					arr[m - i][j] = c;
					arr[m + i][j] = c;
					arr[j][m - i] = c;
					arr[j][m + i] = c;
				}
			}
		}
		arr[0][0] = arr[0][n - 1] = arr[n - 1][0] = arr[n - 1][n - 1] = ' ';
	label:
		if (!front)
			cout << endl;
		front = false;
		for (int i = 0; i < n; ++i)
		{
			for (int j = 0; j < n; ++j)
				cout << arr[i][j];
			cout << endl;
		}
	}

	return 0;
}