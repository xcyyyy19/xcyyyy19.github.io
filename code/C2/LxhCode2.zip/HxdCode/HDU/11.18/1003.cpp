#include <iostream>

using namespace std;

int main()
{
	ios::sync_with_stdio(false);
	cin.tie(0);

	int t;
	cin >> t;
	while (t--)
	{
		int n;
		cin >> n;
		int count = 0, i = 5;
		while (n >= i)
		{
			count += n / i;
			i *= 5;
		}
		cout << count << endl;
	}

	return 0;
}