#include <iostream>
#include <cstdio>
#include <functional>
#include <algorithm>

using namespace std;

struct Grade
{
	bool flag;
	int ac_number;
	int time_h;
	int time_m;
	int time_s;
	bool operator>(const Grade &b) const
	{
		return ac_number == b.ac_number ? time_h == b.time_h ? time_m == b.time_m ? time_s > b.time_s
																				  : time_m > b.time_m
															 : time_h > b.time_h
										: ac_number > b.ac_number;
	}
};

int main()
{
	ios::sync_with_stdio(false);
	cin.tie(0);

	int n, g, s, c, m;
	while (cin >> n >> g >> s >> c >> m, n || g || s || c || m)
	{
		Grade arr[n];
		for (int i = 0; i < n; ++i)
		{
			scanf("%d %d:%d:%d", &arr[i].ac_number, &arr[i].time_h, &arr[i].time_m, &arr[i].time_s);
			arr[i].flag = false;
		}
		arr[m].flag = true;
		sort(arr, arr + n, greater<Grade>());
		int mark = 0;
		for (int i = 0; i < n; ++i)
			if (arr[i].flag)
				mark = i;
		c += s += g;
		if (mark < g)
			cout << "Accepted today? I've got a golden medal :)" << endl;
		else if (mark < s)
			cout << "Accepted today? I've got a silver medal :)" << endl;
		else if (mark < c)
			cout << "Accepted today? I've got a copper medal :)" << endl;
		else
			cout << "Accepted today? I've got an honor mentioned :)" << endl;
	}

	return 0;
}