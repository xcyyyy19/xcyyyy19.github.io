#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

inline int calc_front(const vector<int> &v)
{
	int front = 0;
	int i = 2;
	while (v[i++] == 0)
		++front;
	return front;
}

inline int calc_back(const vector<int> &v)
{
	int back = 0;
	int i = v.size() - 1;
	while (v[i--] == 0)
		++back;
	return back;
}

inline int calc(const vector<int> &v)
{
	int count = 0;
	for (int i = 2; i < v.size(); ++i)
		if (v[i] == 0)
			++count;
	return count - calc_back(v);
}

int main()
{
	ios::sync_with_stdio(false);
	cin.tie(0);

	int n, l, m;
	while (cin >> n >> l >> m)
	{
		vector<vector<int>> v;
		for (int i = 0; i < n; ++i)
		{
			vector<int> t;
			for (int j = 0; j < l; ++j)
			{
				int tt;
				cin >> tt;
				t.push_back(tt);
			}
			if (t[0] == 0 && t[1] == 0)
				v.push_back(t);
			else
				for (int j = 0; j < l; ++j)
					v.back().push_back(t[j]);
		}
		int sup = v.size() - m;
		while (sup--)
		{
			int min_num = 0;
			int min_white = 2100000000;
			for (int i = 1; i < v.size(); ++i)
			{
				int white = calc_back(v[i - 1]);
				if (white < min_white)
				{
					min_white = white;
					min_num = i;
				}
			}
			for (int i = 0; i < v[min_num].size(); ++i)
				v[min_num - 1].push_back(v[min_num][i]);
			vector<vector<int>>::iterator iter = v.begin();
			for (int i = 0; i < min_num; ++i)
				++iter;
			v.erase(iter);
		}
		int count = 0;
		for (int i = 0; i < v.size(); ++i)
			count += calc(v[i]);
		cout << count << endl;
	}

	return 0;
}