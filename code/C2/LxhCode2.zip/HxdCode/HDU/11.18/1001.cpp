#include <iostream>

using namespace std;

int main()
{
	ios::sync_with_stdio(false);
	cin.tie(0);

	int n;
	int num = 1;
	while (cin >> n, n > 0)
	{
		int sum = 0;
		for (int i = 0; i < n; ++i)
		{
			int t;
			cin >> t;
			sum += t;
		}
		cout << "Sum of #" << num++ << " is " << sum << endl;
	}

	return 0;
}