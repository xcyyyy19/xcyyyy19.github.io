#include <iostream>
#include <string>
#include <vector>
#include <queue>
#include <set>

using namespace std;

struct Node
{
	string s;
	vector<char> v;
	Node(string _s) : s(_s) {}
	Node(string _s, vector<char> _v) : s(_s), v(_v) {}
};

void change(string &s, int num)
{
	const string book1 = "41236785";
	const string book2 = "17245368";
	string t;
	switch (num)
	{
	case 0:
		while (s.size())
		{
			t.push_back(s.back());
			s.pop_back();
		}
		break;
	case 1:
		for (int i = 0; i < 8; ++i)
			t.push_back(s[book1[i] - '1']);
		break;
	case 2:
		for (int i = 0; i < 8; ++i)
			t.push_back(s[book2[i] - '1']);
		break;
	}
	s = t;
}

int main()
{
	ios::sync_with_stdio(false);
	cin.tie(0);

	string s1, s2;
	while (cin >> s1 >> s2)
	{
		vector<char> ans;
		queue<Node> q;
		set<string> se;
		q.push(Node(s1));
		se.insert(s1);
		while (q.size())
		{
			Node t = q.front();
			q.pop();
			for (int i = 0; i < 3; ++i)
			{
				Node n(t.s, t.v);
				change(n.s, i);
				if (se.insert(n.s).second)
				{
					n.v.push_back('A' + i);
					if (n.s == s2)
					{
						ans = n.v;
						goto label;
					}
					q.push(n);
				}
			}
		}
	label:
		for (int i = 0; i < ans.size(); ++i)
			cout << ans[i];
		cout << endl;
	}

	return 0;
}