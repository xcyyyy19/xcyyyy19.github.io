#include <iostream>

using namespace std;

int main()
{
	ios::sync_with_stdio(false);
	cin.tie(0);

	int n, m;
	while (cin >> n >> m, n || m)
	{
		int sum = 1, i = 1, j = 1;
		while (j <= n && j <= m)
		{
			if (sum == m)
			{
				cout << '[' << i << ',' << j << ']' << endl;
				sum -= i++;
			}
			else if (sum < m)
				sum += ++j;
			else
				sum -= i++;
		}
		cout << endl;
	}

	return 0;
}