#include <iostream>
#include <algorithm>
#include <cstring>
using namespace std;
int Letter[30];
int C1[550], C2[550];

int main()
{
	int N;
	int i, j, k;
	scanf("%d", &N);
	while (N--)
	{
		memset(C1, 0, sizeof(C1));
		memset(C2, 0, sizeof(C2));
		memset(Letter, 0, sizeof(Letter));
		int Sum = (27 * 26) / 2;
		for (i = 1; i <= 26; i++)
		{
			scanf("%d", &Letter[i]);
		}
		for (i = 0; i <= Letter[1]; i++)
		{
			C1[i] = 1;
		}
		for (i = 2; i <= 26; i++)
		{
			for (j = 0; j <= Sum; j++)
			{
				for (k = 0; j + k <= Sum && k <= Letter[i] * i; k += i)
				{ //k要小于当前这一括号的最大次幂
					C2[j + k] += C1[j];
				}
			}
			for (j = 0; j <= Sum; j++)
			{
				C1[j] = C2[j];
				C2[j] = 0;
			}
		}
		int Count = 0;
		for (i = 1; i <= 50; i++)
		{
			if (C1[i])
			{
				Count += C1[i];
			}
		}
		printf("%d\n", Count);
	}
	return 0;
}