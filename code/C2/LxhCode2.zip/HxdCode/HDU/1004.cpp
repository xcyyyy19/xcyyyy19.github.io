#include <iostream>
#include <string>
#include <map>

using namespace std;

int main()
{
	ios::sync_with_stdio(false);
	cin.tie(0);

	int n;
	while (cin >> n, n)
	{
		map<string, int> m;
		for (int i = 0; i < n; ++i)
		{
			string s;
			cin >> s;
			++m[s];
		}
		string max_s;
		int max_n = 0;
		for (auto iter = m.begin(); iter != m.end(); ++iter)
		{
			if (iter->second > max_n)
			{
				max_s = iter->first;
				max_n = iter->second;
			}
		}
		cout << max_s << endl;
	}

	return 0;
}