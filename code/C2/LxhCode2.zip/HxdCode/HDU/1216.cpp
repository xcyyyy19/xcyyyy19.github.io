#include <iostream>
#include <vector>
#include <cstring>

#define N 33810

using namespace std;

int main()
{
	ios::sync_with_stdio(false);
	cin.tie(0);

	bool arr[N];
	memset(arr, 1, sizeof(bool) * N);
	arr[0] = arr[1] = 0;
	for (int i = 2; i < N; ++i)
	{
		int count = 0;
		if (arr[i])
			for (int j = i + 1; j < N; ++j)
				if (arr[j])
					if (++count == i)
					{
						count = 0;
						arr[j] = 0;
					}
	}
	vector<int> v;
	for (int i = 0; i < N; ++i)
		if (arr[i])
			v.push_back(i);

	int t;
	while (cin >> t, t)
		cout << v[t - 1] << endl;

	return 0;
}