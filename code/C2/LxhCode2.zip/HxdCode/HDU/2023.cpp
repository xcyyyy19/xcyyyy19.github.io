#include <iostream>
#include <cstring>
#include <cstdio>

using namespace std;

int main()
{
	int n, m;
	bool front = true;
	while (cin >> n >> m)
	{
		double arr[n + 1][m + 1];
		memset(arr, 0, sizeof(arr));
		for (int i = 0; i < n; i++)
			for (int j = 0; j < m; j++)
			{
				cin >> arr[i][j];
				arr[i][m] += arr[i][j];
				arr[n][j] += arr[i][j];
			}
		for (int i = 0; i < n; i++)
		{
			if (i)
				cout << ' ';
			printf("%.2lf", arr[i][m] / m);
		}
		cout << endl;
		for (int i = 0; i < m; i++)
		{
			if (i)
				cout << ' ';
			arr[n][i] /= n;
			printf("%.2lf", arr[n][i]);
		}
		cout << endl;
		int num = 0;
		for (int i = 0; i < n; i++)
		{
			bool flag = true;
			for (int j = 0; j < m; j++)
				if (arr[n][j] > arr[i][j])
				{
					flag = false;
					break;
				}
			if (flag)
				num++;
		}
		cout << num << endl
			 << endl;
	}
	return 0;
}