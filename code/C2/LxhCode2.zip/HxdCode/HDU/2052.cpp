#include <iostream>
#include <cstring>

using namespace std;

int main()
{
	int n, m;
	while (cin >> n >> m)
	{
		n += 2, m += 2;
		char arr[m][n];
		memset(arr, 0, sizeof(arr));
		for (int i = 0; i < m; i++)
		{
			arr[i][0] = '|';
			arr[i][n - 1] = '|';
		}
		for (int i = 0; i < n; i++)
		{
			arr[0][i] = '-';
			arr[m - 1][i] = '-';
		}
		arr[0][0] = arr[0][n - 1] = arr[m - 1][0] = arr[m - 1][n - 1] = '+';
		for (int i = 0; i < m; i++)
		{
			for (int j = 0; j < n; j++)
				if (arr[i][j])
					cout << arr[i][j];
				else
					cout << ' ';
			cout << endl;
		}
		cout << endl;
	}
	return 0;
}