#include <iostream>

using namespace std;

int main()
{
	ios::sync_with_stdio(false);
	cin.tie(0);

	int n;
	cin >> n;
	while (n--)
	{
		int num[26];
		for (int i = 0; i < 26; ++i)
			cin >> num[i];

		int ans[51] = {1};
		for (int i = 0; i < 26; ++i)
		{
			for (int j = 0; j < num[i]; ++j)
			{
				int t_ans[51];
				memcpy(t_ans, ans, sizeof(int) * 51);
				for (int k = 0; k <= 50; ++k)
					if (i + 1 + k <= 50)
						t_ans[i + 1 + k] += ans[k];
				memcpy(ans, t_ans, sizeof(int) * 51);
			}
		}
		int answer = 0;
		for (int i = 1; i <= 50; ++i)
			answer += ans[i];
		cout << answer << endl;
	}

	return 0;
}