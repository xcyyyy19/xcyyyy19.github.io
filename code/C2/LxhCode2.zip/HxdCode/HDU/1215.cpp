#include <iostream>
#include <cstring>

#define N 500005

using namespace std;

int main()
{
	ios::sync_with_stdio(false);
	cin.tie(0);

	int n;
	cin >> n;
	int arr[N];
	memset(arr, 0, sizeof(int) * N);
	for (int i = 1; i < N; ++i)
		for (int j = i + i; j < N; j += i)
			arr[j] += i;
	while (n--)
	{
		int t;
		cin >> t;
		cout << arr[t] << endl;
	}

	return 0;
}