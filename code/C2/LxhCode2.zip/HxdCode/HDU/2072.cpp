#include <iostream>
#include <string>
#include <sstream>
#include <set>

using namespace std;

int main()
{
	ios::sync_with_stdio(false);
	cin.tie(0);

	string s;
	while (getline(cin, s))
	{
		if (s == "#")
			break;
		set<string> se;
		stringstream ss(s);
		while (ss >> s)
			se.insert(s);
		cout << se.size() << endl;
	}

	return 0;
}