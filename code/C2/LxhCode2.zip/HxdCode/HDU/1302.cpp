#include <iostream>

using namespace std;

int main()
{
	ios::sync_with_stdio(false);
	cin.tie(0);

	int h, u, d, f;
	while (cin >> h >> u >> d >> f, h)
	{
		h *= 100;
		u *= 100;
		d *= 100;
		int c = u * f / 100;
		int wh = 0;
		for (int day = 1;; ++day)
		{
			wh += u;
			u = u < c ? 0 : u - c;
			if (wh > h)
			{
				cout << "success on day " << day << endl;
				break;
			}
			wh -= d;
			if (wh < 0)
			{
				cout << "failure on day " << day << endl;
				break;
			}
		}
	}

	return 0;
}