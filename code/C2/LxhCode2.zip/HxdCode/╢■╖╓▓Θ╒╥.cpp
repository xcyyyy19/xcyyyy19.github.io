#include <iostream>

using namespace std;

template <typename T>
bool find(T value, T *begin, T *end) // 需要类型 T 提供 < 运算符, 并且要求 !(a < b) && !(b < a) 与 a == b 等价
{
	T *middle = begin + (end - begin) / 2;

	if (end - begin < 1)
		return false;
	if (!(*middle < value) && !(value < *middle))
		return true;

	if (*middle < value)
		return find(value, middle + 1, end);
	else
		return find(value, begin, middle);
}

int main()
{
	int arr[50];
	for (int i = 0; i < 50; ++i)
		arr[i] = i * 2;

	for (int i = 0; i < 100; ++i)
		cout << i << " : " << find(i, arr, arr + 50) << endl;

	return 0;
}
