#include <iostream>
#include <cstring> // 即C语言头文件string.h, 在C++中为cstring, 同理, stdio.h 为 cstdio, math.h 为 cmath
#include <queue>   // queue 队列, 一种先进先出的数据结构
// 什么是先进先出, 比如说将 1 2 3 按顺序入栈, 那么出栈的顺序即 1 2 3
using namespace std;
// 下面用队列写一个 马走日, 帮助理解以及如何使用
// 同时使用了 BFS 算法, 即 宽度优先搜索, 看懂了的话给你点100个赞!! 不, 1000个, 10000个!!!
struct Location
{
	int x, y, w;
	bool operator==(const Location &b) const // 重载 == 运算符, 因为比较的时候只用比 x, y 而不用比 w
	{
		return this->x == b.x && this->y == b.y;
	}
};

int main()
{
	int dx[8] = {-1, -2, -2, -1, +1, +2, +2, +1};
	int dy[8] = {-2, -1, +1, +2, +2, +1, -1, -2};

	int n;
	Location start, end;
	cin >> n >> start.x >> start.y >> end.x >> end.y;
	start.w = 0;

	bool arr[n][n]; //该数组用来标记对应位置是否已访问
	memset(arr, false, sizeof(arr));

	queue<Location> q;			  // 定义一个队列 q, 存储 Location 类型数据
	q.push(start);				  // 将 start 入队
	arr[start.x][start.y] = true; // 将起始位置标记为已访问

	int ans = -1;
	while (q.size()) // q.size() 即队列中元素个数
	{
		Location tloc = q.front();  // 访问队首元素, 实际上还有 q.back() 用以访问队尾元素
		q.pop();					// 将队首元素出队
		for (int i = 0; i < 8; ++i) // 遍历 8 个方向
		{
			Location nloc;
			nloc.x = tloc.x + dx[i];
			nloc.y = tloc.y + dy[i];
			nloc.w = tloc.w + 1;															   // 每一步为上一步所花步数 +1
			if (nloc.x < 0 || nloc.x >= n || nloc.y < 0 || nloc.y >= n || arr[nloc.x][nloc.y]) // 判断是否越界或已访问
				continue;
			else if (nloc == end)
			{
				ans = nloc.w; // 记录所花步数
				goto label;   // break只能跳出一重循环, 而这里有两重, 所以使用goto语句 (当然还可以通过立 flag 的方式跳出
			}
			q.push(nloc);				// 将 nloc 入队
			arr[nloc.x][nloc.y] = true; // 将该位置标记
		}
	}
label:
	cout << ans << endl;

	return 0;
}