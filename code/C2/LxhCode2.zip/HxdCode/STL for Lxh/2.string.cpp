#include <iostream>
#include <string> // c++中字符串的类型, 注意区分 string 与 string.h, 这是两个完全不同的头文件

using namespace std;

int main()
{
	string s;
	if (1)
		cin >> s; //这是读取一个字符串, 遇空白停止
	else
		getline(cin, s); //这才是读取一行的正确操作

	for (int i = 0; i < s.size(); ++i) // 遍历字符串, 将小写字母变为大写, s.size()的值为字符串的长度
		if (s[i] >= 'a' && s[i] <= 'z')
			s[i] -= 'a' - 'A';

	cout << s;

	return 0;
}
// string 好像也没什么好讲的, 但是它里面还有很多函数, 不过并不是很常用, 更具体的可以查阅这个网站
// http://zh.cppreference.com/w/cpp/string/basic_string