#include <iostream>
#include <map> // map 映射, 能够通过一个 key 访问到一个唯一对应的 value

using namespace std;

int main()
{
	map<int, double> m;														   // 定义一个映射 s, key的类型为int, value的类型为double
	m[1] = 2.3, m[2] = 3.4, m[10] = 11.12;									   // m[key]=value;
	m[2] = 4.5;																   // 可以随时通过 key 来修改 value 的值
	cout << m[3] << endl;													   // 如果没有赋值过, 其 value 默认为 0
	for (map<int, double>::iterator iter = m.begin(); iter != m.end(); ++iter) // 通过迭代器来访问 map 的所有元素,
		cout << iter->first << ' ' << iter->second << endl;					   // map 的迭代器有一点特殊, 解引用后是一个 pair 类型,
																			   // pair 类型有两个成员, 一个是 first, 对应 map 的 key
	return 0;																   // 一个是 second, 对应 map 的 value
}