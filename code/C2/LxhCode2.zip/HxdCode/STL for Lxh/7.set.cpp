#include <iostream>
#include <set> // set 集合, 具有互异性, 即元素不会重复， 且内部元素按照 < 排序

using namespace std;

int main()
{
	set<int> s; // 定义一个集合 s, 存储 int 类型数据

	for (int i = 0; i < 100; ++i)
		s.insert(i); // 在集合中插入一个 i, insert vt.插入
	for (int i = 0; i < 100; ++i)
		s.insert(i); // 注意, 这里我把每个元素又插入了一遍, 但是看输入结果可以发现, 每个元素依然只出现了一次而不是两次, 这就是集合的互异性
	for (int i = 95; i < 105; ++i)
	{
		set<int>::iterator iter = s.find(i); // find函数会返回找到的 value 对应的迭代器
		if (iter != s.end())				 // 如果find函数没要找到该 value, 那么返回 end()
			cout << *iter << ":true  ";
		else
			cout << i << ":false  ";
	}
	cout << endl;
	// set也需要通过迭代器访问
	for (set<int>::iterator iter = s.begin(); iter != s.end(); ++iter) // 通过迭代器遍历整个 set
		cout << *iter << ' ';

	return 0;
}