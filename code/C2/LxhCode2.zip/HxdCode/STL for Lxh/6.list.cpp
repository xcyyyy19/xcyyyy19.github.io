#include <iostream>
#include <list> // list 链表, 是一种数据在内存中不连续存储的数据结构
// 这种数据结构能够进行快速的删除插入操作, 但是缺点是不能进行随机访问
using namespace std;

void print(const list<int> &l)
{
	for (list<int>::const_iterator iter = l.begin(); iter != l.end(); ++iter) // l.begin() l.end()
		cout << *iter << ' ';
	cout << endl;
}

int main()
{
	list<int> l; // 定义一个链表 l, 存储 int 类型数据
	for (int i = 0; i < 100; ++i)
		l.push_back(i); // 在链表尾部添加一个 i
	print(l);
	// list不可通过[]的方式访问元素, 只能通过迭代器访问, 可以暂时的把迭代器理解为一种特殊的指针
	for (list<int>::iterator iter = l.begin(); iter != l.end(); ++iter)
	{
		// if (*iter % 2 == 0)
		// 	l.erase(iter);
		// 上面这是错误的写法，正确的在下面
		if (*iter % 2 == 0) // 上面错误的原因是当 iter 指向的元素被删除后, iter 就被非法化了, ++ 操作不在可行
		{					// 所以正确的做法是创建一个临时的迭代器指向 iter 指向的元素, 然后 --iter, 然后删除临时迭代器指向的元素
			list<int>::iterator titer = iter--;
			l.erase(titer);
		}
	}
	print(l);
	int count = 0;
	for (list<int>::iterator iter = l.begin(); iter != l.end(); ++iter)
	{
		l.insert(iter, count);
		count += 2;
	}
	print(l);

	return 0;
}