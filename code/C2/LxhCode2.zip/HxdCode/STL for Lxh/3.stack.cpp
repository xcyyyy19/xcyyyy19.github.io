#include <iostream>
#include <stack> // stack 栈, 一种后进先出的数据结构
// 什么是后进先出, 比如说将 1 2 3 按顺序入栈, 那么出栈的顺序即 3 2 1
using namespace std;
// 下面用栈写一个进制转换, 帮助理解以及如何使用
int main()
{
	stack<int> s; // 定义一个栈 s, 存储 int 类型数据

	int i;
	cin >> i; // 输入一个 i, 将其转换为二进制

	do
	{
		s.push(i % 2); // 将 i % 2 的值入栈, push vt.推
		i /= 2;
	} while (i);

	while (s.size()) // s.size()的值是当前栈中元素的数量
	{
		cout << s.top(); // 访问栈顶元素
		s.pop();		 // 将栈顶元素出栈
	}

	return 0;
}
// 栈的内容并不多, 只要理解栈的原理， 并且会使用 size top push pop 四个函数就够