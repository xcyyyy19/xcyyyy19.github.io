#include <iostream>
#include <vector> // vector 变长数组, 是一个长度可以变化的数组

using namespace std;

int main()
{
	vector<int> v; // 定义一个变长数组 v, 存储 int 类型数据

	for (int i = 0; i < 100; ++i)
		v.push_back(i); // 在数组尾部添加一个 i

	for (int i = 0; i < v.size(); ++i) // v.size()是当前数组中元素的数量
		cout << v[i] << ' ';		   // vector可以通过[]的方式访问元素

	return 0;
}
// 实际上 vector 也可以单独的删除中间的某个元素或插入, 但是这个操作的时间复杂度太高, 所以并不推荐
// 如果需要大量的插入删除操作, 应该使用接下来所介绍的 list 链表