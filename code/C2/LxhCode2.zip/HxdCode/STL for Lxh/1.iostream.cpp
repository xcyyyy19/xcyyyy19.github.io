#include <iostream> // input output stream 输入输出流
// 含有 cin, cout 等 (cin -> c-in, cout -> c-out)
using namespace std;

int main()
{
	int a, b;
	cin >> a >> b; // 从键盘读取一个数到a, 再读取一个到b
	// 可以理解为 scanf("%d%d", &a, &b);
	cout << a + b << endl; // 输出 a + b, endl为换行
	// 可以理解为 printf("%d\n", a+b);
	return 0;
}
// 嗯, 这个比较好理解, 就这样简单的讲一下吧
// 哦, 对了, 要注意, cin 用的是 >>, 而 cout 用的是 <<
// 我感觉这个还是比较生动形象的, 因为这是流嘛, 流
// 把数据从 cin 流进 a 和 b, 所以是cin >> a >> b;
// 把 a + b 和 endl 流进 cout, 所以是cout << a + b << endl;
// 是吧? ~~