#include <iostream>
#include <cstring>

using namespace std;

void dfs(int *arr, bool *book, int n, int i)
{
	if (i == n)
	{
		for (int j = 0; j < n; ++j)
			cout << arr[j] << ' ';
		cout << endl;
		return;
	}
	for (int j = 0; j < n; ++j)
		if (book[j] == 0)
		{
			book[j] = 1;
			arr[i] = j + 1;
			dfs(arr, book, n, i + 1);
			book[j] = 0;
		}
}

void quan_pai_lie(int n)
{
	int arr[n];
	bool book[n];
	memset(book, 0, sizeof(book));

	dfs(arr, book, n, 0);
}

int main()
{
	ios::sync_with_stdio(false);
	cin.tie(0);

	quan_pai_lie(3);

	return 0;
}