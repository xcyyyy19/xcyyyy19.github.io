#include <iostream>
#include <algorithm>
#include <cstdlib>

#define N 1000000

using namespace std;

int main()
{
	int *p = new int[N];
	for (int i = 0; i < N; ++i)
		p[i] = rand();
	auto func = [](int a, int b) -> bool { return a < b; };
	sort(p, p + N, func);

	int a = 3, b = 5, t = 8;
	auto swap = [](int &a, int &b) { int t; t=a,a=b,b=t; };
	swap(a, b);
	cout << a << ' ' << b << ' ' << t;

	return 0;
}