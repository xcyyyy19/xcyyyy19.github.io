#include <stdio.h>

int judge(int *arr, int n, int ceng)
{
	int i;
	for (i = 0; i < ceng; ++i)
		if (arr[ceng] == arr[i] ||
			arr[ceng] == arr[i] + ceng - i ||
			arr[ceng] == arr[i] - ceng + i)
			return 0;
	return 1;
}

int n_queen_dfs(int *arr, int n, int ceng)
{
	int i, count = 0;
	for (i = 0; i < n; ++i)
	{
		arr[ceng] = i;
		if (judge(arr, n, ceng))
		{
			if (ceng + 1 == n)
				return 1;
			else
				count += n_queen_dfs(arr, n, ceng + 1);
		}
	}
	return count;
}

int n_queen(int n)
{
	int i, arr[n];
	for (i = 0; i < n; ++i)
		arr[i] = -1;
	return n_queen_dfs(arr, n, 0);
}

int main()
{
	int i;
	for (i = 1; i <= 13; ++i)
		printf("%d queen: %d\n", i, n_queen(i));
	return 0;
}