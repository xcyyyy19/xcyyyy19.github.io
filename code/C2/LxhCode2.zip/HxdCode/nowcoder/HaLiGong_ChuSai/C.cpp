#include <iostream>

using namespace std;

int main()
{
	ios::sync_with_stdio(false);
	cin.tie(0);

	for (int i = 10000000; i < 100000000; ++i)
	{
		int arr[8];
		int t = i;
		for (int j = 0; j < 8; ++j)
		{
			arr[j] = t % 10;
			t /= 10;
		}
		if (arr[0] == arr[7] && arr[1] == arr[6] && arr[2] == arr[5] && arr[3] == arr[4])
			cout << i << endl;
	}

	return 0;
}