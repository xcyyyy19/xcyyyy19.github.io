#include <iostream>
#include <algorithm>

using namespace std;

bool f(int v, int *b, int *e)
{
	int *m = b + (e - b) / 2;
	return e - b < 1 ? 0 : *m == v ? 1 : *m < v ? f(v, m + 1, e) : f(v, b, m);
}

int main()
{
	ios::sync_with_stdio(false);
	cin.tie(0);

	int n, x;
	cin >> n >> x;
	int arr[n];
	for (int i = 0; i < n; ++i)
		cin >> arr[i];
	sort(arr, arr + n);
	bool flag = false;
	for (int i = 0; i < n; ++i)
	{
		for (int j = 0; j < n; ++j)
		{
			int c = -arr[i] * x * x - arr[j] * x;
			if (f(c, arr, arr + n))
			{
				cout << "YES" << endl;
				return 0;
			}
		}
	}
	cout << "NO" << endl;
	return 0;
}