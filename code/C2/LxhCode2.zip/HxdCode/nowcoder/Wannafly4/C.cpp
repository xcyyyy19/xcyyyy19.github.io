#include <iostream>

using namespace std;

struct S
{
	int left, right;
};

inline int max(const S &a, const S &b)
{
	return a.right > b.right ? a.right : b.right;
}

inline int min(const S &a, const S &b)
{
	return a.left < b.left ? a.left : b.left;
}

int main()
{
	ios::sync_with_stdio(false);
	cin.tie(0);

	int n, m;
	cin >> n >> m;
	S arr[n];
	int brr[n - 1];
	for (int i = 0; i < n; ++i)
	{
		arr[i].left = m - 1;
		arr[i].right = 0;
		bool first = true;
		for (int j = 0; j < m; ++j)
		{
			char c;
			cin >> c;
			if (c == 'W')
			{
				if (first)
					arr[i].left = j;
				arr[i].right = j;
				first = false;
			}
		}
		if (i)
			brr[i - 1] = i % 2 ? max(arr[i], arr[i - 1]) : min(arr[i], arr[i - 1]);
	}
	for (int i = n - 1; i >= 0; --i)
	{
		if (arr[i].left > arr[i].right)
			--n;
		else
			break;
	}

	bool flag[n];
	for (int i = 0; i < n; ++i)
		flag[i] = arr[i].left < arr[i].right;

	int sum = brr[0] + n - 1;
	sum = sum > 0 ? sum : 0;
	for (int i = 1; i < n - 1; ++i)
	{
		if (flag[i - 1])
			sum += abs(brr[i] - brr[i - 1]);
	}

	if (n > 2)
		sum += n % 2 ? abs(brr[n - 2] - arr[n - 1].right) : abs(brr[n - 2] - arr[n - 1].left);
	else if (n == 2)
		sum += abs(brr[0] - arr[1].left);

	cout << sum << endl;

	return 0;
}