#include <iostream>

using namespace std;

template <typename T>
bool f(T v, T *b, T *e) // 需排升序并提供 < 及 == 运算符
{
	T *m = b + (e - b) / 2;
	return e - b < 1 ? 0 : *m == v ? 1 : *m < v ? f(v, m + 1, e) : f(v, b, m);
}

int main()
{
	int arr[50];
	for (int i = 0; i < 50; ++i)
		arr[i] = i * 2;

	for (int i = 0; i < 100; ++i)
		cout << i << " : " << f(i, arr, arr + 50) << endl;

	return 0;
}
