#include <iostream>
#include <set>

using namespace std;

int main()
{
	int n;
	cin >> n;
	multiset<int> ms;
	for (int i = 0; i < n; ++i)
	{
		int t;
		cin >> t;
		ms.insert(t);
	}
	int sum = 0;
	while (ms.size() > 1)
	{
		int a = *ms.begin();
		ms.erase(ms.begin());
		int b = *ms.begin();
		ms.erase(ms.begin());
		sum += a + b;
		ms.insert(a + b);
	}
	cout << sum;

	return 0;
}