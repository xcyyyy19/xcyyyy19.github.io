#include <iostream>

using namespace std;

struct Location
{
	int x, y;
	Location(int _x = 0, int _y = 0) : x(_x), y(_y) {}
	bool operator<(const Location &b) const { return x < b.x && y < b.y; }
};

Location max(const Location &a, const Location &b)
{
	return Location(a.x > b.x ? a.x : b.x, a.y > b.y ? a.y : b.y);
}
Location min(const Location &a, const Location &b)
{
	return Location(a.x < b.x ? a.x : b.x, a.y < b.y ? a.y : b.y);
}

void change(Location &a, Location &b)
{
	if (b < a)
	{
		Location t;
		t = a, a = b, b = t;
	}
	else if (!(a < b))
	{
		Location ta = min(a, b), tb = max(a, b);
		a = ta, b = tb;
		change(a, b);
	}
}

int main()
{
	Location A, B, a, b;
	cin >> A.x >> A.y >> B.x >> B.y >> a.x >> a.y >> b.x >> b.y;
	change(A, B), change(a, b);
	a = a < B ? max(a, A) : min(a, B);
	b = A < b ? min(b, B) : max(b, A);
	cout << (b.x - a.x) * (b.y - a.y);
	return 0;
}