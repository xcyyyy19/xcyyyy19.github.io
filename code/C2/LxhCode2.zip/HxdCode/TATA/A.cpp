#include <iostream>

using namespace std;

int calc(unsigned n)
{
	unsigned c = 0;
	for (c = 0; n; ++c)
		n &= ~-n;
	return c;
}

int main()
{
	ios::sync_with_stdio(false);
	cin.tie(0);

	int arr[55];
	int n;
	cin >> n;
	int max = 0;
	for (int i = 0; i < n; ++i)
	{
		unsigned t;
		cin >> t;
		arr[i] = calc(t);
		max = arr[max] > arr[i] ? max : i;
	}
	int max_sum = 0;
	for (int i = 1; i < n - 1; ++i)
	{
		int sheng_sum = 0;
		for (int j = i - 1; j >= 0; --j)
			if (arr[j + 1] > arr[j])
				sheng_sum += arr[j];
			else
				break;
		if (!sheng_sum)
			continue;
		sheng_sum += arr[i];

		int jiang_sum = 0;
		for (int j = i + 1; j < n; ++j)
		{
			if (arr[j] < arr[i])
			{
				int t_jiang_sum = arr[j];
				for (int k = j + 1; k < n; ++k)
					if (arr[k - 1] > arr[k])
						t_jiang_sum += arr[k];
					else
						break;
				jiang_sum = jiang_sum > t_jiang_sum ? jiang_sum : t_jiang_sum;
			}
		}
		if (jiang_sum)
			max_sum = max_sum > sheng_sum + jiang_sum ? max_sum : sheng_sum + jiang_sum;
	}
	if (max_sum)
		cout << max_sum;
	else
		cout << "Impossible";

	return 0;
}