#include <iostream>
#include <cstdio>

int k, m, n;

int dfs(int sum = 0, int num = 0, int prime_num = 0, int i = 1)
{
	const bool book[] = {0, 0, 1, 1, 0, 1, 0, 1, 0, 0, 0};

	if (num == k)
		return sum % n == m && prime_num > 1;

	int ans = 0;
	for (int j = i; j < n; ++j)
	{
		if (j > 7 && prime_num < 2)
			break;
		ans += dfs(sum + j, num + 1, prime_num + book[j], j);
	}
	return ans;
}

int main()
{
	scanf("%d,%d,%d", &k, &m, &n);

	std::cout << dfs();

	return 0;
}