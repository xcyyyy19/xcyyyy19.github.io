// #pragma GCC diagnostic error "-std=c++11"

#include <iostream>
#include <cstring>

using namespace std;

class Tree_array
{
  public:
	int *p;
	int len;
	Tree_array(int n, int *arr = NULL) : len(n)
	{
		p = new int[len + 1];
		memset(p, 0, sizeof(int) * (len + 1));
		if (arr)
			for (int i = 1; i <= len; ++i)
				updata(i, arr[i - 1]);
	}
	Tree_array(const Tree_array &arr) : len(arr.len)
	{
		p = new int[len + 1];
		memcpy(p, arr.p, sizeof(int) * (len + 1));
	}
	~Tree_array()
	{
		delete[] p;
	}
	Tree_array &updata(int loc, int add)
	{
		while (loc <= len)
		{
			p[loc] += add;
			loc += lowbit(loc);
		}
		return *this;
	}
	int query(int loc) const
	{
		int ans = 0;
		while (loc > 0)
		{
			ans += p[loc];
			loc -= lowbit(loc);
		}
		return ans;
	}
	int operator[](int x) const
	{
		return query(x + 1) - query(x);
	}
	int operator()(int left, int right) const
	{
		return query(right) - query(left);
	}

  private:
	int lowbit(int x) const
	{
		return x & -x;
	}
};

int main()
{
	int num[] = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};
	Tree_array arr(10, num);
	cout << endl;
	cout << arr(1, 9) << endl;
	Tree_array fb(arr);
	fb.updata(5, 1).updata(1, 1).updata(2, 1).updata(3, 1).updata(4, 1);
	for (int i = 1; i <= 10; i++)
		cout << arr[i - 1] << ' ';
	cout << endl;
	for (int i = 0; i < 10; i++)
		cout << fb[i] << ' ';
	cout << endl
		 << fb(0, 10) << endl;
	return 0;
}
