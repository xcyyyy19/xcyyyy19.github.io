#include <iostream>
#include <queue>

using namespace std;

int main()
{
	queue<int> q;
	q.push(20);
	int count = 0;
	while (q.size())
	{
		int t = q.front();
		q.pop();
		for (int i = 1; i <= 3; ++i)
		{
			int n = t - i;
			if (n > 0)
				q.push(n);
			else if (n == 0)
				++count;
		}
	}
	cout << count << endl;
	return 0;
}