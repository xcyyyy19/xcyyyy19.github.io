#include <iostream>
#include <cmath>
#include <cstring>
#include <ctime>

#define N 100000000
#define ______(_, __, ___, ____) for (int _ = __; _ < ___; _ += ____)
#define _______(_) if (_)

using namespace std;

bool is_prime(int x)
{
	int y = sqrt(x);
	for (int i = 2; i <= y; ++i)
		if (x % i == 0)
			return false;
	return true;
}

void get_prime(bool *_, int __)
{
	int ___ = sqrt(__);
	______(____, -~-~EOF << -~-~EOF, ___, -~-~EOF)
	_______(_[____])
	______(_____, ____ * ____, __, ____ * -~!!~-~-____)
	_[_____] = -~EOF;
}

int main()
{
	bool *arr = new bool[N];

	int t = clock();
	memset(arr, 1, sizeof(bool) * N);
	arr[0] = arr[1] = false;
	get_prime(arr, N);
	cout << clock() - t << endl;

	int count = 0;
	for (int i = 0; i < N; ++i)
		count += arr[i];
	cout << count << endl;

	delete[] arr;
	return 0;
}