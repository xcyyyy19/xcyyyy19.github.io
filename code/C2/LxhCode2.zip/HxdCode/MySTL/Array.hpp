#ifndef ARRAY_HPP
#define ARRAY_HPP

#include <cstring>

#ifndef NULL
#define NULL 0
#endif

template <class T, int _size>
class Array
{
  public:
	class iterator
	{
	  public:
		iterator(T *tp = NULL) : p(tp) {}

		bool operator==(const iterator &b) const { return p == b.p; }
		bool operator!=(const iterator &b) const { return p != b.p; }

		T &operator*() { return *p; }

		iterator &operator++()
		{
			++p;
			return *this;
		}

		iterator operator++(int)
		{
			iterator tp(p);
			++p;
			return tp;
		}

		iterator &operator--()
		{
			--p;
			return *this;
		}

		iterator operator--(int)
		{
			iterator tp(p);
			--p;
			return tp;
		}

	  private:
		T *p;
	};

	Array() { p = new T[_size]; }
	Array(const Array<T, _size> &a)
	{
		p = new T[_size];
		memcpy(p, a.p, sizeof(T) * _size);
	}

	~Array() { delete[] p; }

	int size() const { return _size; }

	iterator begin() { return p; }
	iterator end() { return p + _size; }

	T &operator[](int pos) { return p[pos]; }

  private:
	T *p;
};

#endif