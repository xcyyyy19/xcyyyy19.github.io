#ifndef NAME
#define NAME

#endif

// deque

// set
// multiset
// unordered_set(C++ 11)
// unordered_multiset(C++ 11)

// map
// multimap
// unordered_map(C++ 11)
// unordered_multimap(C++ 11)
