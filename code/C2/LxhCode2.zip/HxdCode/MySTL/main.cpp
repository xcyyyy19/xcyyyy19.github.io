#include <iostream>
#include <algorithm>
#include <cstring>
#include <cstdlib>
#include <ctime>
#include "Array.hpp"
#include "Functional.hpp"
#include "List.hpp"
#include "Queue.hpp"
#include "Stack.hpp"
#include "String.hpp"
#include "Vector.hpp"

using std::cin;
using std::cout;
using std::endl;

int main()
{
	// Priority_Queue<int, Greater<int>> pq;
	// Vector<int> v;
	// for (int i = 0; i < 1000000; ++i)
	// 	v.push_back(rand() % 10000);
	// int t = clock();
	// pq.Vector_to_Priority_Queue(v);
	// v.clear();
	// while (pq.size())
	// {
	// 	v.push_back(pq.top());
	// 	pq.pop();
	// }
	// cout << clock() - t << "\n\n";
	// cout << "\n\n";
	// for (int i = 1; i < v.size(); ++i)
	// {
	// 	if (v[i] < v[i - 1])
	// 	{
	// 		cout << v[i] << ' ' << v[i - 1] << endl;
	// 		cout << i << ": fuck" << endl;
	// 		return 0;
	// 	}
	// }
	// cout << "ok" << endl;

	Vector<String> v;
	String s = "hxdlovelxh";
	v.push_back(s);
	cout << s << ' ' << s.size() << endl;
	cin >> s;
	v.push_back(s);
	cout << s << ' ' << s.size() << endl;
	getline(cin, s);
	v.push_back(s);
	cout << s << ' ' << s.size() << endl;

	for (Vector<String>::iterator iter = v.begin(); iter != v.end(); ++iter)
		cout << iter->c_str() << endl;

	// std::sort(v.begin(), v.end());

	for (Vector<String>::iterator iter = v.begin(); iter != v.end(); ++iter)
		cout << iter->c_str() << endl;

	return 0;
}