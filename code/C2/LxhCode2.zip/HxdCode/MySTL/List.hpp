#ifndef LIST_HPP
#define LIST_HPP

#include <iostream>

#ifndef NULL
#define NULL 0
#endif

template <class T>
struct List_node
{
	T data;
	List_node<T> *prev;
	List_node<T> *next;
	List_node(const T &value) : data(value), prev(NULL), next(NULL) {}
};

template <class T>
class List
{
  public:
	class iterator
	{
	  public:
		iterator(List_node<T> *tp = NULL) : p(tp) {}

		bool operator==(const iterator &b) const { return p == b.p; }
		bool operator!=(const iterator &b) const { return p != b.p; }

		T &operator*() { return p->data; }

		iterator &operator++()
		{
			p = p->next;
			return *this;
		}

		iterator operator++(int)
		{
			iterator tp(p);
			p = p->next;
			return tp;
		}

		iterator &operator--()
		{
			p = p->prev;
			return *this;
		}

		iterator operator--(int)
		{
			iterator tp(p);
			p = p->prev;
			return tp;
		}

	  private:
		List_node<T> *p;
	};

	List() : _size(0), head(NULL), rear(NULL) {}

	~List() { clear(); }

	List &push_back(const T &value)
	{
		List_node<T> *np = new List_node<T>(value);
		if (_size)
		{
			rear->next = np;
			np->prev = rear;
		}
		else
			head = np;
		rear = np;
		_size++;

		return *this;
	}

	List &push_front(const T &value)
	{
		if (_size)
		{
			List_node<T> *np = new List_node<T>(value);
			np->next = head;
			head->prev = np;
			head = np;
			_size++;
			return *this;
		}
		return push_back(value);
	}

	List &insert(int pos, const T &value)
	{
		if (pos == 0)
			return push_front(value);
		else if (pos == _size)
			return push_back(value);

		List_node<T> *p = head;
		for (int i = 1; i < pos; ++i)
			p = p->next;
		List_node<T> *np = new List_node<T>(value);
		np->next = p->next;
		p->next->prev = np;
		np->prev = p;
		p->next = np;
		_size++;
		return *this;
	}

	List &pop_back()
	{
		if (_size > 1)
		{
			rear = rear->prev;
			delete rear->next;
			rear->next = NULL;
			_size--;
		}
		else if (_size == 1)
		{
			delete head;
			_size = 0;
			head = NULL;
			rear = NULL;
		}
		return *this;
	}

	List &pop_front()
	{
		if (_size < 2)
			return pop_back();

		head = head->next;
		delete head->prev;
		head->prev = NULL;
		_size--;
		return *this;
	}

	List &erase(int pos)
	{
		if (pos == 0)
			return pop_front();
		else if (pos == _size - 1)
			return pop_back();

		List_node<T> *p = head;
		for (int i = 0; i < pos; ++i)
			p = p->next;
		p->prev->next = p->next;
		p->next->prev = p->prev;
		delete p;
		_size--;
		return *this;
	}

	T front() const { return head->data; }
	T back() const { return rear->data; }

	T get_value(int pos) const
	{
		List_node<T> *p = head;
		while (pos--)
			p = p->next;
		return p->data;
	}

	int size() const { return _size; }
	bool empty() const { return !_size; }

	void print() const
	{
		List_node<T> *p = head;
		for (int i = 0; i < _size; ++i)
		{
			if (i)
				std::cout << ' ';
			std::cout << p->data;
			p = p->next;
		}
		std::cout << std::endl;
	}

	List &clear()
	{
		List_node<T> *p = head;
		while (p)
		{
			delete p->prev;
			p = p->next;
		}
		_size = 0;
		head = NULL;
		rear = NULL;
		return *this;
	}

	iterator begin() { return head; }
	iterator end() { return 0; }

  private:
	int _size;
	List_node<T> *head;
	List_node<T> *rear;
};

#endif