#ifndef STACK_HPP
#define STACK_HPP

#include "List.hpp"

template <class T>
class Stack
{
public:
	Stack &push(const T &value)
	{
		s.push_back(value);
		return *this;
	}

	Stack &pop()
	{
		s.pop_back();
		return *this;
	}

	T top() { return s.back(); }

	int size() const { return s.size(); }

private:
	List<T> s;
};

#endif