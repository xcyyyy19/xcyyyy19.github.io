#include <iostream>
#include <list>

using namespace std;

int f(int n, int m)
{
	return n == 1 ? 0 : (f(n - 1, m) + m) % n;
}

int main()
{
	ios::sync_with_stdio(false);
	cin.tie(0);

	int n;
	cin >> n;
	cout << f(n, 77) << endl;

	return 0;
}