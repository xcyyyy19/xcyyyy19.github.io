#ifndef VECTOR_HPP
#define VECTOR_HPP

#include <cstring>

template <class T>
class Vector
{
  public:
	class iterator
	{
	  public:
		iterator(T *tp = NULL) : p(tp) {}

		bool operator==(const iterator &b) const { return p == b.p; }
		bool operator!=(const iterator &b) const { return p != b.p; }

		T &operator*() { return *p; }

		T *operator->() { return p; }

		iterator operator+(int i) const { return p + i; }

		int operator-(const iterator &i) const { return p - i.p; }

		iterator &operator++()
		{
			++p;
			return *this;
		}

		iterator operator++(int)
		{
			iterator tp(p);
			++p;
			return tp;
		}

		iterator &operator--()
		{
			--p;
			return *this;
		}

		iterator operator--(int)
		{
			iterator tp(p);
			--p;
			return tp;
		}

	  private:
		T *p;
	};

	Vector(int cap = 8) : _size(0), _capacity(cap) { p = new T[_capacity]; }
	Vector(const Vector &v) : _size(v._size), _capacity(v._capacity)
	{
		p = new T[_capacity];
		memcpy(p, v.p, sizeof(T) * _size);
	}

	~Vector() { delete[] p; }

	Vector &insert(int pos, const T &value)
	{
		if (pos <= _size)
		{
			if (_size == _capacity)
				double_capacity();
			for (int i = _size; i > pos; --i)
				p[_size] = p[_size - 1];
			p[pos] = value;
			_size++;
		}
		return *this;
	}

	Vector &erase(int pos)
	{
		if (_size > 0)
		{
			_size--;
			for (int i = pos; i < _size; ++i)
				p[i] = p[i + 1];
		}
		return *this;
	}

	Vector &push_back(const T &value) { return insert(_size, value); }
	Vector &pop_back() { return erase(_size - 1); }

	Vector &clear()
	{
		_size = 0;
		return *this;
	}

	T &front() { return p[0]; }
	T &front() const { return p[0]; }
	T &back() { return p[_size - 1]; }

	int size() const { return _size; }
	bool empty() const { return !_size; }
	int capacity() const { return _capacity; }

	iterator begin() { return p; }
	iterator end() { return p + _size; }

	Vector &operator=(const Vector &b)
	{
		_size = b._size;
		_capacity = b._capacity;
		delete[] p;
		p = new T[_capacity];
		memcpy(p, b.p, sizeof(T) * _size);
	}

	T &operator[](int pos) { return p[pos]; }

  private:
	int _size;
	int _capacity;
	T *p;

	Vector &double_capacity()
	{
		T *np = new T[_capacity *= 2];
		memcpy(np, p, sizeof(T) * _size);
		delete[] p;
		p = np;
		return *this;
	}
};

#endif