#ifndef QUEUE_HPP
#define QUEUE_HPP

#include "List.hpp"
#include "Vector.hpp"
#include "Functional.hpp"

template <class T>
class Queue
{
  public:
	Queue &push(const T &value)
	{
		q.push_back(value);
		return *this;
	}

	Queue &pop()
	{
		q.pop_front();
		return *this;
	}

	T front() { return q.front(); }
	T back() { return q.back(); }

	int size() const { return q.size(); }

  private:
	List<T> q;
};

template <class T, class Cmp = Less<T>>
class Priority_Queue
{
  public:
	Priority_Queue &push(const T &value)
	{
		v.push_back(value);
		up_adjust(v.size() - 1);
		return *this;
	}

	Priority_Queue &pop()
	{
		if (v.size())
		{
			v[0] = v[v.size() - 1];
			v.pop_back();
			down_adjust(0);
		}
		return *this;
	}

	T top() const { return v.front(); }

	int size() const { return v.size(); }
	bool empty() const { return v.empty(); }

	Priority_Queue &clear()
	{
		v.clear();
		return *this;
	}

	Priority_Queue &Vector_to_Priority_Queue(const Vector<T> &vec)
	{
		clear();
		v = vec;
		for (int i = v.size() - 1; i >= 0; --i)
			down_adjust(i);
		return *this;
	}

	Priority_Queue &Priority_Queue_to_Vector(Vector<T> &vec)
	{
		vec = v;
		return *this;
	}

  private:
	Vector<T> v;
	Cmp cmp;

	int left_child(int x) { return -~(x << 1); }
	int right_child(int x) { return -~-~(x << 1); }
	int father(int x) { return ~-x >> 1; }
	void swap(T &a, T &b)
	{
		T t;
		t = a, a = b, b = t;
	}

	void down_adjust(int pos)
	{
		int l = left_child(pos), r = right_child(pos);
		if (r < v.size())
		{
			if (cmp(v[pos], v[l]) && !cmp(v[l], v[r]))
			{
				swap(v[pos], v[l]);
				down_adjust(l);
			}
			else if (cmp(v[pos], v[r]) && !cmp(v[r], v[l]))
			{
				swap(v[pos], v[r]);
				down_adjust(r);
			}
		}
		else if (l < v.size() && cmp(v[pos], v[l]))
		{
			swap(v[pos], v[l]);
			down_adjust(l);
		}
	}
	void up_adjust(int pos)
	{
		if (pos)
		{
			int f = father(pos);
			if (cmp(v[f], v[pos]))
			{
				swap(v[f], v[pos]);
				up_adjust(f);
			}
		}
	}
};

#endif