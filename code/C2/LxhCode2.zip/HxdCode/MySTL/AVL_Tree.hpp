#ifndef AVL_TREE_HPP
#define AVL_TREE_HPP

#ifndef NULL
#define NULL 0
#endif

template <class T>
struct AVL_Tree_Node
{
	T data;
	int height;
	AVL_Tree_Node<T> *father;
	AVL_Tree_Node<T> *left_child;
	AVL_Tree_Node<T> *right_child;

	AVL_Tree_Node(const T &value, int h = 1, AVL_Tree_Node *f = NULL, AVL_Tree_Node *l = NULL, AVL_Tree_Node *r = NULL)
		: data(value), height(h), father(f), left_child(l), right_child(r) {}
};

template <class T>
class AVL_Tree
{
  public:
	AVL_Tree() : root(NULL), _size(0) {}

	AVL_Tree &push(T value)
	{
		AVL_Tree_Node<T> *p = root;
		while (p)
		{
			if (value < p->data)
				p = p->left_child;
			else if (p->data < value)
				p = p->right_child;
			else
				return *this;
		}
	}

	AVL_Tree &clear()
	{
		clear(root);
		root = NULL;
		return *this;
	}

  private:
	AVL_Tree_Node<T> *root;
	int _size;

	void clear(AVL_Tree_Node<T> *node)
	{
		if (node == NULL)
			return;
		clear(node->left_child);
		clear(code->right_child);
		delete node;
	}
};

#endif