#ifndef FUNCTIONAL_HPP
#define FUNCTIONAL_HPP

template <class T>
struct Less
{
	bool operator()(const T &a, const T &b) const { return a < b; }
};

template <class T>
struct Greater
{
	bool operator()(const T &a, const T &b) const { return a > b; }
};

#endif