#ifndef STRING_HPP
#define STRING_HPP

#include <iostream>
#include <cstring>

class String
{
  public:
	String(const char *s = "") : _size(strlen(s)), _capacity(8)
	{
		if (_capacity <= _size)
			do
			{
				_capacity *= 2;
			} while (_capacity <= _size);
		p = new char[_capacity];
		strcpy(p, s);
	}
	String(char c) : _size(0), _capacity(8)
	{
		p = new char[_capacity];
		push_back(c);
	}
	String(const String &s) : _size(s._size), _capacity(s._capacity)
	{
		p = new char[_capacity];
		strcpy(p, s.p);
	}

	~String() { delete[] p; }

	String &push_back(char c)
	{
		if (_size + 1 >= _capacity)
			double_capacity();
		p[_size++] = c;
		p[_size] = 0;
		return *this;
	}
	String &pop_back()
	{
		if (_size > 0)
			p[--_size] = 0;
		return *this;
	}

	String &insert(int pos, char value)
	{
		if (pos <= _size)
		{
			if (_size + 1 == _capacity)
				double_capacity();
			for (int i = _size + 1; i > pos; --i)
				p[_size] = p[_size - 1];
			p[pos] = value;
			_size++;
		}
		return *this;
	}
	String &erase(int pos)
	{
		if (_size > 0)
		{
			_size--;
			for (int i = pos; i <= _size; ++i)
				p[i] = p[i + 1];
		}
		return *this;
	}

	String substr(int pos, int count = npos) const
	{
		if (count == -1 && pos + count > _size)
			count = _size - pos;
		else if (count < pos)
			return "";
		char *np = new char[count];
		strncpy(np, p + pos, count);
		String s(np);
		delete[] np;
		return s;
	}

	int copy(char *np, int pos, int count = npos) const
	{
		String s = substr(pos, count);
		strcpy(np, s);
		return s._size;
	}

	int find(const String &s) const
	{
		int i = 0;
		do
		{
			for (int j = 0; j < s._size; ++j)
				if (p[i + j] != s.p[j])
					continue;
			return i;
		} while (++i);
		return npos;
	}

	char front() { return p[0]; }
	char back() { return p[_size - 1]; }

	char *data() { return p; }
	char *c_str() const { return p; }

	int size() const { return _size; }
	bool empty() const { return !_size; }
	int capacity() const { return _capacity; }

	String &clear()
	{
		p[_size] = _size = 0;
		return *this;
	}

	String &shrink_to_fit()
	{
		_capacity = 8;
		if (_capacity <= _size)
		{
			do
			{
				_capacity *= 2;
			} while (_capacity <= _size);
			char *np = new char[_capacity];
			strcpy(np, p);
			delete[] p;
			p = np;
		}
		return *this;
	}

	int compare(const String &s) const { return strcmp(p, s.p); }

	operator char *() { return p; }

	bool operator==(const String &s) const { return compare(s) == 0; }
	bool operator!=(const String &s) const { return compare(s) != 0; }
	bool operator<(const String &s) const { return compare(s) < 0; }
	bool operator>(const String &s) const { return compare(s) > 0; }
	bool operator<=(const String &s) const { return compare(s) <= 0; }
	bool operator>=(const String &s) const { return compare(s) >= 0; }

	char operator[](int pos) { return p[pos]; }

	String operator+(const String &s) const
	{
		char *np = new char[_size + s._size + 1];
		strcpy(np, p);
		strcat(np, s.p);
		String ns(np);
		delete[] np;
		return ns;
	}
	String &operator=(const String &s)
	{
		if (_capacity <= s._size)
		{
			do
			{
				_capacity *= 2;
			} while (_capacity <= s._size);
			delete[] p;
			p = new char[_capacity];
		}
		strcpy(p, s.p);
		return *this;
	}
	String &operator+=(const String &s)
	{
		if (_capacity <= _size + s._size)
		{
			do
			{
				_capacity *= 2;
			} while (_capacity <= _size + s._size);
			char *np = new char[_capacity];
			strcpy(np, p);
			delete[] p;
			p = np;
		}
		strcat(p, s.p);
		return *this;
	}

	friend std::istream &operator>>(std::istream &in, String &s)
	{
		s._size = 0;
		char t;
		while (in.get(t))
			if (t != ' ' && t != '\t' && t != '\n')
				break;
		do
		{
			if (t == ' ' || t == '\t' || t == '\n')
				break;
			s.push_back(t);
		} while (in.get(t));
		return in;
	}
	friend std::ostream &operator<<(std::ostream &out, const String &s)
	{
		out << s.p;
		return out;
	}
	friend std::istream &getline(std::istream &in, String &s)
	{
		s._size = 0;
		char t;
		while (in.get(t))
			if (t != '\n')
				break;
		do
		{
			if (t == '\n')
				break;
			s.push_back(t);
		} while (in.get(t));
		return in;
	}

  private:
	int _size;
	int _capacity;
	char *p;

	static const int npos = -1;

	String &double_capacity()
	{
		char *np = new char[_capacity *= 2];
		strcpy(np, p);
		delete[] p;
		p = np;
		return *this;
	}
};

#endif

// 数值转换
// stoi
// stol
// stoll  (C++11)
// 转换字符串为有符号整数
// stoul
// stoull  (C++11)
// 转换字符串为无符号整数
// stof
// stod
// stold  (C++11)
// 转换字符串为浮点值
// to_string  (C++11)
// 转换整数或浮点值为 string
// to_wstring  (C++11)
// 转换整数或浮点值为 wstring

// 迭代器
// begin
// cbegin
// 返回指向起始的迭代器
// end
// cend
// 返回指向末尾的迭代器
// rbegin
// crbegin
// 返回指向起始的逆向迭代器
// rend
// crend
// 返回指向末尾的逆向迭代器