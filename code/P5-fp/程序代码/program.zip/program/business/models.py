from django.db import models


# Create your models here.
class Business(models.Model):
    username = models.CharField(max_length=32, verbose_name='用户名')
    password = models.CharField(max_length=32, verbose_name='密码')
    name = models.CharField(max_length=20, verbose_name='商户名称', null=True)
    phone = models.CharField(max_length=11, verbose_name='联系电话', null=True)
    addr = models.CharField(max_length=256, verbose_name='地址', null=True)

    class Meta:
        db_table = 'business'
        verbose_name = '商户账户管理'
        verbose_name_plural = verbose_name

    def __str__(self):
        return self.username


class BusinessOrder(models.Model):
    order = models.ForeignKey('user.Order', verbose_name='订单', on_delete=models.CASCADE)
    business = models.ForeignKey('Business', verbose_name='接单商户', on_delete=models.CASCADE)
    create = models.DateTimeField(auto_now_add=True, verbose_name='接单时间')
    confirm = models.DateTimeField(null=True, blank=True, verbose_name='确认收货时间')
    delivery = models.BooleanField(verbose_name='是否有取货人接单', default=False)


    class Meta:
        db_table = 'business_order'
        verbose_name = '商户订单管理'
        verbose_name_plural = verbose_name
