from django.shortcuts import render, redirect
from django.views.generic import View
from user.models import *
from delivery.models import *
from business.models import *
from datetime import datetime


# Create your views here.
def index(request):
    return redirect('/business/orderlist/')


# 注册
def register(request):
    if request.method == 'GET':
        # 显示注册页面
        return render(request, 'business/login_register.html')
    elif request.method == 'POST':
        # 进行注册处理
        # 接收数据
        username = request.POST.get('username')
        password = request.POST.get('pwd')
        cpassword = request.POST.get('cpwd')
        # 校验用户名是否重复
        try:
            user = Business.objects.get(username=username)
        except:
            # 用户名不存在
            user = None
        if user:
            # 用户名已存在
            return render(request, 'business/login_register.html', {'reg_errmsg': '用户名已存在'})
        if password != cpassword:
            return render(request, 'business/login_register.html', {'reg_errmsg': '两次输入的密码不一致'})
        # 校验数据
        if not all([username, password]):
            return render(request, 'business/login_register.html', {'reg_errmsg': '请将必填项填写完整'})

        # 进行业务处理: 进行用户注册
        Business.objects.create(username=username, password=password, name=username)
        # 返回应答, 跳转到登录页面
        return redirect('/business/login/')


# 登录
def login_(request):
    if request.method == 'GET':
        return render(request, 'business/login_register.html')
    elif request.method == 'POST':
        # 接收数据
        username = request.POST.get('username')
        password = request.POST.get('pwd')
        # 校验数据
        if not all([username, password]):
            return render(request, 'business/login_register.html', {'login_errmsg': '请将必填项填写完整'})
        # 业务处理:登录校验
        user = Business.objects.filter(username=username, password=password)
        if user.exists():
            # 用户名密码正确记录用户的登录状态
            request.session['bid'] = user.first().id
            request.session['bname'] = user.first().username
            return redirect('/business/')
        else:
            # 用户名或密码错误
            return render(request, 'business/login_register.html', {'login_errmsg': '用户名或密码错误'})


# 退出登录
def logout_(request):
    # 清除用户的session信息
    del request.session['bid']
    del request.session['bname']
    # 跳转到首页
    return redirect('/business/')


def orderlist(request):
    user = request.session.get('bid', None)
    if not user:
        # 返回应答, 跳转到登录页面
        return redirect('/business/login/')
    lists = Order.objects.filter(status='等待接单')
    return render(request, 'business/orderlist.html', locals())


def pickup(request, id):
    user = request.session.get('bid', None)
    if not user:
        # 返回应答, 跳转到登录页面
        return redirect('/business/login/')
    if request.method == 'GET':
        id = id
        info = Order.objects.get(id=id)
        return render(request, 'business/pickup.html', locals())
    if request.method == 'POST':
        price = request.POST.get('price')
        Order.objects.filter(id=id).update(price=price, status='商家已接单')
        BusinessOrder.objects.create(order_id=id, business_id=user)
        Status.objects.create(order_id=id, name='商家[' + request.session.get('bname', None) + ']已接单')
    return redirect('/business/order/')


def order(request):
    user = request.session.get('bid', None)
    if not user:
        # 返回应答, 跳转到登录页面
        return redirect('/business/login/')
    lists = BusinessOrder.objects.filter(business_id=user)
    return render(request, 'business/order.html', locals())


def confirm(request, id):
    if request.method == 'GET':
        b = BusinessOrder.objects.get(id=id)
        info = b.order
        id = id
        return render(request, 'business/confirm.html', locals())
    if request.method == 'POST':
        b = BusinessOrder.objects.get(id=id)
        # if order
        Order.objects.filter(id=b.order_id).update(status='已完成')
        b.confirm=datetime.now()
        b.save()
        Status.objects.create(order_id=b.order_id, name='商家已付款')
        Status.objects.create(order_id=b.order_id, name='订单已完成')
        return redirect('/business/order/')


def order_detail(request, id):
    user = request.session.get('bid', None)
    if not user:
        # 返回应答, 跳转到登录页面
        return redirect('/business/login/')
    info = Order.objects.get(id=id)
    status = Status.objects.filter(order=info)

    try:
        b = BusinessOrder.objects.get(order_id=id)
        d = DeliveryOrder.objects.get(order__order_id=id)
    except:
        pass
    return render(request, 'business/order_detail.html', locals())


def review(request):
    user = request.session.get('bid', None)
    if not user:
        # 返回应答, 跳转到登录页面
        return redirect('/business/login/')
    lists = BusinessOrder.objects.filter(business_id=user,order__comment_b__isnull=False)
    return render(request, 'business/review.html', locals())

def my(request):
    '''个人中心'''
    user = request.session.get('bid', None)
    if not user:
        # 返回应答, 跳转到登录页面
        return redirect('/business/login/')
    if request.method == 'GET':
        s = Business.objects.get(id=user)
        return render(request, 'business/my.html', locals())
    else:
        # 获取修改数据
        name = request.POST.get('name')
        phone = request.POST.get('phone')
        addr = request.POST.get('addr')
        # 修改当前用户信息
        Business.objects.filter(id=user).update(name=name, phone=phone, addr=addr)
        # 查询当前用户信息
        info = Business.objects.get(id=user)
        errmsg = '修改成功'
        return render(request, 'business/my.html', {'s': info, 'errmsg': errmsg})
