from django.urls import path
from business.views import *

urlpatterns = [
    path('', index),
    path('register/', register),  # 注册
    path('login/', login_),  # 登录
    path('logout/', logout_),  # 登出
    path('pickup/<int:id>/', pickup),  # 接单
    path('orderlist/', orderlist),  # 订单列表
    path('order/', order),  # 我的订单
    path('order/confirm/<int:id>/', confirm),  # 确认收货
    path('order/detail/<int:id>/', order_detail),  # 订单
    path('review/', review),  # review
    path('my/', my),  # 用户中心
]
