from django.apps import AppConfig


class BusinessConfig(AppConfig):
    name = 'business'
    verbose_name = '商户管理'
