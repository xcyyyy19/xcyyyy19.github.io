from django.contrib import admin
from business.models import *

# Register your models here.
class userAdmin(admin.ModelAdmin):
    list_display = ['id', 'username', 'password', 'name', 'phone','addr']
    list_display_links = ['id',  'username', 'password', 'name', 'phone','addr']
    search_fields = ['username', 'password', 'name', 'phone','addr']


class reviewAdmin(admin.ModelAdmin):
    list_display = ['id', 'order', 'business', 'create', 'confirm','delivery']
    list_display_links = ['id', 'order', 'business', 'create', 'confirm','delivery']
    search_fields = ['order__id', 'business__name']

admin.site.register(Business, userAdmin)
admin.site.register(BusinessOrder, reviewAdmin)