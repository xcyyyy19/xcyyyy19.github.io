from django.db import models
from django.contrib.auth.models import AbstractUser


class User(models.Model):
    username = models.CharField(max_length=32, verbose_name='用户名')
    password = models.CharField(max_length=32, verbose_name='密码')
    name = models.CharField(max_length=20, verbose_name='用户姓名', null=True,default='')
    phone = models.CharField(max_length=11, verbose_name='联系电话', null=True,default='')
    addr = models.CharField(max_length=256, verbose_name='地址', null=True,default='')

    class Meta:
        db_table = 'user'
        verbose_name = '用户账户管理'
        verbose_name_plural = verbose_name

    def __str__(self):
        return self.username


# class Admin(AbstractUser, models.Model):
#     # 扩展系统自带的User
#
#     class Meta:
#         db_table = 'admin'
#         verbose_name = '管理员管理'
#         verbose_name_plural = verbose_name


# 废品分类：id 分类
class Type(models.Model):
    name = models.CharField(max_length=20, verbose_name='类别名称')

    class Meta:
        db_table = 'type'
        verbose_name = '废品分类'
        verbose_name_plural = verbose_name

    def __str__(self):
        return self.name

class Status(models.Model):
    order = models.ForeignKey('Order', related_name='o',verbose_name='订单', on_delete=models.CASCADE)
    name = models.CharField(max_length=50, verbose_name='状态')
    create = models.DateTimeField(auto_now_add=True,verbose_name='下单时间')

    class Meta:
        db_table = 'status'
        verbose_name = '状态'
        verbose_name_plural = verbose_name


# 订单：用户id 商户ID 废品分类id 取件时间 状态 评价取货员 评价商户
class Order(models.Model):
    id = models.CharField(max_length=20, primary_key=True)  # 自增长类型
    user = models.ForeignKey('User', verbose_name='下单用户', on_delete=models.CASCADE)
    type = models.ForeignKey('Type', verbose_name='废品分类', on_delete=models.CASCADE)
    name = models.CharField(max_length=20, verbose_name='收件人')
    phone = models.CharField(max_length=11, verbose_name='联系电话')
    addr = models.CharField(max_length=256, verbose_name='收件地址')
    date = models.DateField(verbose_name='取件日期') 
    time = models.TimeField(verbose_name='取件时间') 
    heavy = models.IntegerField(default=1, verbose_name='重量（kg）')
    create = models.DateTimeField(auto_now_add=True, verbose_name='下单时间')
    detail = models.CharField(max_length=500, null=True, blank=True, verbose_name='备注')
    price = models.DecimalField(verbose_name='价格', max_digits=6, decimal_places=2, default=0)  # 班费余额
    comment_d = models.CharField(max_length=500, null=True, blank=True, verbose_name='评价取货员')
    comment_b = models.CharField(max_length=500, null=True, blank=True, verbose_name='评价商户')
    status = models.CharField(max_length=20, default='等待接单', verbose_name='当前状态')

    class Meta:
        db_table = 'order'
        verbose_name = '用户订单管理'
        verbose_name_plural = verbose_name
