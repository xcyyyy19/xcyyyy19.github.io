from django.contrib import admin
from user.models import *

# Register your models here.   （ModelAdmin模型管理器类）
class typeAdmin(admin.ModelAdmin):
    list_display = ['id', 'name']  # 列表显示哪些字段
    list_display_links = ['id', 'name']  # 控制list_display中的字段，可链接到修改页
    search_fields = ['name']   # 添加搜索框

class userAdmin(admin.ModelAdmin):
    list_display = ['id', 'username', 'password', 'name', 'phone', 'addr']
    list_display_links = ['id',  'username', 'password', 'name', 'phone', 'addr']
    search_fields = ['username', 'password', 'name', 'phone', 'addr']

class reviewAdmin(admin.ModelAdmin):
    list_display = ['id', 'user', 'type', 'date', 'time']
    list_display_links = ['id', 'user', 'type', 'date', 'time']
    search_fields = ['user__name', 'type__name']

admin.site.register(Type, typeAdmin)
admin.site.register(User, userAdmin)
admin.site.register(Order, reviewAdmin)