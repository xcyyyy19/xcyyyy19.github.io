from django.urls import path
from user.views import *

urlpatterns = [
    path('', index),
    path('register/', register),  # 注册
    path('login/', login_),  # 登录
    path('logout/', logout_),  # 登出
    path('order/insert/', order_insert),  # 下单
    path('order/', order),  # 我的订单
    path('order/detail/<int:id>/', order_detail),  # 订单
    path('my/', my),  # 用户中心
    path('order/<int:type>/<int:id>/', order_detail),  # 订单
    path('review/<str:type>/<int:id>/', review),  # 订单

    # path('update/', UserUpdateView.as_view()),  # 用户信息修改
    # path('update/password/', UserPwdUpdateView.as_view()),  # 用户密码修改
]