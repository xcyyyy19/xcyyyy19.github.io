from django.shortcuts import render, redirect
from django.views.generic import View
from user.models import *
from delivery.models import *
from business.models import *
from datetime import datetime
import os


# Create your views here.
def index(request):
    return render(request, 'user/index.html', locals())


# 注册
def register(request):
    if request.method == 'GET':
        # 显示注册页面
        return render(request, 'user/login_register.html')
    elif request.method == 'POST':
        # 进行注册处理
        # 接收数据
        username = request.POST.get('username')
        password = request.POST.get('pwd')
        cpassword = request.POST.get('cpwd')
        # 校验用户名是否重复
        try:
            user = User.objects.get(username=username)
        except User.DoesNotExist:
            # 用户名不存在
            user = None
        if user:
            # 用户名已存在
            return render(request, 'user/login_register.html', {'reg_errmsg': '用户名已存在'})
        if password != cpassword:
            return render(request, 'user/login_register.html', {'reg_errmsg': '两次输入的密码不一致'})
        # 校验数据
        if not all([username, password]):
            return render(request, 'user/login_register.html', {'reg_errmsg': '请将必填项填写完整'})

        # 进行业务处理: 进行用户注册
        User.objects.create(username=username, password=password, name=username)
        # 返回应答, 跳转到登录页面
        return redirect('/user/login/')


# 登录
def login_(request):
    if request.method == 'GET':
        return render(request, 'user/login_register.html')
    elif request.method == 'POST':
        # 接收数据
        username = request.POST.get('username')
        password = request.POST.get('pwd')
        # 校验数据
        if not all([username, password]):
            return render(request, 'user/login_register.html', {'login_errmsg': '请将必填项填写完整'})
        # 业务处理:登录校验
        user = User.objects.filter(username=username, password=password)
        if user.exists():
            # 用户名密码正确记录用户的登录状态
            request.session['uid'] = user.first().id
            request.session['uname'] = user.first().username
            return redirect('/user/')
        else:
            # 用户名或密码错误
            return render(request, 'user/login_register.html', {'login_errmsg': '用户名或密码错误'})


# 退出登录
def logout_(request):
    # 清除用户的session信息
    del request.session['uid']
    del request.session['uname']
    # 跳转到首页
    return redirect('/user/')


def order(request):
    user = request.session.get('uid', None)
    if not user:
        # 返回应答, 跳转到登录页面
        return redirect('/user/login/')
    lists = Order.objects.filter(user_id=user)
    return render(request, 'user/order.html', locals())


def order_insert(request):
    if request.method == 'GET':
        # 获取所有类型（页面需要选择废品类型）
        type_list = Type.objects.all()
        user = request.session.get('uid', None)
        if user:
            u = User.objects.get(id=user)
        return render(request, 'user/order_insert.html', locals())
    if request.method == 'POST':
        user = request.session.get('uid', None)
        if not user:
            # 返回应答, 跳转到登录页面
            return redirect('/user/login/')
        # 获取前台输入的数据
        type = request.POST.get('type')
        name = request.POST.get('name')
        phone = request.POST.get('phone')
        addr = request.POST.get('addr')

        date = request.POST.get('date')
        time = request.POST.get('time')
        heavy = request.POST.get('heavy')
        detail = request.POST.get('detail')
        # 订单id: 订单创建时间
        order_id = datetime.now().strftime('%Y%m%d%H%M%S')
        # 创建
        Order.objects.create(id=order_id, user_id=user, type_id=type, name=name, phone=phone, addr=addr, date=date,
                             time=time,
                             heavy=heavy, detail=detail)
        Status.objects.create(order_id=order_id, name='您的订单开始处理')
        return redirect('/user/order/')


def order_detail(request, id):
    user = request.session.get('uid', None)
    if not user:
        # 返回应答, 跳转到登录页面
        return redirect('/user/login/')
    info = Order.objects.get(id=id)
    try:
        b = BusinessOrder.objects.get(order_id=id)
        d = DeliveryOrder.objects.get(order__order_id=id)
    except:
        pass
    status = Status.objects.filter(order_id=id)
    return render(request, 'user/order_detail.html', locals())


def review(request, type, id):
    user = request.session.get('uid', None)
    if not user:
        # 返回应答, 跳转到登录页面
        return redirect('/user/login/')
    info = Order.objects.get(id=id)
    review = request.POST.get('review')
    if type == 'b':
        info.comment_b = review
    else:
        info.comment_d = review
    info.save()
    return redirect('/user/order/detail/'+str(id)+'/')


def my(request):
    '''个人中心'''
    user = request.session.get('uid', None)
    if not user:
        # 返回应答, 跳转到登录页面
        return redirect('/user/login/')
    if request.method == 'GET':
        s = User.objects.get(id=user)
        return render(request, 'user/my.html', locals())
    else:
        # 获取修改数据
        name = request.POST.get('name')
        phone = request.POST.get('phone')
        addr = request.POST.get('addr')
        # 修改当前用户信息
        User.objects.filter(id=user).update(name=name, phone=phone, addr=addr)
        # 查询当前用户信息
        info = User.objects.get(id=user)
        errmsg = '修改成功'
        return render(request, 'user/my.html', {'s': info, 'errmsg': errmsg})
