import pymysql
pymysql.install_as_MySQLdb()

# python3 manage.py makemigrations user
# python3 manage.py makemigrations business
# python3 manage.py makemigrations delivery
# python3 manage.py migrate