from django.contrib import admin
from delivery.models import *

# Register your models here.
class userAdmin(admin.ModelAdmin):
    list_display = ['id', 'username', 'password', 'name', 'phone']
    list_display_links = ['id',  'username', 'password', 'name', 'phone']
    search_fields = ['username', 'password', 'name', 'phone']


class reviewAdmin(admin.ModelAdmin):
    list_display = ['id', 'order', 'delivery', 'create', 'confirm']
    list_display_links = ['id', 'order', 'delivery', 'create', 'confirm']
    search_fields = ['order__order__id', 'delivery__name']


admin.site.register(Delivery, userAdmin)
admin.site.register(DeliveryOrder, reviewAdmin)