from django.shortcuts import render, redirect
from user.models import *
from delivery.models import *
from business.models import *
from datetime import datetime


# Create your views here.
def index(request):
    return redirect('/delivery/orderlist/')


# 注册
def register(request):
    if request.method == 'GET':
        # 显示注册页面
        return render(request, 'delivery/login_register.html')
    elif request.method == 'POST':
        # 进行注册处理
        # 接收数据
        username = request.POST.get('username')
        password = request.POST.get('pwd')
        cpassword = request.POST.get('cpwd')
        # 校验用户名是否重复
        try:
            user = Delivery.objects.get(username=username)
        except:
            # 用户名不存在
            user = None
        if user:
            # 用户名已存在
            return render(request, 'delivery/login_register.html', {'reg_errmsg': '用户名已存在'})
        if password != cpassword:
            return render(request, 'delivery/login_register.html', {'reg_errmsg': '两次输入的密码不一致'})
        # 校验数据
        if not all([username, password]):
            return render(request, 'delivery/login_register.html', {'reg_errmsg': '请将必填项填写完整'})

        # 进行业务处理: 进行用户注册
        Delivery.objects.create(username=username, password=password, name=username)
        # 返回应答, 跳转到登录页面
        return redirect('/delivery/login/')


# 登录
def login_(request):
    if request.method == 'GET':
        return render(request, 'delivery/login_register.html')
    elif request.method == 'POST':
        # 接收数据
        username = request.POST.get('username')
        password = request.POST.get('pwd')
        # 校验数据
        if not all([username, password]):
            return render(request, 'delivery/login_register.html', {'login_errmsg': '请将必填项填写完整'})
        # 业务处理:登录校验
        user = Delivery.objects.filter(username=username, password=password)
        if user.exists():
            # 用户名密码正确记录用户的登录状态
            request.session['did'] = user.first().id
            request.session['dname'] = user.first().username
            return redirect('/delivery/')
        else:
            # 用户名或密码错误
            return render(request, 'delivery/login_register.html', {'login_errmsg': '用户名或密码错误'})


# 退出登录
def logout_(request):
    # 清除用户的session信息
    del request.session['did']
    del request.session['dname']
    # 跳转到首页
    return redirect('/delivery/')


def orderlist(request):
    user = request.session.get('did', None)
    if not user:
        # 返回应答, 跳转到登录页面
        return redirect('/delivery/login/')
    lists = BusinessOrder.objects.filter(delivery=False)
    return render(request, 'delivery/orderlist.html', locals())


def pickup(request, id):
    user = request.session.get('did', None)
    if not user:
        # 返回应答, 跳转到登录页面
        return redirect('/delivery/login/')
    if request.method == 'GET':
        id = id
        info = BusinessOrder.objects.get(id=id)
        return render(request, 'delivery/pickup.html', locals())
    if request.method == 'POST':
        b = BusinessOrder.objects.get(id=id)
        b.delivery = True
        b.save()
        Order.objects.filter(id=b.order_id).update(status='取货员已接单')
        d = Delivery.objects.get(id=request.session.get('did', None))
        DeliveryOrder.objects.create(order_id=id, delivery=d)
        Status.objects.create(order_id=b.order_id, name='取货员 ' + d.name + '[' + str(d.phone) + '] 已接单')
        Status.objects.create(order_id=b.order_id, name='取货员 ' + d.name + '[' + str(d.phone) + '] 正赶往取货地点')
    return redirect('/delivery/order/')


def order(request):
    user = request.session.get('did', None)
    if not user:
        # 返回应答, 跳转到登录页面
        return redirect('/delivery/login/')
    lists = DeliveryOrder.objects.filter(delivery_id=user)
    return render(request, 'delivery/order.html', locals())


def arrive(request, id):
    d = DeliveryOrder.objects.get(id=id)
    Order.objects.filter(id=d.order.order_id).update(status='取货员已到达')
    Status.objects.create(order_id=d.order.order_id, name='取货员' + d.delivery.name + '[' + str(d.delivery.phone) + '] 已到达')
    return redirect('/delivery/order/')


def take(request, id):
    d = DeliveryOrder.objects.get(id=id)
    Order.objects.filter(id=d.order.order_id).update(status='取货员已取货')
    Status.objects.create(order_id=d.order.order_id, name='取货员已取货')
    Status.objects.create(order_id=d.order.order_id, name='取货员' + d.delivery.name + '[' + str(d.delivery.phone) + '] 正赶往送货地点')
    return redirect('/delivery/order/')


def confirm(request, id):
    d = DeliveryOrder.objects.get(id=id)
    d.confirm = datetime.now()
    d.save()
    Order.objects.filter(id=d.order.order_id).update(status='取货员已送达')
    Status.objects.create(order_id=d.order.order_id, name='取货员已送达')
    return redirect('/delivery/order/')


def order_detail(request, id):
    user = request.session.get('did', None)
    if not user:
        # 返回应答, 跳转到登录页面
        return redirect('/delivery/login/')
    info = Order.objects.get(id=id)
    status = Status.objects.filter(order=info)

    try:
        b = BusinessOrder.objects.get(order_id=id)
        d = DeliveryOrder.objects.get(order__order_id=id)
    except:
        pass
    return render(request, 'delivery/order_detail.html', locals())


def review(request):
    user = request.session.get('did', None)
    if not user:
        return redirect('/delivery/login/')
    lists = DeliveryOrder.objects.filter(delivery_id=user, order__order__comment_d__isnull=False)
    return render(request, 'delivery/review.html', locals())


def my(request):
    '''个人中心'''
    user = request.session.get('did', None)
    if not user:
        # 返回应答, 跳转到登录页面
        return redirect('/delivery/login/')
    if request.method == 'GET':
        s = Delivery.objects.get(id=user)
        return render(request, 'delivery/my.html', locals())
    else:
        # 获取修改数据
        name = request.POST.get('name')
        phone = request.POST.get('phone')
        # 修改当前用户信息
        Delivery.objects.filter(id=user).update(name=name, phone=phone)
        # 查询当前用户信息
        info = Delivery.objects.get(id=user)
        errmsg = '修改成功'
        return render(request, 'delivery/my.html', {'s': info, 'errmsg': errmsg})
