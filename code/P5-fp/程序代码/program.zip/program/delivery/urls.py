from django.urls import path
from delivery.views import *

urlpatterns = [
    path('', index),
    path('register/', register),  # 注册
    path('login/', login_),  # 登录
    path('logout/', logout_),  # 登出

    path('orderlist/', orderlist),  # 订单列表
    path('pickup/<int:id>/', pickup),  # 接单

    path('order/', order),  # 我的订单
    path('order/arrive/<int:id>/', arrive),  # 已到达取货地点
    path('order/take/<int:id>/', take),  # 已取货
    path('order/confirm/<int:id>/', confirm),  # 已送达
    path('order/detail/<int:id>/', order_detail),  # 订单

    path('review/', review),  # review
    path('my/', my),  # 用户中心
]
