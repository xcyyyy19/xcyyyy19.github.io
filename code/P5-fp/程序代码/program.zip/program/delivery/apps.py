from django.apps import AppConfig


class DeliveryConfig(AppConfig):
    name = 'delivery'
    verbose_name = '取货员管理'
