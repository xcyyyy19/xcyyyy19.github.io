from django.db import models


# Create your models here.
class Delivery(models.Model):
    username = models.CharField(max_length=32, verbose_name='用户名')
    password = models.CharField(max_length=32, verbose_name='密码')
    name = models.CharField(max_length=20, verbose_name='姓名', null=True)
    phone = models.CharField(max_length=11, verbose_name='联系电话', null=True)

    class Meta:
        db_table = 'delivery'
        verbose_name = '取货员账户管理'
        verbose_name_plural = verbose_name

    def __str__(self):
        return self.username


class DeliveryOrder(models.Model):
    order = models.ForeignKey('business.BusinessOrder', verbose_name='订单', on_delete=models.CASCADE)
    delivery = models.ForeignKey('Delivery',verbose_name='接单人', on_delete=models.CASCADE)
    create = models.DateTimeField(auto_now_add=True, verbose_name='接单时间')
    confirm = models.DateTimeField(null=True, blank=True, verbose_name='送达时间')

    class Meta:
        db_table = 'delivery_order'
        verbose_name = '取货员订单管理'
        verbose_name_plural = verbose_name