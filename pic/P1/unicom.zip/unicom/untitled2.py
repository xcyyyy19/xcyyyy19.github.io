# -*- coding: utf-8 -*-
"""
Created on Sat Mar  2 10:38:48 2019

@author: zzr
"""

a = input("请输入")
print(a)