# -*- coding: utf-8 -*-
"""
Created on Tue Nov 20 17:06:49 2018

@author: zzr
"""

# -*- coding: utf-8 -*-
"""
Created on Wed Nov 14 18:24:17 2018

@author: zzr
"""

import numpy as np
import pandas as pd
import time
import matplotlib.pyplot as plt
import seaborn as sns

from sklearn import preprocessing

import warnings
warnings.filterwarnings('ignore')

np.set_printoptions(precision=4, threshold=10000, linewidth=160, edgeitems=999, suppress=True)
pd.set_option('display.max_columns', None)
pd.set_option('display.max_rows', None)
pd.set_option('display.width', 160)
pd.set_option('expand_frame_repr', False)
pd.set_option('precision', 4)


def app_weight(x,res_list): 
    global df,dfa
    duoshou_power = 0
    tuiguang_power = 0
    zijin_power = 0
    freetime_power = 0
    
    a = dfa[(dfa.phoneID==x) & (dfa.prod_id_ot!='OTHER')].index.tolist()
    alen = len(a)
    #print(alen)
    for i in range(alen):
        app_idna = dfa.iloc[a[i]].ix['prod_id_ot']
        #tuiguang
        if ('WX' == app_idna) | ('KMUS' == app_idna) : 
            tuiguang_power += 1
            duoshou_power += 1                         
        #zijin
        elif ('GDMAP' == app_idna) | ('BDMAP' == app_idna) | ('TXMAP' == app_idna) : 
            zijin_power += 0.2
        elif ('CARF' == app_idna)  | ('ALBB' == app_idna) :
            zijin_power += 1
            duoshou_power += 0.5
        #freetime 
        elif ('TX_V' == app_idna) | ('KSHOU' == app_idna) | ('AIQY' == app_idna) |\
             ('MI_V' == app_idna) | ('YUKU' == app_idna): 
            freetime_power += 0.5
        #duoshou
        elif ('TAOBAO' == app_idna) | ('JD' == app_idna) | ('SUNING' == app_idna) :
            duoshou_power += 1
            zijin_power += 0.1
        elif ('ALIPAY' == app_idna) | ('MEIT' == app_idna) | ('DIANP' == app_idna) :
            duoshou_power += 2
            zijin_power += 0.1        
    
    #this phoneid res
    res_list[:] = []
    res_list.append(duoshou_power)
    res_list.append(tuiguang_power)
    res_list.append(zijin_power)
    res_list.append(freetime_power)



def pro_consume():
    global df,dfa
    rowlen = len(df.phoneID)
    #print(rowlen)
    p_list = []
    for i in range(rowlen):
        #df.loc[:,['phoneID']].ix[i]
        #print("proccessing:",i,df.phoneID.ix[i])       
        app_weight(df.phoneID.ix[i],p_list)
        #print("powerlist",p_list)
        df.duoshou.ix[i] += p_list[0]
        df.tuiguang.ix[i] += p_list[1]
        df.zijin.ix[i] += p_list[2]
        df.freetime.ix[i] += p_list[3]
    
        
        
if __name__ == '__main__':
    global df,dfa
    sum1 = 0
    df = pd.read_csv('unicom_4g.csv', header = 0)
    dfa = pd.read_csv('unicom_app_res1555743345.csv', header = 0)
    df['duoshou'] = 0
    df['tuiguang'] = 0
    df['zijin'] = 0
    df['freetime'] = 0
    #df['zijin'].describe()
    df.info()
    sns.set_style('whitegrid')
    colors = ["scarlet", "pinkish orange", "amber",
              "lime green", "cyan","blue violet","fuchsia"]
    sns.set(palette=sns.xkcd_palette(colors))
    
    pro_consume()
    '''
    newdf = df[['flux_num_Scaled','total_flux_Scaled']]
    newdf.info()
    sns.distplot(df['prod_id_ot'],hist=True,kde=False,rug=False)
    sns.jointplot(x='flux_num_Scaled', y='total_flux_Scaled', data=newdf, kind="kde")
    '''
    
    name = "./unicom_power_res" + str(int(time.time())) + ".csv"
    df.to_csv(name)

    