# -*- coding: utf-8 -*-
"""
Created on Fri Nov 23 16:28:05 2018

@author: zzr
"""
import time
class TimeTest(object):
    def __init__(self,hour,minute,second):
        self.hour = hour
        self.minute = minute
        self.second = second
    @staticmethod   
    def showTime():      
        return time.strftime("%H:%M:%S", time.localtime())
   
print (TimeTest.showTime())  
t = TimeTest(2,10,10)
nowTime = t.showTime()
print (nowTime)

