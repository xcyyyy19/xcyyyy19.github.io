# -*- coding: utf-8 -*-
"""
Created on 2019-3-1

@author: laozhou
"""
import numpy as np
import pandas as pd
import time
import matplotlib.pyplot as plt
import seaborn as sns
import random

from sklearn import preprocessing

def printscore(namelist,scorelist,pnum):
    print("===========================积分榜============================")
    for i in range(pnum):
        print("%d号%s>>>" % (i+1,namelist[i]),end='')
    print()
    for i in range(pnum):
        print("    %d分    " % (scorelist[i]),end='')
    print()
    return

if __name__ == '__main__':
    #pnum = 5
    namelist = []
    scorelist = []
    
    pnum = int(input("==请输入参赛队员人数==："))
   
    for i in range(pnum):
        namelist.append(input("==请输入参赛队员名字==："))
        scorelist.append(10)
    
    print("==共有以下队员报名参赛==：")
    print(namelist)
    temp=input("==下面由电脑随机为每位队员分配参赛号码==>>>>")
    random.shuffle(namelist)
    for i in range(pnum):
        print("%d号->%s" % (i+1,namelist[i]))
    printscore(namelist,scorelist,pnum)  
    while 1:
        nn,ss=map(int,input("请输入分数：号码 得分===").split())
        if 0 == nn:
            break
        scorelist[nn-1] += ss
        printscore(namelist,scorelist,pnum)
        
    
        
        