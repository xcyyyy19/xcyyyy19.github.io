# -*- coding: utf-8 -*-
"""
Created on Sun May 30 19:32:58 2021

@author: zzr
"""

import numpy as np
import pandas as pd
import time
import matplotlib.pyplot as plt
import seaborn as sns

if __name__ == '__main__':
    global df
    df = pd.read_csv('unicom_app.csv', header = 0)
    sns.set_style('whitegrid')
    plt.style.use({'figure.figsize':(7, 5)})
    colors = ["scarlet", "pinkish orange", "amber",
              "lime green", "cyan","blue violet","fuchsia"]
    #sns.set(palette=sns.xkcd_palette(colors))
    
    df.info()