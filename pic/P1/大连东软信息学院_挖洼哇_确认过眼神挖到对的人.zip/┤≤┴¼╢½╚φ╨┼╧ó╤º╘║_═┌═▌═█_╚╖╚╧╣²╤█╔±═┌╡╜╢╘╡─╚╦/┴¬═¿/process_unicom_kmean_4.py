# -*- coding: utf-8 -*-
"""
Created on Mon Nov 19 08:16:18 2018

@author: zzr
"""

import numpy as np
import pandas as pd
import time
import matplotlib.pyplot as plt
import seaborn as sns

from sklearn import preprocessing
from sklearn.cluster import KMeans
from sklearn import metrics

import warnings
warnings.filterwarnings('ignore')

np.set_printoptions(precision=4, threshold=10000, linewidth=160, edgeitems=999, suppress=True)
pd.set_option('display.max_columns', None)
pd.set_option('display.max_rows', None)
pd.set_option('display.width', 160)
pd.set_option('expand_frame_repr', False)
pd.set_option('precision', 6)

if __name__ == '__main__':
    sns.set_style('whitegrid')
    colors = ["scarlet", "pinkish orange", "amber",
              "lime green", "cyan","blue violet","fuchsia"]
    sns.set(palette=sns.xkcd_palette(colors))
    dft = pd.read_csv('unicom_res1542965499.csv', header = 0)
    dfc = dft[['sj','gw','zj','jj']]
    nc = 5
    model = KMeans(n_clusters = nc, n_jobs = 2, max_iter = 500,n_init=50)
    model.fit(dfc)
    
    print(metrics.silhouette_score(dfc,model.labels_,metric='euclidean'))
    r1 = pd.Series(model.labels_).value_counts()
    r2 = pd.DataFrame(model.cluster_centers_)
    #print(r2)
    r = pd.concat([r2, r1], axis = 1)
    r.columns = list(dfc.columns) + ['NUM_DFCLASS']  
    print(r)
    
    r3 = pd.concat([dfc,pd.Series(model.labels_, index = dfc.index)],axis=1)
    r3.columns = list(dfc.columns) + ['DFCLASS']
    #print(r3)
    
    plt.style.use('ggplot')
    
    labels = np.array(['sj','gw','zj','jj'])

    result = pd.concat([r2, r2.ix[:,0]], axis=1)

    n = len(labels)
    angle = np.linspace(0, 2 * np.pi, n, endpoint=False)
    angle = np.concatenate((angle, [angle[0]]))

    fig = plt.figure(figsize=(8,8))
    ax = fig.add_subplot(111, polar=True)    # 参数polar, 以极坐标的形式绘制图形
    kinds =['U1','U2','U3','U4','U5','U6','U7','U8','U9']

    for i in range(nc):
        ax.plot(angle, result.ix[i,:], linewidth=2, label=kinds[i])
        # ax.fill(angle, centers[i])  # 填充底色

    ax.set_thetagrids(angle * 180 / np.pi, labels)
    plt.title('different kind')
    plt.legend(loc='lower right')
    plt.show()

    
    