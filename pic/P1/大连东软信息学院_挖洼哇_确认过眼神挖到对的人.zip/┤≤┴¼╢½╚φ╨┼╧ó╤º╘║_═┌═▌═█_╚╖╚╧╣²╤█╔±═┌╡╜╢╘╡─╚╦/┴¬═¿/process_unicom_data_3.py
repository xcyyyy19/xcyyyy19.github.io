# -*- coding: utf-8 -*-
"""
Created on Wed Nov 14 18:24:17 2018

@author: zzr
"""

import numpy as np
import pandas as pd
import time
import matplotlib.pyplot as plt
import seaborn as sns

from sklearn import preprocessing

import warnings
warnings.filterwarnings('ignore')

np.set_printoptions(precision=4, threshold=10000, linewidth=160, edgeitems=999, suppress=True)
pd.set_option('display.max_columns', None)
pd.set_option('display.max_rows', None)
pd.set_option('display.width', 160)
pd.set_option('expand_frame_repr', False)
pd.set_option('precision', 4)


    
def pro_free_time2():
    global df
    scaler = preprocessing.MinMaxScaler()
    df['sj2'] = scaler.fit_transform(df['freetime'].values.reshape(-1, 1))
    #sns.distplot(df['freetime_Scaled'],hist=True,kde=True,rug=True)
    #df['freetime'].describe()
    
def pro_free_time1():
    global df
    #flux_num
    #25%       139.0000
    #50%       228.0000
    #75%       366.0000
    #total_dura
    #25%       93478.0000
    #50%      160193.0000
    #75%      241409.0000
    meanxi = (93478/139+160193/228+241409/366)/3
    #print(meanxi)
    df['ft'] = df.apply(lambda x: x['flux_num']*meanxi + x['total_dura'], axis=1)
    #df['ft_bin'] = pd.qcut(df.ft, 10)
    #df['ft_bin_id'] = pd.factorize(df.ft_bin)[0]+1
    df['ft_bin_id'] = df.ft.map(lambda x:9.9707e+05 if x > 9.8707e+05 else x)
    scaler = preprocessing.MinMaxScaler()
    df['sj1'] = scaler.fit_transform(df['ft_bin_id'].values.reshape(-1, 1))

def pro_free_time():
    global df
    pro_free_time1()
    pro_free_time2()
    df['sj'] = df.apply(lambda x: (x['sj1'] + x['sj2'])*0.5, axis=1)
    
def downiszero(x):
    if x == 0:
        return 0.1
    return x

def pro_communication1():
    global df
    df['down_flux'] = df['down_flux'].map( lambda x: downiszero(x))
    df['updo_rat'] = df.apply(lambda x: x['up_flux'] * x['up_flux'] / x['down_flux'], axis=1)
    df.updo_rat[df.updo_rat.isnull()] = 0
    df['updo_rat_bin'] = pd.qcut(df.updo_rat, 10)
    df['updo_rat_bin_id'] = pd.factorize(df.updo_rat_bin)[0]+1
    #df['updo_rat_bin_id'] = df.updo_rat.map(lambda x:15 if x > 15 else x)
    scaler = preprocessing.MinMaxScaler()
    df['jj1'] = scaler.fit_transform(df['updo_rat_bin_id'].values.reshape(-1, 1))

def pro_communication2():
    global df
    scaler = preprocessing.MinMaxScaler()
    df['jj2'] = scaler.fit_transform(df['tuiguang'].values.reshape(-1, 1))
    #sns.distplot(df['tuiguang_Scaled'],hist=True,kde=True,rug=True)
    #df['tuiguang'].describe()
    
def pro_communication():
    global df
    pro_communication1()
    pro_communication2()
    df['jj'] = df.apply(lambda x: (x['jj1'] + x['jj2'])*0.5, axis=1)
    
def pro_total_flux():
    global df
    df['total_flux_bin'] = pd.qcut(df.total_flux, 10)
    df['total_flux_bin_id'] = pd.factorize(df.total_flux_bin)[0]+1
    scaler = preprocessing.MinMaxScaler()
    df['tf'] = scaler.fit_transform(df['total_flux_bin_id'].values.reshape(-1, 1))
    #sns.distplot(df['total_flux_Scaled'],hist=True,kde=True,rug=True)
    #df['total_flux'].describe()

def pro_money():
    global df
    pro_total_flux()
    df['zjt'] = df.apply(lambda x: x['tf'] + x['zijin'], axis=1)
    scaler = preprocessing.MinMaxScaler()
    df['zj'] = scaler.fit_transform(df['zjt'].values.reshape(-1, 1))
    #sns.distplot(df['duoshou_Scaled'],hist=True,kde=False,rug=False)
    #df['zijin'].describe()
    

def pro_desire():
    global df
    scaler = preprocessing.MinMaxScaler()
    df['gw'] = scaler.fit_transform(df['duoshou'].values.reshape(-1, 1))
    
    #sns.distplot(df['duoshou_Scaled'],hist=True,kde=True,rug=True)
    #df['duoshou'].describe()
    


pro_list_ch = ['WX','GDMAP','TAOBAO','TX_V','OPPO','BDMAP','TXMAP',
                   'KSHOU','MISPORT','TXNEWS','360','MI_V','WIFI',
                   'JD','ALIPAY','MEIT','DIANP','SUNING','AIQY',
                   'KMUS','CARF','ALBB','YUKU']

        
if __name__ == '__main__':
    global df
    df = pd.read_csv('unicom_power_res1542965367.csv', header = 0)
    print("process unicom")
    sns.set_style('whitegrid')
    colors = ["scarlet", "pinkish orange", "amber",
              "lime green", "cyan","blue violet","fuchsia"]
    sns.set(palette=sns.xkcd_palette(colors))
    
    pro_free_time()
    pro_communication()
    pro_money()
    pro_desire()
    
    '''
    newdf = df[['flux_num_Scaled','total_flux_Scaled']]
    newdf.info()
    sns.jointplot(x='flux_num_Scaled', y='total_flux_Scaled', data=newdf, kind="kde")
    '''
    
    name = "./unicom_res" + str(int(time.time())) + ".csv"
    df.to_csv(name)

    