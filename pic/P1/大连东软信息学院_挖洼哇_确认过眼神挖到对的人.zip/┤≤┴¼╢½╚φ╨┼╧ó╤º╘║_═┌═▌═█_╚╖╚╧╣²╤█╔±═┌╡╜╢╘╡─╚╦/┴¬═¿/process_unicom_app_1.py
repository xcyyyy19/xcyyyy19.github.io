# -*- coding: utf-8 -*-
"""
Created on Thu Nov 15 22:39:22 2018

@author: zzr
"""
import numpy as np
import pandas as pd
import time
import matplotlib.pyplot as plt
import seaborn as sns

from sklearn import preprocessing

import warnings
warnings.filterwarnings('ignore')

np.set_printoptions(precision=4, threshold=10000, linewidth=160, edgeitems=999, suppress=True)
pd.set_option('display.max_columns', None)
pd.set_option('display.max_rows', None)
pd.set_option('display.width', 160)
pd.set_option('expand_frame_repr', False)
pd.set_option('precision', 4)

protop_list = ['C1004','C545','C874','C946','C298','C1223','C4453',
                   'C274','C66690','C950','C18','C84357','C5348',
                   'C632','C1167','C742','C483','C923','C370',
                   'C52215','C807','C374','C1107']
protop_list_ch = ['WX','GDMAP','TAOBAO','TX_V','OPPO','BDMAP','TXMAP',
                   'KSHOU','MISPORT','TXNEWS','360','MI_V','WIFI',
                   'JD','ALIPAY','MEIT','DIANP','SUNING','AIQY',
                   'KMUS','CARF','ALBB','YUKU']

def istopin(x): 
    if x in protop_list:
        res = protop_list.index(x)
        return protop_list_ch[res]
    else:
        return 'OTHER'
    
if __name__ == '__main__':
    global df
    df = pd.read_csv('unicom_app.csv', header = 0)
    sns.set_style('whitegrid')
    plt.style.use({'figure.figsize':(7, 5)})
    colors = ["scarlet", "pinkish orange", "amber",
              "lime green", "cyan","blue violet","fuchsia"]
    #sns.set(palette=sns.xkcd_palette(colors))
    
    df.info()
    #print(df['prod_id'].value_counts())
    
    df['prod_id_ot'] = df['prod_id'].map( lambda x : istopin(x))
    
    print(df['prod_id_ot'].value_counts())
    sns.countplot(df['prod_id_ot'])
    #sns.distplot(df['prod_id_ot'],hist=True,kde=False,rug=False)
    name = "./unicom_app_res" + str(int(time.time())) + ".csv"
    df.to_csv(name)
    