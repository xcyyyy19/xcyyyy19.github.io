# -*- coding: utf-8 -*-
"""
Created on Tue Nov 20 20:01:41 2018

@author: zzr
"""

import numpy as np
import pandas as pd
import time
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn import metrics   
from sklearn.datasets.samples_generator import make_blobs   
from sklearn.preprocessing import StandardScaler  

from sklearn.cluster import DBSCAN

import warnings
warnings.filterwarnings('ignore')

np.set_printoptions(precision=4, threshold=10000, linewidth=160, edgeitems=999, suppress=True)
pd.set_option('display.max_columns', None)
pd.set_option('display.max_rows', None)
pd.set_option('display.width', 160)
pd.set_option('expand_frame_repr', False)
pd.set_option('precision', 4)

        
if __name__ == '__main__':
    global xp
    dft = pd.read_csv('unipay_power_res1542933946.csv', header = 0)
    X = dft[['gw1','gw2','zj1','zj2','zc1','zc2','jj1','jj2']]
    # 训练DBSCAN   
    # 调用密度聚类  DBSCAN
    db = DBSCAN(eps=0.3, min_samples=60).fit(X)
    # db.labels_为所有样本的聚类索引，没有聚类索引为-1
    #print(db.core_sample_indices_) # 所有核心样本的索引
    core_samples_mask = np.zeros_like(db.labels_, dtype=bool)  # 设置一个样本个数长度的全false向量
    core_samples_mask[db.core_sample_indices_] = True #将核心样本部分设置为true
    labels = db.labels_
    # 获取聚类个数。（聚类结果中-1表示没有聚类为离散点）
    n_clusters_ = len(set(labels)) - (1 if -1 in labels else 0)
    
    #print(labels)
    L1 = pd.Series(labels)
    xp = pd.concat([X, L1], axis = 1)
    xp.columns = list(X.columns) + ['DFCLASS']  
    xp.info()
    dflist = []
    for i in range(n_clusters_):
        dflist.append(xp[xp['DFCLASS']==i])
    dflist.append(xp[xp['DFCLASS']==-1])
    #r2 = np.zeros((n_clusters_,8), float)
    r0 = pd.concat([dflist[0].mean(), dflist[1].mean(), dflist[2].mean(),
                    dflist[3].mean(),dflist[4].mean()], axis = 1)
    r2 = pd.DataFrame(r0.T)
    del r2['DFCLASS']
    #print(xp['DFCLASS'].value_counts())
    print(r2)
    plt.style.use('ggplot')
    
    Tlabels = np.array(['gw1','gw2','zj1','zj2','jj1','jj2','zc1','zc2'])

    result = pd.concat([r2, r2.ix[:,0]], axis=1)

    n = len(Tlabels)
    angle = np.linspace(0, 2 * np.pi, n, endpoint=False)
    angle = np.concatenate((angle, [angle[0]]))

    fig = plt.figure(figsize=(8,8))
    ax = fig.add_subplot(111, polar=True)    
    kinds =['U1','U2','U3','U4','U5','U6','U7','U8','U9']

    for i in range(n_clusters_+1):
        ax.plot(angle, result.ix[i,:], linewidth=2, label=kinds[i])

    ax.set_thetagrids(angle * 180 / np.pi, Tlabels)
    ax.set_title("银联用户DBSCAN聚类", va='bottom', fontproperties="SimHei")
    plt.legend(loc='lower right')
    plt.show()
    
