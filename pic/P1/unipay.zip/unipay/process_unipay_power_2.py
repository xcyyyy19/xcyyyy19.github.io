# -*- coding: utf-8 -*-
"""
Created on Thu Nov 22 21:52:24 2018

@author: zzr
"""

import numpy as np
import pandas as pd
import time
import matplotlib.pyplot as plt
import seaborn as sns
import math
from sklearn import preprocessing

import warnings
warnings.filterwarnings('ignore')

np.set_printoptions(precision=4, threshold=10000, linewidth=160, edgeitems=999, suppress=True)
pd.set_option('display.max_columns', None)
pd.set_option('display.max_rows', None)
pd.set_option('display.width', 160)
pd.set_option('expand_frame_repr', False)
pd.set_option('precision', 4)

goutong_list = ['就餐场所和餐馆','住宿服务（旅馆、酒店、汽车旅馆、度假村等）',
                '成人成衣店','运动服饰商店','保健及美容SPA',
                '商业体育场馆、职业体育俱乐部、运动场和体育推广公司',
                '妇女成衣商店','各类服装及饰物店','化妆品商店',
                '饮酒场所（酒吧、酒馆、夜总会、鸡尾酒大厅、迪斯科舞厅）',
                '按摩店','旅行社','歌舞厅','体育用品店','机场服务']

def pro_v15_v28():
    global df,dfa
    dfa['v15_s'] = dfa.v15.map(lambda x:8.8 if x > 8.8 else x)
    dfa['v28_s'] = dfa.v28.map(lambda x:7.7 if x > 7.7 else x)
    scaler = preprocessing.MinMaxScaler()
    dfa['gw1'] = scaler.fit_transform(dfa['v15_s'].values.reshape(-1, 1))
    dfa['gw2'] = scaler.fit_transform(dfa['v28_s'].values.reshape(-1, 1))

def pro_v4_v18():
    global df,dfa
    
    dfa['v18_s'] = dfa.v18.map(lambda x:2.9930e+04 if x > 2.9930e+04 else x)
    scaler = preprocessing.MinMaxScaler()
    dfa['zj1'] = scaler.fit_transform(dfa['v4_s'].values.reshape(-1, 1))
    dfa['zj2'] = scaler.fit_transform(dfa['v18_s'].values.reshape(-1, 1))  

def pro_goutong_chengshi():
    global df,dfa
    scaler = preprocessing.MinMaxScaler()
    dfa['jj1'] = scaler.fit_transform(dfa['goutong'].values.reshape(-1, 1))
    dfa['jj2'] = scaler.fit_transform(dfa['chengshi'].values.reshape(-1, 1))  

def pro_quanmian_v28_v21():
    global df,dfa
    dfa['vc'] = dfa.apply(lambda x: x['v28'] - x['v21'], axis=1)
    scaler = preprocessing.MinMaxScaler()
    dfa['zc1'] = scaler.fit_transform(dfa['vc'].values.reshape(-1, 1))
    dfa['zc2'] = scaler.fit_transform(dfa['quanmian'].values.reshape(-1, 1))
    #sns.jointplot(x='zc1', y='zc2', data=dfa, kind="kde")
   
    
def goutong_weight(i):
    global df,dfa
    goutongfen = 0
    if df.iloc[i].ix['v67'] in goutong_list:
        goutongfen+=1
    if df.iloc[i].ix['v69'] in goutong_list:
        goutongfen+=1
    if df.iloc[i].ix['v71'] in goutong_list:
        goutongfen+=1
    if df.iloc[i].ix['v73'] in goutong_list:
        goutongfen+=1
    if df.iloc[i].ix['v75'] in goutong_list:
        goutongfen+=1
    dfa.goutong.iloc[i] = goutongfen
    #print("%d %d"% (i,goutongfen))
    
def chengshi_weight(i):
    global df,dfa
    chengshifen = 0
    if not math.isnan(df.iloc[i].ix['v78']):
        chengshifen+=1
    if not math.isnan(df.iloc[i].ix['v80']):
        chengshifen+=1
    if not math.isnan(df.iloc[i].ix['v82']):
        chengshifen+=1
    if not math.isnan(df.iloc[i].ix['v84']):
        chengshifen+=1
    if not math.isnan(df.iloc[i].ix['v86']):
        chengshifen+=1
    dfa.chengshi.iloc[i] = chengshifen
    #print("%d %d"% (i,chengshifen))

def quanmian_weight(i):
    global df,dfa
    quanmianfen = 0
    if not math.isnan(df.iloc[i].ix['v68']):
        quanmianfen+=1
    if not math.isnan(df.iloc[i].ix['v70']):
        quanmianfen+=1
    if not math.isnan(df.iloc[i].ix['v72']):
        quanmianfen+=1
    if not math.isnan(df.iloc[i].ix['v74']):
        quanmianfen+=1
    if not math.isnan(df.iloc[i].ix['v76']):
        quanmianfen+=1
    dfa.quanmian.iloc[i] = quanmianfen
    #print("%d %d"% (i,quanmianfen))
    
def pro_consume():
    global df,dfa
    rowlen = len(df.v0)
    #print(rowlen)
    for i in range(rowlen):
        goutong_weight(i)
        chengshi_weight(i)
        quanmian_weight(i)
            
if __name__ == '__main__':
    global df,dfa
    sum1 = 0
    df = pd.read_csv('paydata.csv', header = 0)
    dfa = pd.read_csv('unipay_fill_carprice1555742409.csv', header = 0)
    dfa['chengshi'] = 0
    dfa['quanmian'] = 0
    dfa['goutong'] = 0
    #df['zijin'].describe()
    #df.info()
    sns.set_style('whitegrid')
    colors = ["scarlet", "pinkish orange", "amber",
              "lime green", "cyan","blue violet","fuchsia"]
    sns.set(palette=sns.xkcd_palette(colors))
    
    pro_consume()
    pro_v15_v28()
    pro_v4_v18()
    pro_goutong_chengshi()
    pro_quanmian_v28_v21()
    dfa.info()
    name = "./unipay_power_res" + str(int(time.time())) + ".csv"
    dfa.to_csv(name)