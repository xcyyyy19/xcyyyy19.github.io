# -*- coding: utf-8 -*-
"""
Created on Wed Nov 21 19:03:12 2018

@author: zzr
"""
import numpy as np
import pandas as pd
import time
import matplotlib.pyplot as plt
import seaborn as sns

from sklearn import preprocessing
from sklearn.ensemble import RandomForestClassifier
from sklearn import cross_validation, metrics


import warnings
warnings.filterwarnings('ignore')

np.set_printoptions(precision=4, threshold=10000, linewidth=160, edgeitems=999, suppress=True)
pd.set_option('display.max_columns', None)
pd.set_option('display.max_rows', None)
pd.set_option('display.width', 160)
pd.set_option('expand_frame_repr', False)
pd.set_option('precision', 4)

'''
['v0','v4_s','v6','v10','v11']
'''
def v4mean(x):
    if 'U0' == x :
        return None
    y = x.split()
    z = ((float)(y[1]) + (float)(y[3]))*0.5
    if z > 0 and z<= 12:
        return 1
    elif z > 12 and z <= 30:
        return 2
    elif z > 30:
        return 3
    
def process_v4():
    global df
    df['v4'] = df.v4.fillna('U0')
    #print(df['v4'].describe())
    #sns.distplot(df['v4_s'],hist=True,kde=False,rug=False)
    df['v4_s'] = df['v4'].map( lambda x: v4mean(x))
    #print(df['v4_s'].describe())
    

def process_v6():
    global df    
    df.v6[df.v6.isnull()] = df.v6.dropna().mode().values
    
def process_vnull():
    global df    
    df.v10[df.v10.isnull()] = 0
    df.v11[df.v11.isnull()] = 0
    df.v13[df.v13.isnull()] = 0
    df.v14[df.v14.isnull()] = 0
    df.v29[df.v29.isnull()] = 0
    df.v30[df.v30.isnull()] = 0
    df.v31[df.v31.isnull()] = 0
    df.v32[df.v32.isnull()] = 0
    df.v41[df.v41.isnull()] = 0
    df.v42[df.v42.isnull()] = 0
    df.v44[df.v44.isnull()] = 0
    df.v45[df.v45.isnull()] = 0

if __name__ == '__main__':
    global df
    df = pd.read_csv('paydata.csv', header = 0)
    sns.set_style('whitegrid')
    plt.style.use({'figure.figsize':(7, 5)})
    colors = ["scarlet", "pinkish orange", "amber",
              "lime green", "cyan","blue violet","fuchsia"]
    #sns.distplot(df['v4_s'],hist=True,kde=False,rug=False)
    #df['v4_s'].describe()
    #df['v4_s'].value_counts()
    process_v4()
    process_v6()
    process_vnull()
    alist = ['v4_s']
    for i in range(6,67,1): 
        alist.append('v'+str(i))
    dfa = df[alist]
    #dfe.info()
    #dfe = dfa.drop(['v4_s'], axis=1)
    #scaler = preprocessing.MinMaxScaler()
    #nas = scaler.fit_transAform(dfe)
    #dfs = pd.DataFrame(nas)
    #dfa = pd.concat( [df['v4_s'], dfe], axis=1) 
    dfa.info()    
    dfa_notnull = dfa.loc[(dfa['v4_s'].notnull())]
    dfa_isnull = dfa.loc[(dfa['v4_s'].isnull())]
    X = dfa_notnull.values[:, 1:]
    Y = dfa_notnull.values[:,0]
    RFR = RandomForestClassifier(n_estimators=500, max_depth=11, 
                                 max_features='sqrt', min_samples_leaf=58, 
                                 oob_score=True, n_jobs=-1)
    RFR.fit(X,Y)
    print ("out of bag:", RFR.oob_score_)
    predictv4_s = RFR.predict(dfa_isnull.values[:,1:])
    dfa.loc[dfa['v4_s'].isnull(), ['v4_s']]= predictv4_s  
    
    name = "./unipay_fill_carprice" + str(int(time.time())) + ".csv"
    dfa.to_csv(name)
    